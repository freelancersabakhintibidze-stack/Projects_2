import { pgTable, serial, text, numeric, integer, timestamp, date } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const costsTable = pgTable("costs", {
  id: serial("id").primaryKey(),
  orderId: integer("order_id"),
  vehicleId: integer("vehicle_id"),
  type: text("type").notNull(),
  amount: numeric("amount", { precision: 12, scale: 2 }).notNull(),
  currency: text("currency").notNull().default("USD"),
  date: date("date", { mode: "string" }).notNull(),
  description: text("description"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const insertCostSchema = createInsertSchema(costsTable).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertCost = z.infer<typeof insertCostSchema>;
export type Cost = typeof costsTable.$inferSelect;
