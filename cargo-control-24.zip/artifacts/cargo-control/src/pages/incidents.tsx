import React, { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import {
  useListIncidents, useCreateIncident, useUpdateIncident, useDeleteIncident,
  getListIncidentsQueryKey
} from "@workspace/api-client-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Plus, Search, Edit, Trash2, CheckCircle } from "lucide-react";
import { formatShortDate } from "@/lib/format";
import { toast } from "sonner";

const SEVERITY_COLORS: Record<string, string> = {
  low: "bg-green-500/20 text-green-400 border-green-500/30",
  medium: "bg-yellow-500/20 text-yellow-400 border-yellow-500/30",
  high: "bg-orange-500/20 text-orange-400 border-orange-500/30",
  critical: "bg-red-500/20 text-red-400 border-red-500/30",
};

const STATUS_COLORS: Record<string, string> = {
  open: "bg-red-500/20 text-red-400 border-red-500/30",
  investigating: "bg-yellow-500/20 text-yellow-400 border-yellow-500/30",
  resolved: "bg-green-500/20 text-green-400 border-green-500/30",
};

const TYPES = ["accident", "delay", "theft", "mechanical", "other"];
const SEVERITIES = ["low", "medium", "high", "critical"];
const STATUSES = ["open", "investigating", "resolved"];

type IncidentInput = {
  title: string; type: string; severity: string; status: string;
  description?: string; orderId?: number; vehicleId?: number; driverId?: number; reportedAt?: string;
};

function IncidentFormDialog({ open, onOpenChange, initial, onSave }: {
  open: boolean; onOpenChange: (v: boolean) => void;
  initial?: Partial<IncidentInput> & { id?: number }; onSave: (d: IncidentInput) => void;
}) {
  const [form, setForm] = useState<IncidentInput>({
    title: initial?.title ?? "", type: initial?.type ?? "other",
    severity: initial?.severity ?? "low", status: initial?.status ?? "open",
    description: initial?.description ?? "",
  });
  const set = (k: keyof IncidentInput, v: unknown) => setForm(f => ({ ...f, [k]: v }));

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-card border-border">
        <DialogHeader><DialogTitle className="font-mono uppercase">{initial?.id ? "Edit Incident" : "Report Incident"}</DialogTitle></DialogHeader>
        <div className="grid grid-cols-2 gap-4 py-2">
          <div className="space-y-1 col-span-2">
            <Label className="font-mono text-xs uppercase">Title</Label>
            <Input value={form.title} onChange={e => set("title", e.target.value)} className="font-mono" />
          </div>
          <div className="space-y-1">
            <Label className="font-mono text-xs uppercase">Type</Label>
            <Select value={form.type} onValueChange={v => set("type", v)}>
              <SelectTrigger className="font-mono"><SelectValue /></SelectTrigger>
              <SelectContent>{TYPES.map(t => <SelectItem key={t} value={t} className="font-mono">{t}</SelectItem>)}</SelectContent>
            </Select>
          </div>
          <div className="space-y-1">
            <Label className="font-mono text-xs uppercase">Severity</Label>
            <Select value={form.severity} onValueChange={v => set("severity", v)}>
              <SelectTrigger className="font-mono"><SelectValue /></SelectTrigger>
              <SelectContent>{SEVERITIES.map(s => <SelectItem key={s} value={s} className="font-mono">{s}</SelectItem>)}</SelectContent>
            </Select>
          </div>
          <div className="col-span-2 space-y-1">
            <Label className="font-mono text-xs uppercase">Status</Label>
            <Select value={form.status} onValueChange={v => set("status", v)}>
              <SelectTrigger className="font-mono"><SelectValue /></SelectTrigger>
              <SelectContent>{STATUSES.map(s => <SelectItem key={s} value={s} className="font-mono">{s}</SelectItem>)}</SelectContent>
            </Select>
          </div>
          <div className="space-y-1">
            <Label className="font-mono text-xs uppercase">Order ID</Label>
            <Input type="number" value={form.orderId ?? ""} onChange={e => set("orderId", e.target.value ? parseInt(e.target.value) : undefined)} className="font-mono" placeholder="Optional" />
          </div>
          <div className="space-y-1">
            <Label className="font-mono text-xs uppercase">Vehicle ID</Label>
            <Input type="number" value={form.vehicleId ?? ""} onChange={e => set("vehicleId", e.target.value ? parseInt(e.target.value) : undefined)} className="font-mono" placeholder="Optional" />
          </div>
          <div className="col-span-2 space-y-1">
            <Label className="font-mono text-xs uppercase">Description</Label>
            <Textarea value={form.description ?? ""} onChange={e => set("description", e.target.value)} className="font-mono" rows={3} />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)} className="font-mono">Cancel</Button>
          <Button onClick={() => onSave(form)} className="font-mono">Save Incident</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

export default function Incidents() {
  const qc = useQueryClient();
  const { data: incidents, isLoading } = useListIncidents();
  const createMutation = useCreateIncident();
  const updateMutation = useUpdateIncident();
  const deleteMutation = useDeleteIncident();
  const [search, setSearch] = useState("");
  const [showCreate, setShowCreate] = useState(false);
  const [editItem, setEditItem] = useState<(typeof incidents extends (infer T)[] | undefined ? T : never) | null>(null);

  const filtered = (incidents ?? []).filter(i =>
    i.title.toLowerCase().includes(search.toLowerCase()) ||
    i.type.toLowerCase().includes(search.toLowerCase()) ||
    i.severity.toLowerCase().includes(search.toLowerCase())
  );

  const handleResolve = (id: number) => {
    updateMutation.mutate({ id, data: { status: "resolved", resolvedAt: new Date().toISOString() } }, {
      onSuccess: () => { qc.invalidateQueries({ queryKey: getListIncidentsQueryKey() }); toast.success("Incident resolved"); },
      onError: () => toast.error("Failed"),
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-mono font-bold tracking-tight uppercase">Incidents</h1>
        <Button onClick={() => setShowCreate(true)} className="font-mono uppercase"><Plus className="h-4 w-4 mr-2" /> Report Incident</Button>
      </div>
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input placeholder="Search incidents..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9 font-mono" />
      </div>
      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow className="border-border">
                <TableHead className="font-mono uppercase text-xs">Title</TableHead>
                <TableHead className="font-mono uppercase text-xs">Type</TableHead>
                <TableHead className="font-mono uppercase text-xs">Severity</TableHead>
                <TableHead className="font-mono uppercase text-xs">Status</TableHead>
                <TableHead className="font-mono uppercase text-xs">Reported</TableHead>
                <TableHead className="font-mono uppercase text-xs">Resolved</TableHead>
                <TableHead className="w-[110px]"></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                Array.from({ length: 4 }).map((_, i) => (
                  <TableRow key={i}>{Array.from({ length: 7 }).map((_, j) => <TableCell key={j}><Skeleton className="h-5 w-full" /></TableCell>)}</TableRow>
                ))
              ) : filtered.length === 0 ? (
                <TableRow><TableCell colSpan={7} className="text-center text-muted-foreground font-mono py-12">No incidents found</TableCell></TableRow>
              ) : (
                filtered.map(i => (
                  <TableRow key={i.id} className="border-border hover:bg-muted/5">
                    <TableCell className="font-mono font-medium">{i.title}</TableCell>
                    <TableCell className="font-mono text-xs uppercase text-muted-foreground">{i.type}</TableCell>
                    <TableCell>
                      <span className={`px-2 py-0.5 rounded-sm border text-xs font-mono uppercase font-medium ${SEVERITY_COLORS[i.severity] ?? "bg-muted"}`}>{i.severity}</span>
                    </TableCell>
                    <TableCell>
                      <span className={`px-2 py-0.5 rounded-sm border text-xs font-mono uppercase font-medium ${STATUS_COLORS[i.status] ?? "bg-muted"}`}>{i.status}</span>
                    </TableCell>
                    <TableCell className="font-mono text-xs text-muted-foreground">{formatShortDate(i.reportedAt)}</TableCell>
                    <TableCell className="font-mono text-xs text-muted-foreground">{i.resolvedAt ? formatShortDate(i.resolvedAt) : "—"}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1">
                        {i.status !== "resolved" && (
                          <Button variant="ghost" size="icon" title="Resolve" onClick={() => handleResolve(i.id)}>
                            <CheckCircle className="h-3.5 w-3.5 text-green-400" />
                          </Button>
                        )}
                        <Button variant="ghost" size="icon" onClick={() => setEditItem(i)}><Edit className="h-3.5 w-3.5" /></Button>
                        <Button variant="ghost" size="icon" className="text-destructive hover:text-destructive"
                          onClick={() => { if (!confirm("Delete this incident?")) return; deleteMutation.mutate({ id: i.id }, { onSuccess: () => { qc.invalidateQueries({ queryKey: getListIncidentsQueryKey() }); toast.success("Deleted"); }, onError: () => toast.error("Failed") }); }}>
                          <Trash2 className="h-3.5 w-3.5" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
      <IncidentFormDialog open={showCreate} onOpenChange={setShowCreate} onSave={data => { createMutation.mutate({ data }, { onSuccess: () => { qc.invalidateQueries({ queryKey: getListIncidentsQueryKey() }); setShowCreate(false); toast.success("Incident reported"); }, onError: () => toast.error("Failed") }); }} />
      {editItem && <IncidentFormDialog open={!!editItem} onOpenChange={() => setEditItem(null)} initial={editItem as Partial<IncidentInput> & { id: number }} onSave={data => { updateMutation.mutate({ id: editItem.id, data }, { onSuccess: () => { qc.invalidateQueries({ queryKey: getListIncidentsQueryKey() }); setEditItem(null); toast.success("Updated"); }, onError: () => toast.error("Failed") }); }} />}
    </div>
  );
}
