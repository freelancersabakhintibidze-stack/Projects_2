import React, { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import {
  useListCosts, useCreateCost, useUpdateCost, useDeleteCost, useGetCostBreakdown,
  getListCostsQueryKey
} from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Plus, Search, Edit, Trash2, DollarSign } from "lucide-react";
import { formatCurrency } from "@/lib/format";
import { toast } from "sonner";

const TYPES = ["fuel", "toll", "maintenance", "salary", "loading", "other"];
const TYPE_COLORS: Record<string, string> = {
  fuel: "bg-orange-500/20 text-orange-400 border-orange-500/30",
  toll: "bg-purple-500/20 text-purple-400 border-purple-500/30",
  maintenance: "bg-yellow-500/20 text-yellow-400 border-yellow-500/30",
  salary: "bg-blue-500/20 text-blue-400 border-blue-500/30",
  loading: "bg-cyan-500/20 text-cyan-400 border-cyan-500/30",
  other: "bg-muted text-muted-foreground border-border",
};

type CostInput = {
  orderId?: number; vehicleId?: number; type: string;
  amount: number; currency: string; date: string; description?: string;
};

function CostFormDialog({ open, onOpenChange, initial, onSave }: {
  open: boolean; onOpenChange: (v: boolean) => void;
  initial?: Partial<CostInput> & { id?: number }; onSave: (d: CostInput) => void;
}) {
  const [form, setForm] = useState<CostInput>({
    type: initial?.type ?? "fuel", amount: initial?.amount ?? 0,
    currency: initial?.currency ?? "USD",
    date: initial?.date ?? new Date().toISOString().slice(0, 10),
    description: initial?.description ?? "",
  });
  const set = (k: keyof CostInput, v: unknown) => setForm(f => ({ ...f, [k]: v }));

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-card border-border">
        <DialogHeader><DialogTitle className="font-mono uppercase">{initial?.id ? "Edit Cost" : "Add Cost"}</DialogTitle></DialogHeader>
        <div className="grid grid-cols-2 gap-4 py-2">
          <div className="space-y-1">
            <Label className="font-mono text-xs uppercase">Type</Label>
            <Select value={form.type} onValueChange={v => set("type", v)}>
              <SelectTrigger className="font-mono"><SelectValue /></SelectTrigger>
              <SelectContent>{TYPES.map(t => <SelectItem key={t} value={t} className="font-mono">{t}</SelectItem>)}</SelectContent>
            </Select>
          </div>
          <div className="space-y-1">
            <Label className="font-mono text-xs uppercase">Amount</Label>
            <Input type="number" value={form.amount} onChange={e => set("amount", parseFloat(e.target.value))} className="font-mono" />
          </div>
          <div className="space-y-1">
            <Label className="font-mono text-xs uppercase">Currency</Label>
            <Input value={form.currency} onChange={e => set("currency", e.target.value)} className="font-mono" />
          </div>
          <div className="space-y-1">
            <Label className="font-mono text-xs uppercase">Date</Label>
            <Input type="date" value={form.date} onChange={e => set("date", e.target.value)} className="font-mono" />
          </div>
          <div className="space-y-1">
            <Label className="font-mono text-xs uppercase">Order ID</Label>
            <Input type="number" value={form.orderId ?? ""} onChange={e => set("orderId", e.target.value ? parseInt(e.target.value) : undefined)} className="font-mono" placeholder="Optional" />
          </div>
          <div className="space-y-1">
            <Label className="font-mono text-xs uppercase">Vehicle ID</Label>
            <Input type="number" value={form.vehicleId ?? ""} onChange={e => set("vehicleId", e.target.value ? parseInt(e.target.value) : undefined)} className="font-mono" placeholder="Optional" />
          </div>
          <div className="col-span-2 space-y-1">
            <Label className="font-mono text-xs uppercase">Description</Label>
            <Textarea value={form.description ?? ""} onChange={e => set("description", e.target.value)} className="font-mono" rows={2} />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)} className="font-mono">Cancel</Button>
          <Button onClick={() => onSave(form)} className="font-mono">Save Cost</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

export default function Costs() {
  const qc = useQueryClient();
  const { data: costs, isLoading } = useListCosts();
  const { data: breakdown } = useGetCostBreakdown();
  const createMutation = useCreateCost();
  const updateMutation = useUpdateCost();
  const deleteMutation = useDeleteCost();
  const [search, setSearch] = useState("");
  const [showCreate, setShowCreate] = useState(false);
  const [editItem, setEditItem] = useState<(typeof costs extends (infer T)[] | undefined ? T : never) | null>(null);

  const filtered = (costs ?? []).filter(c =>
    c.type.toLowerCase().includes(search.toLowerCase()) ||
    (c.description ?? "").toLowerCase().includes(search.toLowerCase())
  );

  const totalAmount = (costs ?? []).reduce((s, c) => s + Number(c.amount), 0);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-mono font-bold tracking-tight uppercase">Costs</h1>
        <Button onClick={() => setShowCreate(true)} className="font-mono uppercase"><Plus className="h-4 w-4 mr-2" /> Add Cost</Button>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-2 flex flex-row items-center justify-between space-y-0">
            <CardTitle className="text-xs font-mono uppercase text-muted-foreground">Total Costs</CardTitle>
            <DollarSign className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold font-mono">{formatCurrency(totalAmount)}</div>
          </CardContent>
        </Card>
        {(breakdown ?? []).slice(0, 3).map(b => (
          <Card key={b.type}>
            <CardHeader className="pb-2">
              <CardTitle className="text-xs font-mono uppercase text-muted-foreground">{b.type}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-xl font-bold font-mono">{formatCurrency(b.total)}</div>
              <p className="text-xs text-muted-foreground font-mono">{b.count} entries</p>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input placeholder="Search costs..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9 font-mono" />
      </div>
      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow className="border-border">
                <TableHead className="font-mono uppercase text-xs">Type</TableHead>
                <TableHead className="font-mono uppercase text-xs">Amount</TableHead>
                <TableHead className="font-mono uppercase text-xs">Date</TableHead>
                <TableHead className="font-mono uppercase text-xs">Order ID</TableHead>
                <TableHead className="font-mono uppercase text-xs">Vehicle ID</TableHead>
                <TableHead className="font-mono uppercase text-xs">Description</TableHead>
                <TableHead className="w-[80px]"></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                Array.from({ length: 5 }).map((_, i) => (
                  <TableRow key={i}>{Array.from({ length: 7 }).map((_, j) => <TableCell key={j}><Skeleton className="h-5 w-full" /></TableCell>)}</TableRow>
                ))
              ) : filtered.length === 0 ? (
                <TableRow><TableCell colSpan={7} className="text-center text-muted-foreground font-mono py-12">No cost entries found</TableCell></TableRow>
              ) : (
                filtered.map(c => (
                  <TableRow key={c.id} className="border-border hover:bg-muted/5">
                    <TableCell>
                      <span className={`px-2 py-0.5 rounded-sm border text-xs font-mono uppercase font-medium ${TYPE_COLORS[c.type] ?? TYPE_COLORS.other}`}>{c.type}</span>
                    </TableCell>
                    <TableCell className="font-mono font-medium text-primary">{formatCurrency(Number(c.amount), c.currency)}</TableCell>
                    <TableCell className="font-mono text-xs">{c.date}</TableCell>
                    <TableCell className="font-mono text-xs text-muted-foreground">{c.orderId ?? "—"}</TableCell>
                    <TableCell className="font-mono text-xs text-muted-foreground">{c.vehicleId ?? "—"}</TableCell>
                    <TableCell className="font-mono text-xs text-muted-foreground max-w-[200px] truncate">{c.description ?? "—"}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1">
                        <Button variant="ghost" size="icon" onClick={() => setEditItem(c)}><Edit className="h-3.5 w-3.5" /></Button>
                        <Button variant="ghost" size="icon" className="text-destructive hover:text-destructive"
                          onClick={() => { if (!confirm("Delete this entry?")) return; deleteMutation.mutate({ id: c.id }, { onSuccess: () => { qc.invalidateQueries({ queryKey: getListCostsQueryKey() }); toast.success("Deleted"); }, onError: () => toast.error("Failed") }); }}>
                          <Trash2 className="h-3.5 w-3.5" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
      <CostFormDialog open={showCreate} onOpenChange={setShowCreate} onSave={data => { createMutation.mutate({ data }, { onSuccess: () => { qc.invalidateQueries({ queryKey: getListCostsQueryKey() }); setShowCreate(false); toast.success("Cost added"); }, onError: () => toast.error("Failed") }); }} />
      {editItem && <CostFormDialog open={!!editItem} onOpenChange={() => setEditItem(null)} initial={editItem as Partial<CostInput> & { id: number }} onSave={data => { updateMutation.mutate({ id: editItem.id, data }, { onSuccess: () => { qc.invalidateQueries({ queryKey: getListCostsQueryKey() }); setEditItem(null); toast.success("Updated"); }, onError: () => toast.error("Failed") }); }} />}
    </div>
  );
}
