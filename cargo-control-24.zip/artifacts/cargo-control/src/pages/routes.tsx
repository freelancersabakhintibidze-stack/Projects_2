import React, { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import {
  useListRoutes, useCreateRoute, useUpdateRoute, useDeleteRoute,
  getListRoutesQueryKey
} from "@workspace/api-client-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Plus, Search, Edit, Trash2 } from "lucide-react";
import { toast } from "sonner";

const STATUS_COLORS: Record<string, string> = {
  active: "bg-green-500/20 text-green-400 border-green-500/30",
  inactive: "bg-red-500/20 text-red-400 border-red-500/30",
};

type RouteInput = {
  name: string; origin: string; destination: string;
  distanceKm: number; estimatedHours?: number; status: string; notes?: string;
};

function RouteFormDialog({ open, onOpenChange, initial, onSave }: {
  open: boolean; onOpenChange: (v: boolean) => void;
  initial?: Partial<RouteInput> & { id?: number }; onSave: (d: RouteInput) => void;
}) {
  const [form, setForm] = useState<RouteInput>({
    name: initial?.name ?? "", origin: initial?.origin ?? "",
    destination: initial?.destination ?? "", distanceKm: initial?.distanceKm ?? 0,
    estimatedHours: initial?.estimatedHours ?? undefined, status: initial?.status ?? "active",
    notes: initial?.notes ?? "",
  });
  const set = (k: keyof RouteInput, v: unknown) => setForm(f => ({ ...f, [k]: v }));

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-card border-border">
        <DialogHeader><DialogTitle className="font-mono uppercase">{initial?.id ? "Edit Route" : "Add Route"}</DialogTitle></DialogHeader>
        <div className="grid grid-cols-2 gap-4 py-2">
          <div className="space-y-1 col-span-2">
            <Label className="font-mono text-xs uppercase">Route Name</Label>
            <Input value={form.name} onChange={e => set("name", e.target.value)} className="font-mono" />
          </div>
          <div className="space-y-1">
            <Label className="font-mono text-xs uppercase">Origin</Label>
            <Input value={form.origin} onChange={e => set("origin", e.target.value)} className="font-mono" />
          </div>
          <div className="space-y-1">
            <Label className="font-mono text-xs uppercase">Destination</Label>
            <Input value={form.destination} onChange={e => set("destination", e.target.value)} className="font-mono" />
          </div>
          <div className="space-y-1">
            <Label className="font-mono text-xs uppercase">Distance (km)</Label>
            <Input type="number" value={form.distanceKm} onChange={e => set("distanceKm", parseFloat(e.target.value))} className="font-mono" />
          </div>
          <div className="space-y-1">
            <Label className="font-mono text-xs uppercase">Est. Hours</Label>
            <Input type="number" value={form.estimatedHours ?? ""} onChange={e => set("estimatedHours", e.target.value ? parseFloat(e.target.value) : undefined)} className="font-mono" />
          </div>
          <div className="col-span-2 space-y-1">
            <Label className="font-mono text-xs uppercase">Status</Label>
            <Select value={form.status} onValueChange={v => set("status", v)}>
              <SelectTrigger className="font-mono"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="active" className="font-mono">active</SelectItem>
                <SelectItem value="inactive" className="font-mono">inactive</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="col-span-2 space-y-1">
            <Label className="font-mono text-xs uppercase">Notes</Label>
            <Textarea value={form.notes ?? ""} onChange={e => set("notes", e.target.value)} className="font-mono" rows={2} />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)} className="font-mono">Cancel</Button>
          <Button onClick={() => onSave(form)} className="font-mono">Save Route</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

export default function RoutesPage() {
  const qc = useQueryClient();
  const { data: routes, isLoading } = useListRoutes();
  const createMutation = useCreateRoute();
  const updateMutation = useUpdateRoute();
  const deleteMutation = useDeleteRoute();
  const [search, setSearch] = useState("");
  const [showCreate, setShowCreate] = useState(false);
  const [editItem, setEditItem] = useState<(typeof routes extends (infer T)[] | undefined ? T : never) | null>(null);

  const filtered = (routes ?? []).filter(r =>
    r.name.toLowerCase().includes(search.toLowerCase()) ||
    r.origin.toLowerCase().includes(search.toLowerCase()) ||
    r.destination.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-mono font-bold tracking-tight uppercase">Routes</h1>
        <Button onClick={() => setShowCreate(true)} className="font-mono uppercase"><Plus className="h-4 w-4 mr-2" /> Add Route</Button>
      </div>
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input placeholder="Search routes..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9 font-mono" />
      </div>
      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow className="border-border">
                <TableHead className="font-mono uppercase text-xs">Name</TableHead>
                <TableHead className="font-mono uppercase text-xs">Origin</TableHead>
                <TableHead className="font-mono uppercase text-xs">Destination</TableHead>
                <TableHead className="font-mono uppercase text-xs">Distance</TableHead>
                <TableHead className="font-mono uppercase text-xs">Est. Time</TableHead>
                <TableHead className="font-mono uppercase text-xs">Status</TableHead>
                <TableHead className="w-[80px]"></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                Array.from({ length: 4 }).map((_, i) => (
                  <TableRow key={i}>{Array.from({ length: 7 }).map((_, j) => <TableCell key={j}><Skeleton className="h-5 w-full" /></TableCell>)}</TableRow>
                ))
              ) : filtered.length === 0 ? (
                <TableRow><TableCell colSpan={7} className="text-center text-muted-foreground font-mono py-12">No routes found</TableCell></TableRow>
              ) : (
                filtered.map(r => (
                  <TableRow key={r.id} className="border-border hover:bg-muted/5">
                    <TableCell className="font-mono font-medium text-primary">{r.name}</TableCell>
                    <TableCell className="font-mono text-xs">{r.origin}</TableCell>
                    <TableCell className="font-mono text-xs">{r.destination}</TableCell>
                    <TableCell className="font-mono text-xs">{Number(r.distanceKm).toLocaleString()} km</TableCell>
                    <TableCell className="font-mono text-xs text-muted-foreground">
                      {r.estimatedHours != null ? `${r.estimatedHours}h` : "—"}
                    </TableCell>
                    <TableCell>
                      <span className={`px-2 py-0.5 rounded-sm border text-xs font-mono uppercase font-medium ${STATUS_COLORS[r.status] ?? "bg-muted text-muted-foreground"}`}>{r.status}</span>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1">
                        <Button variant="ghost" size="icon" onClick={() => setEditItem(r)}><Edit className="h-3.5 w-3.5" /></Button>
                        <Button variant="ghost" size="icon" className="text-destructive hover:text-destructive"
                          onClick={() => { if (!confirm("Delete this route?")) return; deleteMutation.mutate({ id: r.id }, { onSuccess: () => { qc.invalidateQueries({ queryKey: getListRoutesQueryKey() }); toast.success("Route deleted"); }, onError: () => toast.error("Failed") }); }}>
                          <Trash2 className="h-3.5 w-3.5" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
      <RouteFormDialog open={showCreate} onOpenChange={setShowCreate} onSave={data => { createMutation.mutate({ data }, { onSuccess: () => { qc.invalidateQueries({ queryKey: getListRoutesQueryKey() }); setShowCreate(false); toast.success("Route added"); }, onError: () => toast.error("Failed") }); }} />
      {editItem && <RouteFormDialog open={!!editItem} onOpenChange={() => setEditItem(null)} initial={editItem as Partial<RouteInput> & { id: number }} onSave={data => { updateMutation.mutate({ id: editItem.id, data }, { onSuccess: () => { qc.invalidateQueries({ queryKey: getListRoutesQueryKey() }); setEditItem(null); toast.success("Updated"); }, onError: () => toast.error("Failed") }); }} />}
    </div>
  );
}
