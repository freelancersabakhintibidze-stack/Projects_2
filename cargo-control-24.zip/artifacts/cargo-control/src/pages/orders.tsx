import React, { useState } from "react";
import { Link } from "wouter";
import { useQueryClient } from "@tanstack/react-query";
import {
  useListOrders, useCreateOrder, useUpdateOrder, useDeleteOrder,
  useListDrivers, useListVehicles, useListRoutes,
  getListOrdersQueryKey
} from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Plus, Search, ExternalLink, Trash2, Edit } from "lucide-react";
import { formatShortDate, formatCurrency } from "@/lib/format";
import { toast } from "sonner";

const STATUS_COLORS: Record<string, string> = {
  pending: "bg-yellow-500/20 text-yellow-400 border-yellow-500/30",
  in_transit: "bg-blue-500/20 text-blue-400 border-blue-500/30",
  delivered: "bg-green-500/20 text-green-400 border-green-500/30",
  cancelled: "bg-red-500/20 text-red-400 border-red-500/30",
};

const STATUSES = ["pending", "in_transit", "delivered", "cancelled"];

type OrderInput = {
  clientName: string;
  origin: string;
  destination: string;
  cargoType: string;
  weightKg: number;
  status: string;
  routeId?: number;
  driverId?: number;
  vehicleId?: number;
  scheduledDate?: string;
  notes?: string;
};

function OrderFormDialog({
  open, onOpenChange, initial, onSave
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  initial?: Partial<OrderInput> & { id?: number };
  onSave: (data: OrderInput) => void;
}) {
  const { data: drivers } = useListDrivers();
  const { data: vehicles } = useListVehicles();
  const { data: routes } = useListRoutes();
  const [form, setForm] = useState<OrderInput>({
    clientName: initial?.clientName ?? "",
    origin: initial?.origin ?? "",
    destination: initial?.destination ?? "",
    cargoType: initial?.cargoType ?? "",
    weightKg: initial?.weightKg ?? 0,
    status: initial?.status ?? "pending",
    routeId: initial?.routeId ?? undefined,
    driverId: initial?.driverId ?? undefined,
    vehicleId: initial?.vehicleId ?? undefined,
    scheduledDate: initial?.scheduledDate ?? "",
    notes: initial?.notes ?? "",
  });

  const set = (k: keyof OrderInput, v: unknown) => setForm((f) => ({ ...f, [k]: v }));

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-card border-border max-w-2xl">
        <DialogHeader>
          <DialogTitle className="font-mono uppercase">{initial?.id ? "Edit Order" : "New Order"}</DialogTitle>
        </DialogHeader>
        <div className="grid grid-cols-2 gap-4 py-2">
          <div className="space-y-1">
            <Label className="font-mono text-xs uppercase">Client Name</Label>
            <Input value={form.clientName} onChange={e => set("clientName", e.target.value)} className="font-mono" />
          </div>
          <div className="space-y-1">
            <Label className="font-mono text-xs uppercase">Cargo Type</Label>
            <Input value={form.cargoType} onChange={e => set("cargoType", e.target.value)} className="font-mono" />
          </div>
          <div className="space-y-1">
            <Label className="font-mono text-xs uppercase">Origin</Label>
            <Input value={form.origin} onChange={e => set("origin", e.target.value)} className="font-mono" />
          </div>
          <div className="space-y-1">
            <Label className="font-mono text-xs uppercase">Destination</Label>
            <Input value={form.destination} onChange={e => set("destination", e.target.value)} className="font-mono" />
          </div>
          <div className="space-y-1">
            <Label className="font-mono text-xs uppercase">Weight (kg)</Label>
            <Input type="number" value={form.weightKg} onChange={e => set("weightKg", parseFloat(e.target.value))} className="font-mono" />
          </div>
          <div className="space-y-1">
            <Label className="font-mono text-xs uppercase">Status</Label>
            <Select value={form.status} onValueChange={v => set("status", v)}>
              <SelectTrigger className="font-mono"><SelectValue /></SelectTrigger>
              <SelectContent>
                {STATUSES.map(s => <SelectItem key={s} value={s} className="font-mono">{s}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1">
            <Label className="font-mono text-xs uppercase">Route</Label>
            <Select value={form.routeId?.toString() ?? "none"} onValueChange={v => set("routeId", v === "none" ? undefined : parseInt(v))}>
              <SelectTrigger className="font-mono"><SelectValue placeholder="None" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="none" className="font-mono">None</SelectItem>
                {routes?.map(r => <SelectItem key={r.id} value={r.id.toString()} className="font-mono">{r.name}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1">
            <Label className="font-mono text-xs uppercase">Driver</Label>
            <Select value={form.driverId?.toString() ?? "none"} onValueChange={v => set("driverId", v === "none" ? undefined : parseInt(v))}>
              <SelectTrigger className="font-mono"><SelectValue placeholder="None" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="none" className="font-mono">None</SelectItem>
                {drivers?.map(d => <SelectItem key={d.id} value={d.id.toString()} className="font-mono">{d.fullName}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1">
            <Label className="font-mono text-xs uppercase">Vehicle</Label>
            <Select value={form.vehicleId?.toString() ?? "none"} onValueChange={v => set("vehicleId", v === "none" ? undefined : parseInt(v))}>
              <SelectTrigger className="font-mono"><SelectValue placeholder="None" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="none" className="font-mono">None</SelectItem>
                {vehicles?.map(v => <SelectItem key={v.id} value={v.id.toString()} className="font-mono">{v.plate}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1">
            <Label className="font-mono text-xs uppercase">Scheduled Date</Label>
            <Input type="date" value={form.scheduledDate ?? ""} onChange={e => set("scheduledDate", e.target.value)} className="font-mono" />
          </div>
          <div className="col-span-2 space-y-1">
            <Label className="font-mono text-xs uppercase">Notes</Label>
            <Textarea value={form.notes ?? ""} onChange={e => set("notes", e.target.value)} className="font-mono" rows={2} />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)} className="font-mono">Cancel</Button>
          <Button onClick={() => onSave(form)} className="font-mono">Save Order</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

export default function Orders() {
  const qc = useQueryClient();
  const { data: orders, isLoading } = useListOrders();
  const createMutation = useCreateOrder();
  const updateMutation = useUpdateOrder();
  const deleteMutation = useDeleteOrder();

  const [search, setSearch] = useState("");
  const [showCreate, setShowCreate] = useState(false);
  const [editOrder, setEditOrder] = useState<(typeof orders extends (infer T)[] | undefined ? T : never) | null>(null);

  const filtered = (orders ?? []).filter(o =>
    o.clientName.toLowerCase().includes(search.toLowerCase()) ||
    o.orderNumber.toLowerCase().includes(search.toLowerCase()) ||
    o.origin.toLowerCase().includes(search.toLowerCase()) ||
    o.destination.toLowerCase().includes(search.toLowerCase())
  );

  const handleCreate = (data: OrderInput) => {
    createMutation.mutate({ data }, {
      onSuccess: () => {
        qc.invalidateQueries({ queryKey: getListOrdersQueryKey() });
        setShowCreate(false);
        toast.success("Order created");
      },
      onError: () => toast.error("Failed to create order"),
    });
  };

  const handleUpdate = (data: OrderInput) => {
    if (!editOrder) return;
    updateMutation.mutate({ id: editOrder.id, data }, {
      onSuccess: () => {
        qc.invalidateQueries({ queryKey: getListOrdersQueryKey() });
        setEditOrder(null);
        toast.success("Order updated");
      },
      onError: () => toast.error("Failed to update order"),
    });
  };

  const handleDelete = (id: number) => {
    if (!confirm("Delete this order?")) return;
    deleteMutation.mutate({ id }, {
      onSuccess: () => {
        qc.invalidateQueries({ queryKey: getListOrdersQueryKey() });
        toast.success("Order deleted");
      },
      onError: () => toast.error("Failed to delete order"),
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-mono font-bold tracking-tight uppercase">Orders</h1>
        <Button onClick={() => setShowCreate(true)} className="font-mono uppercase">
          <Plus className="h-4 w-4 mr-2" /> New Order
        </Button>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Search orders..."
          value={search}
          onChange={e => setSearch(e.target.value)}
          className="pl-9 font-mono"
        />
      </div>

      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow className="border-border">
                <TableHead className="font-mono uppercase text-xs">Order #</TableHead>
                <TableHead className="font-mono uppercase text-xs">Client</TableHead>
                <TableHead className="font-mono uppercase text-xs">Route</TableHead>
                <TableHead className="font-mono uppercase text-xs">Cargo</TableHead>
                <TableHead className="font-mono uppercase text-xs">Weight</TableHead>
                <TableHead className="font-mono uppercase text-xs">Status</TableHead>
                <TableHead className="font-mono uppercase text-xs">Scheduled</TableHead>
                <TableHead className="font-mono uppercase text-xs">Cost</TableHead>
                <TableHead className="w-[100px]"></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                Array.from({ length: 5 }).map((_, i) => (
                  <TableRow key={i}>
                    {Array.from({ length: 9 }).map((_, j) => (
                      <TableCell key={j}><Skeleton className="h-5 w-full" /></TableCell>
                    ))}
                  </TableRow>
                ))
              ) : filtered.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={9} className="text-center text-muted-foreground font-mono py-12">
                    No orders found
                  </TableCell>
                </TableRow>
              ) : (
                filtered.map(order => (
                  <TableRow key={order.id} className="border-border hover:bg-muted/5">
                    <TableCell className="font-mono text-primary font-medium">{order.orderNumber}</TableCell>
                    <TableCell className="font-mono">{order.clientName}</TableCell>
                    <TableCell className="font-mono text-xs text-muted-foreground">
                      {order.origin} → {order.destination}
                    </TableCell>
                    <TableCell className="font-mono text-xs">{order.cargoType}</TableCell>
                    <TableCell className="font-mono text-xs">{order.weightKg.toLocaleString()} kg</TableCell>
                    <TableCell>
                      <span className={`px-2 py-0.5 rounded-sm border text-xs font-mono uppercase font-medium ${STATUS_COLORS[order.status] ?? "bg-muted text-muted-foreground"}`}>
                        {order.status}
                      </span>
                    </TableCell>
                    <TableCell className="font-mono text-xs text-muted-foreground">
                      {order.scheduledDate ?? "—"}
                    </TableCell>
                    <TableCell className="font-mono text-xs">
                      {order.totalCost != null ? formatCurrency(order.totalCost) : "—"}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1">
                        <Button variant="ghost" size="icon" asChild>
                          <Link href={`/orders/${order.id}`}><ExternalLink className="h-3.5 w-3.5" /></Link>
                        </Button>
                        <Button variant="ghost" size="icon" onClick={() => setEditOrder(order)}>
                          <Edit className="h-3.5 w-3.5" />
                        </Button>
                        <Button variant="ghost" size="icon" onClick={() => handleDelete(order.id)} className="text-destructive hover:text-destructive">
                          <Trash2 className="h-3.5 w-3.5" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <OrderFormDialog open={showCreate} onOpenChange={setShowCreate} onSave={handleCreate} />
      {editOrder && (
        <OrderFormDialog
          open={!!editOrder}
          onOpenChange={() => setEditOrder(null)}
          initial={editOrder as Partial<OrderInput> & { id: number }}
          onSave={handleUpdate}
        />
      )}
    </div>
  );
}
