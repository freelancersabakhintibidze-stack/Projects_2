import React, { useState } from "react";
import { useParams, useLocation } from "wouter";
import { useQueryClient } from "@tanstack/react-query";
import {
  useGetOrder, useUpdateOrder, useListCosts, useListIncidents,
  useListDrivers, useListVehicles, useListRoutes,
  getGetOrderQueryKey, getListOrdersQueryKey
} from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { ArrowLeft, Save } from "lucide-react";
import { formatCurrency, formatShortDate } from "@/lib/format";
import { toast } from "sonner";

const STATUS_COLORS: Record<string, string> = {
  pending: "bg-yellow-500/20 text-yellow-400 border-yellow-500/30",
  in_transit: "bg-blue-500/20 text-blue-400 border-blue-500/30",
  delivered: "bg-green-500/20 text-green-400 border-green-500/30",
  cancelled: "bg-red-500/20 text-red-400 border-red-500/30",
};

const SEVERITY_COLORS: Record<string, string> = {
  low: "bg-green-500/20 text-green-400 border-green-500/30",
  medium: "bg-yellow-500/20 text-yellow-400 border-yellow-500/30",
  high: "bg-orange-500/20 text-orange-400 border-orange-500/30",
  critical: "bg-red-500/20 text-red-400 border-red-500/30",
};

const STATUSES = ["pending", "in_transit", "delivered", "cancelled"];

export default function OrderDetail() {
  const params = useParams<{ id: string }>();
  const id = parseInt(params.id, 10);
  const [, navigate] = useLocation();
  const qc = useQueryClient();

  const { data: order, isLoading } = useGetOrder(id, { query: { enabled: !!id, queryKey: getGetOrderQueryKey(id) } });
  const { data: costs } = useListCosts({ orderId: id });
  const { data: incidents } = useListIncidents({ orderId: id });
  const { data: drivers } = useListDrivers();
  const { data: vehicles } = useListVehicles();
  const { data: routes } = useListRoutes();
  const updateMutation = useUpdateOrder();

  const [editing, setEditing] = useState(false);
  const [form, setForm] = useState<Record<string, unknown>>({});

  const startEdit = () => {
    if (!order) return;
    setForm({
      clientName: order.clientName, origin: order.origin, destination: order.destination,
      cargoType: order.cargoType, weightKg: order.weightKg, status: order.status,
      routeId: order.routeId, driverId: order.driverId, vehicleId: order.vehicleId,
      scheduledDate: order.scheduledDate, notes: order.notes,
    });
    setEditing(true);
  };

  const handleSave = () => {
    updateMutation.mutate({ id, data: form as Parameters<typeof updateMutation.mutate>[0]["data"] }, {
      onSuccess: () => {
        qc.invalidateQueries({ queryKey: getGetOrderQueryKey(id) });
        qc.invalidateQueries({ queryKey: getListOrdersQueryKey() });
        setEditing(false);
        toast.success("Order updated");
      },
      onError: () => toast.error("Failed to update order"),
    });
  };

  if (isLoading) return (
    <div className="space-y-6">
      <Skeleton className="h-10 w-48" />
      <Skeleton className="h-64 w-full" />
    </div>
  );

  if (!order) return (
    <div className="flex flex-col items-center justify-center py-24 text-muted-foreground font-mono">
      <p className="text-xl">Order not found</p>
      <Button variant="outline" className="mt-4 font-mono" onClick={() => navigate("/orders")}>Back to Orders</Button>
    </div>
  );

  const set = (k: string, v: unknown) => setForm(f => ({ ...f, [k]: v }));

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="icon" onClick={() => navigate("/orders")}>
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <div>
          <h1 className="text-3xl font-mono font-bold tracking-tight uppercase">{order.orderNumber}</h1>
          <p className="text-muted-foreground font-mono text-sm">{order.clientName}</p>
        </div>
        <div className="ml-auto flex items-center gap-2">
          <span className={`px-3 py-1 rounded-sm border text-sm font-mono uppercase font-medium ${STATUS_COLORS[order.status] ?? "bg-muted"}`}>{order.status}</span>
          {editing ? (
            <>
              <Button variant="outline" onClick={() => setEditing(false)} className="font-mono">Cancel</Button>
              <Button onClick={handleSave} className="font-mono"><Save className="h-4 w-4 mr-2" /> Save</Button>
            </>
          ) : (
            <Button onClick={startEdit} className="font-mono">Edit Order</Button>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader><CardTitle className="font-mono uppercase text-sm tracking-wider">Order Details</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            {editing ? (
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <Label className="font-mono text-xs uppercase">Client</Label>
                  <Input value={form.clientName as string} onChange={e => set("clientName", e.target.value)} className="font-mono" />
                </div>
                <div className="space-y-1">
                  <Label className="font-mono text-xs uppercase">Cargo Type</Label>
                  <Input value={form.cargoType as string} onChange={e => set("cargoType", e.target.value)} className="font-mono" />
                </div>
                <div className="space-y-1">
                  <Label className="font-mono text-xs uppercase">Origin</Label>
                  <Input value={form.origin as string} onChange={e => set("origin", e.target.value)} className="font-mono" />
                </div>
                <div className="space-y-1">
                  <Label className="font-mono text-xs uppercase">Destination</Label>
                  <Input value={form.destination as string} onChange={e => set("destination", e.target.value)} className="font-mono" />
                </div>
                <div className="space-y-1">
                  <Label className="font-mono text-xs uppercase">Weight (kg)</Label>
                  <Input type="number" value={form.weightKg as number} onChange={e => set("weightKg", parseFloat(e.target.value))} className="font-mono" />
                </div>
                <div className="space-y-1">
                  <Label className="font-mono text-xs uppercase">Status</Label>
                  <Select value={form.status as string} onValueChange={v => set("status", v)}>
                    <SelectTrigger className="font-mono"><SelectValue /></SelectTrigger>
                    <SelectContent>{STATUSES.map(s => <SelectItem key={s} value={s} className="font-mono">{s}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
                <div className="space-y-1">
                  <Label className="font-mono text-xs uppercase">Route</Label>
                  <Select value={(form.routeId as number | null | undefined)?.toString() ?? "none"} onValueChange={v => set("routeId", v === "none" ? null : parseInt(v))}>
                    <SelectTrigger className="font-mono"><SelectValue placeholder="None" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none" className="font-mono">None</SelectItem>
                      {routes?.map(r => <SelectItem key={r.id} value={r.id.toString()} className="font-mono">{r.name}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1">
                  <Label className="font-mono text-xs uppercase">Driver</Label>
                  <Select value={(form.driverId as number | null | undefined)?.toString() ?? "none"} onValueChange={v => set("driverId", v === "none" ? null : parseInt(v))}>
                    <SelectTrigger className="font-mono"><SelectValue placeholder="None" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none" className="font-mono">None</SelectItem>
                      {drivers?.map(d => <SelectItem key={d.id} value={d.id.toString()} className="font-mono">{d.fullName}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1">
                  <Label className="font-mono text-xs uppercase">Vehicle</Label>
                  <Select value={(form.vehicleId as number | null | undefined)?.toString() ?? "none"} onValueChange={v => set("vehicleId", v === "none" ? null : parseInt(v))}>
                    <SelectTrigger className="font-mono"><SelectValue placeholder="None" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none" className="font-mono">None</SelectItem>
                      {vehicles?.map(v => <SelectItem key={v.id} value={v.id.toString()} className="font-mono">{v.plate}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1">
                  <Label className="font-mono text-xs uppercase">Scheduled Date</Label>
                  <Input type="date" value={(form.scheduledDate as string) ?? ""} onChange={e => set("scheduledDate", e.target.value)} className="font-mono" />
                </div>
                <div className="col-span-2 space-y-1">
                  <Label className="font-mono text-xs uppercase">Notes</Label>
                  <Textarea value={(form.notes as string) ?? ""} onChange={e => set("notes", e.target.value)} className="font-mono" rows={2} />
                </div>
              </div>
            ) : (
              <dl className="grid grid-cols-2 gap-x-4 gap-y-3 text-sm">
                {[
                  ["Client", order.clientName],
                  ["Cargo Type", order.cargoType],
                  ["Origin", order.origin],
                  ["Destination", order.destination],
                  ["Weight", `${Number(order.weightKg).toLocaleString()} kg`],
                  ["Scheduled", order.scheduledDate ?? "—"],
                  ["Total Cost", order.totalCost != null ? formatCurrency(Number(order.totalCost)) : "—"],
                  ["Created", formatShortDate(order.createdAt)],
                ].map(([k, v]) => (
                  <div key={k}>
                    <dt className="font-mono text-xs uppercase text-muted-foreground">{k}</dt>
                    <dd className="font-mono mt-0.5">{v}</dd>
                  </div>
                ))}
                {order.notes && (
                  <div className="col-span-2">
                    <dt className="font-mono text-xs uppercase text-muted-foreground">Notes</dt>
                    <dd className="font-mono mt-0.5 text-muted-foreground">{order.notes}</dd>
                  </div>
                )}
              </dl>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle className="font-mono uppercase text-sm tracking-wider">Associated Costs</CardTitle></CardHeader>
          <CardContent>
            {!costs || costs.length === 0 ? (
              <p className="text-muted-foreground font-mono text-sm py-4">No costs logged for this order</p>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow className="border-border">
                    <TableHead className="font-mono uppercase text-xs">Type</TableHead>
                    <TableHead className="font-mono uppercase text-xs">Amount</TableHead>
                    <TableHead className="font-mono uppercase text-xs">Date</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {costs.map(c => (
                    <TableRow key={c.id} className="border-border">
                      <TableCell className="font-mono text-xs uppercase">{c.type}</TableCell>
                      <TableCell className="font-mono text-xs text-primary">{formatCurrency(Number(c.amount), c.currency)}</TableCell>
                      <TableCell className="font-mono text-xs text-muted-foreground">{c.date}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader><CardTitle className="font-mono uppercase text-sm tracking-wider">Related Incidents</CardTitle></CardHeader>
        <CardContent>
          {!incidents || incidents.length === 0 ? (
            <p className="text-muted-foreground font-mono text-sm py-4">No incidents reported for this order</p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow className="border-border">
                  <TableHead className="font-mono uppercase text-xs">Title</TableHead>
                  <TableHead className="font-mono uppercase text-xs">Type</TableHead>
                  <TableHead className="font-mono uppercase text-xs">Severity</TableHead>
                  <TableHead className="font-mono uppercase text-xs">Status</TableHead>
                  <TableHead className="font-mono uppercase text-xs">Reported</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {incidents.map(i => (
                  <TableRow key={i.id} className="border-border">
                    <TableCell className="font-mono text-sm">{i.title}</TableCell>
                    <TableCell className="font-mono text-xs uppercase text-muted-foreground">{i.type}</TableCell>
                    <TableCell>
                      <span className={`px-2 py-0.5 rounded-sm border text-xs font-mono uppercase font-medium ${SEVERITY_COLORS[i.severity] ?? "bg-muted"}`}>{i.severity}</span>
                    </TableCell>
                    <TableCell className="font-mono text-xs uppercase">{i.status}</TableCell>
                    <TableCell className="font-mono text-xs text-muted-foreground">{formatShortDate(i.reportedAt)}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
