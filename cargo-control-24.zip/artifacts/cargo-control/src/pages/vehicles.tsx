import React, { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import {
  useListVehicles, useCreateVehicle, useUpdateVehicle, useDeleteVehicle,
  getListVehiclesQueryKey
} from "@workspace/api-client-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Plus, Search, Edit, Trash2 } from "lucide-react";
import { toast } from "sonner";

const STATUS_COLORS: Record<string, string> = {
  available: "bg-green-500/20 text-green-400 border-green-500/30",
  in_use: "bg-blue-500/20 text-blue-400 border-blue-500/30",
  maintenance: "bg-yellow-500/20 text-yellow-400 border-yellow-500/30",
  inactive: "bg-red-500/20 text-red-400 border-red-500/30",
};

const STATUSES = ["available", "in_use", "maintenance", "inactive"];
const TYPES = ["truck", "van", "trailer", "tanker"];

type VehicleInput = {
  plate: string; type: string; brand?: string; model?: string;
  year?: number; capacityKg: number; status: string; driverId?: number; notes?: string;
};

function VehicleFormDialog({ open, onOpenChange, initial, onSave }: {
  open: boolean; onOpenChange: (v: boolean) => void;
  initial?: Partial<VehicleInput> & { id?: number }; onSave: (d: VehicleInput) => void;
}) {
  const [form, setForm] = useState<VehicleInput>({
    plate: initial?.plate ?? "", type: initial?.type ?? "truck",
    brand: initial?.brand ?? "", model: initial?.model ?? "",
    year: initial?.year ?? undefined, capacityKg: initial?.capacityKg ?? 0,
    status: initial?.status ?? "available", notes: initial?.notes ?? "",
  });
  const set = (k: keyof VehicleInput, v: unknown) => setForm(f => ({ ...f, [k]: v }));

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-card border-border">
        <DialogHeader><DialogTitle className="font-mono uppercase">{initial?.id ? "Edit Vehicle" : "Add Vehicle"}</DialogTitle></DialogHeader>
        <div className="grid grid-cols-2 gap-4 py-2">
          <div className="space-y-1">
            <Label className="font-mono text-xs uppercase">Plate</Label>
            <Input value={form.plate} onChange={e => set("plate", e.target.value)} className="font-mono" />
          </div>
          <div className="space-y-1">
            <Label className="font-mono text-xs uppercase">Type</Label>
            <Select value={form.type} onValueChange={v => set("type", v)}>
              <SelectTrigger className="font-mono"><SelectValue /></SelectTrigger>
              <SelectContent>{TYPES.map(t => <SelectItem key={t} value={t} className="font-mono">{t}</SelectItem>)}</SelectContent>
            </Select>
          </div>
          <div className="space-y-1">
            <Label className="font-mono text-xs uppercase">Brand</Label>
            <Input value={form.brand ?? ""} onChange={e => set("brand", e.target.value)} className="font-mono" />
          </div>
          <div className="space-y-1">
            <Label className="font-mono text-xs uppercase">Model</Label>
            <Input value={form.model ?? ""} onChange={e => set("model", e.target.value)} className="font-mono" />
          </div>
          <div className="space-y-1">
            <Label className="font-mono text-xs uppercase">Year</Label>
            <Input type="number" value={form.year ?? ""} onChange={e => set("year", e.target.value ? parseInt(e.target.value) : undefined)} className="font-mono" />
          </div>
          <div className="space-y-1">
            <Label className="font-mono text-xs uppercase">Capacity (kg)</Label>
            <Input type="number" value={form.capacityKg} onChange={e => set("capacityKg", parseFloat(e.target.value))} className="font-mono" />
          </div>
          <div className="col-span-2 space-y-1">
            <Label className="font-mono text-xs uppercase">Status</Label>
            <Select value={form.status} onValueChange={v => set("status", v)}>
              <SelectTrigger className="font-mono"><SelectValue /></SelectTrigger>
              <SelectContent>{STATUSES.map(s => <SelectItem key={s} value={s} className="font-mono">{s}</SelectItem>)}</SelectContent>
            </Select>
          </div>
          <div className="col-span-2 space-y-1">
            <Label className="font-mono text-xs uppercase">Notes</Label>
            <Textarea value={form.notes ?? ""} onChange={e => set("notes", e.target.value)} className="font-mono" rows={2} />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)} className="font-mono">Cancel</Button>
          <Button onClick={() => onSave(form)} className="font-mono">Save Vehicle</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

export default function Vehicles() {
  const qc = useQueryClient();
  const { data: vehicles, isLoading } = useListVehicles();
  const createMutation = useCreateVehicle();
  const updateMutation = useUpdateVehicle();
  const deleteMutation = useDeleteVehicle();
  const [search, setSearch] = useState("");
  const [showCreate, setShowCreate] = useState(false);
  const [editItem, setEditItem] = useState<(typeof vehicles extends (infer T)[] | undefined ? T : never) | null>(null);

  const filtered = (vehicles ?? []).filter(v =>
    v.plate.toLowerCase().includes(search.toLowerCase()) ||
    (v.brand ?? "").toLowerCase().includes(search.toLowerCase()) ||
    v.type.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-mono font-bold tracking-tight uppercase">Fleet</h1>
        <Button onClick={() => setShowCreate(true)} className="font-mono uppercase"><Plus className="h-4 w-4 mr-2" /> Add Vehicle</Button>
      </div>
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input placeholder="Search fleet..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9 font-mono" />
      </div>
      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow className="border-border">
                <TableHead className="font-mono uppercase text-xs">Plate</TableHead>
                <TableHead className="font-mono uppercase text-xs">Type</TableHead>
                <TableHead className="font-mono uppercase text-xs">Brand / Model</TableHead>
                <TableHead className="font-mono uppercase text-xs">Year</TableHead>
                <TableHead className="font-mono uppercase text-xs">Capacity</TableHead>
                <TableHead className="font-mono uppercase text-xs">Status</TableHead>
                <TableHead className="w-[80px]"></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                Array.from({ length: 4 }).map((_, i) => (
                  <TableRow key={i}>{Array.from({ length: 7 }).map((_, j) => <TableCell key={j}><Skeleton className="h-5 w-full" /></TableCell>)}</TableRow>
                ))
              ) : filtered.length === 0 ? (
                <TableRow><TableCell colSpan={7} className="text-center text-muted-foreground font-mono py-12">No vehicles found</TableCell></TableRow>
              ) : (
                filtered.map(v => (
                  <TableRow key={v.id} className="border-border hover:bg-muted/5">
                    <TableCell className="font-mono text-primary font-medium">{v.plate}</TableCell>
                    <TableCell className="font-mono text-xs uppercase">{v.type}</TableCell>
                    <TableCell className="font-mono text-xs">{v.brand} {v.model}</TableCell>
                    <TableCell className="font-mono text-xs text-muted-foreground">{v.year ?? "—"}</TableCell>
                    <TableCell className="font-mono text-xs">{Number(v.capacityKg).toLocaleString()} kg</TableCell>
                    <TableCell>
                      <span className={`px-2 py-0.5 rounded-sm border text-xs font-mono uppercase font-medium ${STATUS_COLORS[v.status] ?? "bg-muted text-muted-foreground"}`}>{v.status}</span>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1">
                        <Button variant="ghost" size="icon" onClick={() => setEditItem(v)}><Edit className="h-3.5 w-3.5" /></Button>
                        <Button variant="ghost" size="icon" className="text-destructive hover:text-destructive"
                          onClick={() => { if (!confirm("Delete this vehicle?")) return; deleteMutation.mutate({ id: v.id }, { onSuccess: () => { qc.invalidateQueries({ queryKey: getListVehiclesQueryKey() }); toast.success("Vehicle deleted"); }, onError: () => toast.error("Failed to delete") }); }}>
                          <Trash2 className="h-3.5 w-3.5" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
      <VehicleFormDialog open={showCreate} onOpenChange={setShowCreate} onSave={data => { createMutation.mutate({ data }, { onSuccess: () => { qc.invalidateQueries({ queryKey: getListVehiclesQueryKey() }); setShowCreate(false); toast.success("Vehicle added"); }, onError: () => toast.error("Failed to add vehicle") }); }} />
      {editItem && <VehicleFormDialog open={!!editItem} onOpenChange={() => setEditItem(null)} initial={editItem as Partial<VehicleInput> & { id: number }} onSave={data => { updateMutation.mutate({ id: editItem.id, data }, { onSuccess: () => { qc.invalidateQueries({ queryKey: getListVehiclesQueryKey() }); setEditItem(null); toast.success("Vehicle updated"); }, onError: () => toast.error("Failed to update") }); }} />}
    </div>
  );
}
