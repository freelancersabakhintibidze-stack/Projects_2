import React from "react";
import { useGetDashboardSummary, useGetRecentActivity, useGetCostBreakdown } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { formatCurrency, formatShortDate } from "@/lib/format";
import { Package, Truck, Users, AlertTriangle, Activity } from "lucide-react";
import {
  PieChart,
  Pie,
  Cell,
  ResponsiveContainer,
  Tooltip,
  Legend
} from "recharts";

const COLORS = ['hsl(var(--chart-1))', 'hsl(var(--chart-2))', 'hsl(var(--chart-3))', 'hsl(var(--chart-4))', 'hsl(var(--chart-5))'];

export default function Dashboard() {
  const { data: summary, isLoading: isSummaryLoading } = useGetDashboardSummary();
  const { data: activity, isLoading: isActivityLoading } = useGetRecentActivity();
  const { data: costBreakdown, isLoading: isCostLoading } = useGetCostBreakdown();

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-mono font-bold tracking-tight uppercase">Operational Overview</h1>
      </div>

      {isSummaryLoading || !summary ? (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {[1, 2, 3, 4].map((i) => <Skeleton key={i} className="h-32 w-full rounded-md" />)}
        </div>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground uppercase font-mono">Orders Active</CardTitle>
              <Package className="h-4 w-4 text-primary" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold font-mono">{summary.activeOrders} <span className="text-sm text-muted-foreground font-normal">/ {summary.totalOrders}</span></div>
              <p className="text-xs text-muted-foreground mt-1 font-mono uppercase">
                {summary.pendingOrders} pending, {summary.completedOrders} delivered
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground uppercase font-mono">Fleet Available</CardTitle>
              <Truck className="h-4 w-4 text-primary" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold font-mono">{summary.availableVehicles} <span className="text-sm text-muted-foreground font-normal">/ {summary.totalVehicles}</span></div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground uppercase font-mono">Drivers Available</CardTitle>
              <Users className="h-4 w-4 text-primary" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold font-mono">{summary.availableDrivers} <span className="text-sm text-muted-foreground font-normal">/ {summary.totalDrivers}</span></div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground uppercase font-mono">Open Incidents</CardTitle>
              <AlertTriangle className={`h-4 w-4 ${summary.openIncidents > 0 ? "text-destructive" : "text-muted-foreground"}`} />
            </CardHeader>
            <CardContent>
              <div className={`text-2xl font-bold font-mono ${summary.openIncidents > 0 ? "text-destructive" : ""}`}>{summary.openIncidents}</div>
            </CardContent>
          </Card>
        </div>
      )}

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
        <Card className="col-span-4">
          <CardHeader>
            <CardTitle className="uppercase font-mono text-sm tracking-wider flex items-center gap-2">
              <Activity className="h-4 w-4" /> Activity Feed
            </CardTitle>
          </CardHeader>
          <CardContent>
            {isActivityLoading || !activity ? (
              <div className="space-y-4">
                {[1, 2, 3, 4, 5].map((i) => <Skeleton key={i} className="h-12 w-full" />)}
              </div>
            ) : (
              <div className="space-y-4">
                {activity.map((item) => (
                  <div key={item.id} className="flex items-start gap-4 text-sm border-b border-border pb-4 last:border-0 last:pb-0">
                    <div className="font-mono text-muted-foreground min-w-[100px]">
                      {formatShortDate(item.timestamp)}
                    </div>
                    <div>
                      <span className="font-mono text-primary font-medium mr-2">[{item.type}]</span>
                      <span>{item.description}</span>
                    </div>
                  </div>
                ))}
                {activity.length === 0 && (
                  <div className="text-center text-muted-foreground py-8 font-mono">No recent activity</div>
                )}
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="col-span-3">
          <CardHeader>
            <CardTitle className="uppercase font-mono text-sm tracking-wider flex items-center gap-2">
              Cost Breakdown
            </CardTitle>
          </CardHeader>
          <CardContent>
            {isCostLoading || !costBreakdown ? (
              <Skeleton className="h-[300px] w-full" />
            ) : costBreakdown.length > 0 ? (
              <div className="h-[300px] w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={costBreakdown}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={80}
                      paddingAngle={2}
                      dataKey="total"
                      nameKey="type"
                    >
                      {costBreakdown.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip 
                      formatter={(value: number) => formatCurrency(value)}
                      contentStyle={{ backgroundColor: 'hsl(var(--card))', borderColor: 'hsl(var(--border))' }}
                    />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            ) : (
              <div className="h-[300px] flex items-center justify-center text-muted-foreground font-mono">
                No cost data available
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
