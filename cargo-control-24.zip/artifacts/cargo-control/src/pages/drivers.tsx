import React, { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import {
  useListDrivers, useCreateDriver, useUpdateDriver, useDeleteDriver,
  getListDriversQueryKey
} from "@workspace/api-client-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Plus, Search, Edit, Trash2 } from "lucide-react";
import { toast } from "sonner";

const STATUS_COLORS: Record<string, string> = {
  available: "bg-green-500/20 text-green-400 border-green-500/30",
  on_duty: "bg-blue-500/20 text-blue-400 border-blue-500/30",
  off_duty: "bg-yellow-500/20 text-yellow-400 border-yellow-500/30",
  suspended: "bg-red-500/20 text-red-400 border-red-500/30",
};

const STATUSES = ["available", "on_duty", "off_duty", "suspended"];

type DriverInput = {
  fullName: string; licenseNumber: string; licenseClass?: string;
  phone?: string; email?: string; status: string; vehicleId?: number; notes?: string;
};

function DriverFormDialog({ open, onOpenChange, initial, onSave }: {
  open: boolean; onOpenChange: (v: boolean) => void;
  initial?: Partial<DriverInput> & { id?: number }; onSave: (d: DriverInput) => void;
}) {
  const [form, setForm] = useState<DriverInput>({
    fullName: initial?.fullName ?? "", licenseNumber: initial?.licenseNumber ?? "",
    licenseClass: initial?.licenseClass ?? "", phone: initial?.phone ?? "",
    email: initial?.email ?? "", status: initial?.status ?? "available", notes: initial?.notes ?? "",
  });
  const set = (k: keyof DriverInput, v: unknown) => setForm(f => ({ ...f, [k]: v }));

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-card border-border">
        <DialogHeader><DialogTitle className="font-mono uppercase">{initial?.id ? "Edit Driver" : "Add Driver"}</DialogTitle></DialogHeader>
        <div className="grid grid-cols-2 gap-4 py-2">
          <div className="space-y-1 col-span-2">
            <Label className="font-mono text-xs uppercase">Full Name</Label>
            <Input value={form.fullName} onChange={e => set("fullName", e.target.value)} className="font-mono" />
          </div>
          <div className="space-y-1">
            <Label className="font-mono text-xs uppercase">License Number</Label>
            <Input value={form.licenseNumber} onChange={e => set("licenseNumber", e.target.value)} className="font-mono" />
          </div>
          <div className="space-y-1">
            <Label className="font-mono text-xs uppercase">License Class</Label>
            <Input value={form.licenseClass ?? ""} onChange={e => set("licenseClass", e.target.value)} className="font-mono" placeholder="Class A CDL" />
          </div>
          <div className="space-y-1">
            <Label className="font-mono text-xs uppercase">Phone</Label>
            <Input value={form.phone ?? ""} onChange={e => set("phone", e.target.value)} className="font-mono" />
          </div>
          <div className="space-y-1">
            <Label className="font-mono text-xs uppercase">Email</Label>
            <Input value={form.email ?? ""} onChange={e => set("email", e.target.value)} className="font-mono" />
          </div>
          <div className="col-span-2 space-y-1">
            <Label className="font-mono text-xs uppercase">Status</Label>
            <Select value={form.status} onValueChange={v => set("status", v)}>
              <SelectTrigger className="font-mono"><SelectValue /></SelectTrigger>
              <SelectContent>{STATUSES.map(s => <SelectItem key={s} value={s} className="font-mono">{s}</SelectItem>)}</SelectContent>
            </Select>
          </div>
          <div className="col-span-2 space-y-1">
            <Label className="font-mono text-xs uppercase">Notes</Label>
            <Textarea value={form.notes ?? ""} onChange={e => set("notes", e.target.value)} className="font-mono" rows={2} />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)} className="font-mono">Cancel</Button>
          <Button onClick={() => onSave(form)} className="font-mono">Save Driver</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

export default function Drivers() {
  const qc = useQueryClient();
  const { data: drivers, isLoading } = useListDrivers();
  const createMutation = useCreateDriver();
  const updateMutation = useUpdateDriver();
  const deleteMutation = useDeleteDriver();
  const [search, setSearch] = useState("");
  const [showCreate, setShowCreate] = useState(false);
  const [editItem, setEditItem] = useState<(typeof drivers extends (infer T)[] | undefined ? T : never) | null>(null);

  const filtered = (drivers ?? []).filter(d =>
    d.fullName.toLowerCase().includes(search.toLowerCase()) ||
    d.licenseNumber.toLowerCase().includes(search.toLowerCase()) ||
    (d.phone ?? "").includes(search)
  );

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-mono font-bold tracking-tight uppercase">Drivers</h1>
        <Button onClick={() => setShowCreate(true)} className="font-mono uppercase"><Plus className="h-4 w-4 mr-2" /> Add Driver</Button>
      </div>
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input placeholder="Search drivers..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9 font-mono" />
      </div>
      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow className="border-border">
                <TableHead className="font-mono uppercase text-xs">Name</TableHead>
                <TableHead className="font-mono uppercase text-xs">License</TableHead>
                <TableHead className="font-mono uppercase text-xs">Class</TableHead>
                <TableHead className="font-mono uppercase text-xs">Phone</TableHead>
                <TableHead className="font-mono uppercase text-xs">Email</TableHead>
                <TableHead className="font-mono uppercase text-xs">Status</TableHead>
                <TableHead className="w-[80px]"></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                Array.from({ length: 4 }).map((_, i) => (
                  <TableRow key={i}>{Array.from({ length: 7 }).map((_, j) => <TableCell key={j}><Skeleton className="h-5 w-full" /></TableCell>)}</TableRow>
                ))
              ) : filtered.length === 0 ? (
                <TableRow><TableCell colSpan={7} className="text-center text-muted-foreground font-mono py-12">No drivers found</TableCell></TableRow>
              ) : (
                filtered.map(d => (
                  <TableRow key={d.id} className="border-border hover:bg-muted/5">
                    <TableCell className="font-mono font-medium">{d.fullName}</TableCell>
                    <TableCell className="font-mono text-xs text-primary">{d.licenseNumber}</TableCell>
                    <TableCell className="font-mono text-xs text-muted-foreground">{d.licenseClass ?? "—"}</TableCell>
                    <TableCell className="font-mono text-xs">{d.phone ?? "—"}</TableCell>
                    <TableCell className="font-mono text-xs text-muted-foreground">{d.email ?? "—"}</TableCell>
                    <TableCell>
                      <span className={`px-2 py-0.5 rounded-sm border text-xs font-mono uppercase font-medium ${STATUS_COLORS[d.status] ?? "bg-muted text-muted-foreground"}`}>{d.status}</span>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1">
                        <Button variant="ghost" size="icon" onClick={() => setEditItem(d)}><Edit className="h-3.5 w-3.5" /></Button>
                        <Button variant="ghost" size="icon" className="text-destructive hover:text-destructive"
                          onClick={() => { if (!confirm("Delete this driver?")) return; deleteMutation.mutate({ id: d.id }, { onSuccess: () => { qc.invalidateQueries({ queryKey: getListDriversQueryKey() }); toast.success("Driver deleted"); }, onError: () => toast.error("Failed") }); }}>
                          <Trash2 className="h-3.5 w-3.5" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
      <DriverFormDialog open={showCreate} onOpenChange={setShowCreate} onSave={data => { createMutation.mutate({ data }, { onSuccess: () => { qc.invalidateQueries({ queryKey: getListDriversQueryKey() }); setShowCreate(false); toast.success("Driver added"); }, onError: () => toast.error("Failed") }); }} />
      {editItem && <DriverFormDialog open={!!editItem} onOpenChange={() => setEditItem(null)} initial={editItem as Partial<DriverInput> & { id: number }} onSave={data => { updateMutation.mutate({ id: editItem.id, data }, { onSuccess: () => { qc.invalidateQueries({ queryKey: getListDriversQueryKey() }); setEditItem(null); toast.success("Updated"); }, onError: () => toast.error("Failed") }); }} />}
    </div>
  );
}
