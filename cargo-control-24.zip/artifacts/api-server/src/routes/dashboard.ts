import { Router, type IRouter } from "express";
import { eq, count, sql } from "drizzle-orm";
import { db, ordersTable, vehiclesTable, driversTable, incidentsTable, costsTable } from "@workspace/db";
import {
  GetDashboardSummaryResponse,
  GetRecentActivityResponse,
  GetCostBreakdownResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/dashboard/summary", async (_req, res): Promise<void> => {
  const [orderStats] = await db.select({
    total: count(),
    active: sql<number>`COUNT(*) FILTER (WHERE status = 'in_transit')`,
    completed: sql<number>`COUNT(*) FILTER (WHERE status = 'delivered')`,
    pending: sql<number>`COUNT(*) FILTER (WHERE status = 'pending')`,
  }).from(ordersTable);

  const [vehicleStats] = await db.select({
    total: count(),
    available: sql<number>`COUNT(*) FILTER (WHERE status = 'available')`,
  }).from(vehiclesTable);

  const [driverStats] = await db.select({
    total: count(),
    available: sql<number>`COUNT(*) FILTER (WHERE status = 'available')`,
  }).from(driversTable);

  const [incidentStats] = await db.select({
    open: sql<number>`COUNT(*) FILTER (WHERE status != 'resolved')`,
  }).from(incidentsTable);

  const [costStats] = await db.select({
    total: sql<number>`COALESCE(SUM(amount), 0)`,
  }).from(costsTable);

  const [revenueStats] = await db.select({
    total: sql<number>`COALESCE(SUM(total_cost), 0)`,
  }).from(ordersTable).where(eq(ordersTable.status, "delivered"));

  const summary = {
    totalOrders: Number(orderStats?.total ?? 0),
    activeOrders: Number(orderStats?.active ?? 0),
    completedOrders: Number(orderStats?.completed ?? 0),
    pendingOrders: Number(orderStats?.pending ?? 0),
    totalVehicles: Number(vehicleStats?.total ?? 0),
    availableVehicles: Number(vehicleStats?.available ?? 0),
    totalDrivers: Number(driverStats?.total ?? 0),
    availableDrivers: Number(driverStats?.available ?? 0),
    openIncidents: Number(incidentStats?.open ?? 0),
    totalRevenue: parseFloat(String(revenueStats?.total ?? 0)),
    totalCosts: parseFloat(String(costStats?.total ?? 0)),
  };

  res.json(GetDashboardSummaryResponse.parse(summary));
});

router.get("/dashboard/recent-activity", async (_req, res): Promise<void> => {
  const recentOrders = await db.select().from(ordersTable).orderBy(sql`created_at DESC`).limit(5);
  const recentIncidents = await db.select().from(incidentsTable).orderBy(sql`reported_at DESC`).limit(3);

  const activities = [
    ...recentOrders.map((o) => ({
      id: o.id,
      type: "order",
      description: `Order ${o.orderNumber} (${o.clientName}) — ${o.status}`,
      entityId: o.id,
      timestamp: o.createdAt.toISOString(),
    })),
    ...recentIncidents.map((i) => ({
      id: i.id + 10000,
      type: "incident",
      description: `Incident: ${i.title} — ${i.severity} severity`,
      entityId: i.id,
      timestamp: i.reportedAt.toISOString(),
    })),
  ].sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()).slice(0, 8);

  res.json(GetRecentActivityResponse.parse(activities));
});

router.get("/dashboard/cost-breakdown", async (_req, res): Promise<void> => {
  const breakdown = await db.select({
    type: costsTable.type,
    total: sql<number>`SUM(amount)`,
    count: count(),
  }).from(costsTable).groupBy(costsTable.type);

  const result = breakdown.map((b) => ({
    type: b.type,
    total: parseFloat(String(b.total ?? 0)),
    count: Number(b.count),
  }));

  res.json(GetCostBreakdownResponse.parse(result));
});

export default router;
