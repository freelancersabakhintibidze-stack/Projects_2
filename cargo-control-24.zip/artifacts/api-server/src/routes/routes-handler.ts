import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import { db, routesTable } from "@workspace/db";
import {
  ListRoutesResponse,
  CreateRouteBody,
  CreateRouteResponse,
  GetRouteParams,
  GetRouteResponse,
  UpdateRouteParams,
  UpdateRouteBody,
  UpdateRouteResponse,
  DeleteRouteParams,
} from "@workspace/api-zod";

const router: IRouter = Router();

function toRouteResponse(row: typeof routesTable.$inferSelect) {
  return {
    ...row,
    distanceKm: parseFloat(row.distanceKm as unknown as string),
    estimatedHours: row.estimatedHours != null ? parseFloat(row.estimatedHours as unknown as string) : null,
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
  };
}

router.get("/routes", async (_req, res): Promise<void> => {
  const routes = await db.select().from(routesTable).orderBy(routesTable.createdAt);
  res.json(ListRoutesResponse.parse(routes.map(toRouteResponse)));
});

router.post("/routes", async (req, res): Promise<void> => {
  const parsed = CreateRouteBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [route] = await db.insert(routesTable).values({
    ...parsed.data,
    status: parsed.data.status ?? "active",
  }).returning();

  res.status(201).json(CreateRouteResponse.parse(toRouteResponse(route)));
});

router.get("/routes/:id", async (req, res): Promise<void> => {
  const params = GetRouteParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [route] = await db.select().from(routesTable).where(eq(routesTable.id, params.data.id));
  if (!route) {
    res.status(404).json({ error: "Route not found" });
    return;
  }

  res.json(GetRouteResponse.parse(toRouteResponse(route)));
});

router.patch("/routes/:id", async (req, res): Promise<void> => {
  const params = UpdateRouteParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const parsed = UpdateRouteBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [route] = await db.update(routesTable).set(parsed.data).where(eq(routesTable.id, params.data.id)).returning();
  if (!route) {
    res.status(404).json({ error: "Route not found" });
    return;
  }

  res.json(UpdateRouteResponse.parse(toRouteResponse(route)));
});

router.delete("/routes/:id", async (req, res): Promise<void> => {
  const params = DeleteRouteParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [route] = await db.delete(routesTable).where(eq(routesTable.id, params.data.id)).returning();
  if (!route) {
    res.status(404).json({ error: "Route not found" });
    return;
  }

  res.sendStatus(204);
});

export default router;
