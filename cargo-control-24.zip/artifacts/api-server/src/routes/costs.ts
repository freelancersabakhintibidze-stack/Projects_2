import { Router, type IRouter } from "express";
import { eq, and } from "drizzle-orm";
import { db, costsTable } from "@workspace/db";
import {
  ListCostsQueryParams,
  ListCostsResponse,
  CreateCostBody,
  CreateCostResponse,
  GetCostParams,
  GetCostResponse,
  UpdateCostParams,
  UpdateCostBody,
  UpdateCostResponse,
  DeleteCostParams,
} from "@workspace/api-zod";

const router: IRouter = Router();

function toCostResponse(row: typeof costsTable.$inferSelect) {
  return {
    ...row,
    amount: parseFloat(row.amount as unknown as string),
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
  };
}

router.get("/costs", async (req, res): Promise<void> => {
  const query = ListCostsQueryParams.safeParse(req.query);
  if (!query.success) {
    res.status(400).json({ error: query.error.message });
    return;
  }

  let dbQuery = db.select().from(costsTable);
  const conditions = [];
  if (query.data.orderId) conditions.push(eq(costsTable.orderId, query.data.orderId));
  if (query.data.type) conditions.push(eq(costsTable.type, query.data.type));

  const costs = conditions.length > 0
    ? await dbQuery.where(and(...conditions)).orderBy(costsTable.date)
    : await dbQuery.orderBy(costsTable.date);

  res.json(ListCostsResponse.parse(costs.map(toCostResponse)));
});

router.post("/costs", async (req, res): Promise<void> => {
  const parsed = CreateCostBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [cost] = await db.insert(costsTable).values({
    ...parsed.data,
    currency: parsed.data.currency ?? "USD",
  }).returning();

  res.status(201).json(CreateCostResponse.parse(toCostResponse(cost)));
});

router.get("/costs/:id", async (req, res): Promise<void> => {
  const params = GetCostParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [cost] = await db.select().from(costsTable).where(eq(costsTable.id, params.data.id));
  if (!cost) {
    res.status(404).json({ error: "Cost not found" });
    return;
  }

  res.json(GetCostResponse.parse(toCostResponse(cost)));
});

router.patch("/costs/:id", async (req, res): Promise<void> => {
  const params = UpdateCostParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const parsed = UpdateCostBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [cost] = await db.update(costsTable).set(parsed.data).where(eq(costsTable.id, params.data.id)).returning();
  if (!cost) {
    res.status(404).json({ error: "Cost not found" });
    return;
  }

  res.json(UpdateCostResponse.parse(toCostResponse(cost)));
});

router.delete("/costs/:id", async (req, res): Promise<void> => {
  const params = DeleteCostParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [cost] = await db.delete(costsTable).where(eq(costsTable.id, params.data.id)).returning();
  if (!cost) {
    res.status(404).json({ error: "Cost not found" });
    return;
  }

  res.sendStatus(204);
});

export default router;
