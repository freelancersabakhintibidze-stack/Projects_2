import { Router, type IRouter } from "express";
import healthRouter from "./health";
import ordersRouter from "./orders";
import vehiclesRouter from "./vehicles";
import driversRouter from "./drivers";
import routesHandlerRouter from "./routes-handler";
import costsRouter from "./costs";
import incidentsRouter from "./incidents";
import dashboardRouter from "./dashboard";

const router: IRouter = Router();

router.use(healthRouter);
router.use(ordersRouter);
router.use(vehiclesRouter);
router.use(driversRouter);
router.use(routesHandlerRouter);
router.use(costsRouter);
router.use(incidentsRouter);
router.use(dashboardRouter);

export default router;
