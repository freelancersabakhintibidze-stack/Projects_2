import { Router, type IRouter } from "express";
import { eq, and } from "drizzle-orm";
import { db, incidentsTable } from "@workspace/db";
import {
  ListIncidentsQueryParams,
  ListIncidentsResponse,
  CreateIncidentBody,
  CreateIncidentResponse,
  GetIncidentParams,
  GetIncidentResponse,
  UpdateIncidentParams,
  UpdateIncidentBody,
  UpdateIncidentResponse,
  DeleteIncidentParams,
} from "@workspace/api-zod";

const router: IRouter = Router();

function toIncidentResponse(row: typeof incidentsTable.$inferSelect) {
  return {
    ...row,
    reportedAt: row.reportedAt.toISOString(),
    resolvedAt: row.resolvedAt ? row.resolvedAt.toISOString() : null,
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
  };
}

router.get("/incidents", async (req, res): Promise<void> => {
  const query = ListIncidentsQueryParams.safeParse(req.query);
  if (!query.success) {
    res.status(400).json({ error: query.error.message });
    return;
  }

  let dbQuery = db.select().from(incidentsTable);
  const conditions = [];
  if (query.data.severity) conditions.push(eq(incidentsTable.severity, query.data.severity));
  if (query.data.status) conditions.push(eq(incidentsTable.status, query.data.status));
  if (query.data.orderId) conditions.push(eq(incidentsTable.orderId, query.data.orderId));

  const incidents = conditions.length > 0
    ? await dbQuery.where(and(...conditions)).orderBy(incidentsTable.reportedAt)
    : await dbQuery.orderBy(incidentsTable.reportedAt);

  res.json(ListIncidentsResponse.parse(incidents.map(toIncidentResponse)));
});

router.post("/incidents", async (req, res): Promise<void> => {
  const parsed = CreateIncidentBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const reportedAt = parsed.data.reportedAt ? new Date(parsed.data.reportedAt) : new Date();
  const [incident] = await db.insert(incidentsTable).values({
    ...parsed.data,
    status: parsed.data.status ?? "open",
    reportedAt,
  }).returning();

  res.status(201).json(CreateIncidentResponse.parse(toIncidentResponse(incident)));
});

router.get("/incidents/:id", async (req, res): Promise<void> => {
  const params = GetIncidentParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [incident] = await db.select().from(incidentsTable).where(eq(incidentsTable.id, params.data.id));
  if (!incident) {
    res.status(404).json({ error: "Incident not found" });
    return;
  }

  res.json(GetIncidentResponse.parse(toIncidentResponse(incident)));
});

router.patch("/incidents/:id", async (req, res): Promise<void> => {
  const params = UpdateIncidentParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const parsed = UpdateIncidentBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const updateData: Record<string, unknown> = { ...parsed.data };
  if (parsed.data.resolvedAt != null) {
    updateData.resolvedAt = new Date(parsed.data.resolvedAt);
  }

  const [incident] = await db.update(incidentsTable).set(updateData).where(eq(incidentsTable.id, params.data.id)).returning();
  if (!incident) {
    res.status(404).json({ error: "Incident not found" });
    return;
  }

  res.json(UpdateIncidentResponse.parse(toIncidentResponse(incident)));
});

router.delete("/incidents/:id", async (req, res): Promise<void> => {
  const params = DeleteIncidentParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [incident] = await db.delete(incidentsTable).where(eq(incidentsTable.id, params.data.id)).returning();
  if (!incident) {
    res.status(404).json({ error: "Incident not found" });
    return;
  }

  res.sendStatus(204);
});

export default router;
