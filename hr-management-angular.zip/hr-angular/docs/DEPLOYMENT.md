# Deployment Guide — HR სისტემა

## Prerequisites

| Tool | Min Version | Purpose |
|------|------------|---------|
| Node.js | 20.x | Build |
| npm | 10.x | Package manager |
| Docker | 24.x | Container runtime |
| Docker Compose | 2.x | Multi-container orchestration |

---

## Option 1 — Local Development (no Docker)

```bash
git clone <repo>
cd hr-angular
npm ci
npm start          # ng serve → http://localhost:4200
```

### Demo login credentials
| Role | Username | Password |
|------|----------|----------|
| HR Admin | `admin` | `admin123` |
| Employee | `user` | `user123` |

---

## Option 2 — Docker (recommended for staging/prod)

### Build and run
```bash
# Copy environment file
cp .env.example .env

# Build production image and start
docker compose up --build -d

# View logs
docker compose logs -f

# Stop
docker compose down
```

App is available at: **http://localhost:8080**

### Development with hot-reload inside Docker
```bash
docker compose -f docker-compose.yml -f docker-compose.dev.yml up
```

---

## Option 3 — Static hosting (Netlify / Vercel / S3 + CloudFront)

```bash
npm ci
npm run build -- --configuration production
# Upload dist/hr-management/browser/ to your host
```

**Important:** Configure your host to redirect all 404s to `index.html`  
(Angular Router handles client-side routing).

### Netlify
Create `public/_redirects`:
```
/*  /index.html  200
```

### Apache
Create `dist/hr-management/browser/.htaccess`:
```apache
RewriteEngine On
RewriteCond %{REQUEST_FILENAME} !-f
RewriteRule ^ /index.html [QSA,L]
```

---

## CI/CD Pipeline (GitHub Actions)

| Job | Trigger | Steps |
|-----|---------|-------|
| `quality` | All pushes / PRs | Lint → `npm audit` → Semgrep SAST |
| `build-and-test` | After `quality` | Unit tests → Coverage → Production build |
| `docker` | `main` branch only | Trivy scan → Docker build → Push to Docker Hub |

### Required GitHub Secrets

| Secret | Description |
|--------|-------------|
| `DOCKER_USERNAME` | Docker Hub username |
| `DOCKER_PASSWORD` | Docker Hub access token |

---

## Environment Configuration

Angular environments are **compile-time** — there are no runtime `.env` variables inside the Angular SPA. The `fileReplacements` in `angular.json` swap:

```
src/environments/environment.ts        → development build
src/environments/environment.prod.ts  → production build  (ng build --configuration production)
```

To add a real runtime config (e.g. API URL), create `src/assets/config.json` and fetch it in `APP_INITIALIZER`.

---

## Nginx Security Headers

The production container (nginx) sets the following headers on every response:

| Header | Value |
|--------|-------|
| `X-Frame-Options` | `DENY` |
| `X-Content-Type-Options` | `nosniff` |
| `X-XSS-Protection` | `1; mode=block` |
| `Referrer-Policy` | `strict-origin-when-cross-origin` |
| `Content-Security-Policy` | `default-src 'self'; script-src 'self'; ...` |
| `Permissions-Policy` | `camera=(), microphone=(), geolocation=()` |

**HSTS** is commented out by default. Enable it only after TLS is terminated upstream:
```nginx
add_header Strict-Transport-Security "max-age=31536000; includeSubDomains; preload" always;
```

---

## Health Check

```bash
curl http://localhost:8080/health
# → {"status":"ok"}
```

Used by Docker healthcheck and load balancer readiness probes.

---

## Backup & Restore

All data lives in the **browser's `localStorage`** — it is user-scoped and never leaves the browser.

### Export (in-app)
`Settings → JSON ჩამოტვირთვა` — downloads a `hr-backup-<date>.json` file.

### Import (in-app)
`Settings → JSON ატვირთვა` — restores from a previously exported JSON.

### Reset to seed data (in-app)
`Settings → გადაყენება` — wipes current data and restores the 15-employee seed dataset.

---

## Monitoring & Observability

| Concern | Implementation |
|---------|---------------|
| Error tracking | `GlobalErrorHandler` — dev: `console.error`; prod: user-facing toast |
| Structured logs | nginx access logs in JSON-file driver (Docker) |
| Log rotation | Docker log driver: `max-size=10m, max-file=3` |
| Health check | `GET /health` → 200 `{"status":"ok"}` |
| Coverage reports | Karma → lcov → Codecov (CI) |
