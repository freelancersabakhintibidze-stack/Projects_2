# HR სისტემა — Architecture Documentation

## Overview

A production-grade, single-page HR Management application built with Angular 17. All data is persisted in the browser's `localStorage` through a bulletproof `StorageService`. No backend server is required — the application ships as a set of static files served by nginx inside Docker.

---

## Data Flow

```
Browser (Angular SPA)
        │
        ▼
  AuthService (Signal)  ──►  sessionStorage  (session only)
        │
        ▼
  Route Guards
  authGuard ──► /login redirect if unauthenticated
  roleGuard ──► /dashboard redirect if insufficient role
        │
        ▼
  Feature Components  (OnPush, lazy-loaded)
        │
        ├──► EmployeeService  ──┐
        ├──► DepartmentService  ├──► StorageService ──► localStorage
        ├──► PositionService    │         │
        └──► VacationService  ──┘         └── try/catch + QuotaExceeded
                                                     │
                                               GlobalErrorHandler
                                                     │
                                               ToastService (Signal)
```

---

## Key Design Decisions

| Decision | Rationale |
|----------|-----------|
| **Standalone components** | No NgModules → smaller bundles, direct dependency declaration |
| **ChangeDetectionStrategy.OnPush** | Reduces CD cycles from O(tree) to O(dirty path) |
| **Angular Signals** for auth & toast | Avoid boilerplate subscriptions in reactive primitives |
| **BehaviorSubject** for entity services | Multicasting state with synchronous `.value` access |
| **localStorage** (not IndexedDB) | Synchronous API — no async complexity for 15-employee seed |
| **sessionStorage** for auth session | Session ends on tab close — no persistent login tokens |
| **Lazy-loaded routes** | Initial bundle ~80 KB; each feature chunk loaded on demand |
| **Mock auth (no backend)** | Simulates real RBAC without requiring a server |

---

## Module & Component Hierarchy

```
AppComponent (root, OnPush)
├── SidebarComponent     (OnPush, role-aware nav)
├── HeaderComponent      (OnPush, user info + logout)
├── RouterOutlet
│   ├── LoginComponent           [/login]
│   ├── DashboardComponent       [/dashboard]
│   ├── EmployeeListComponent    [/employees]
│   ├── EmployeeFormComponent    [/employees/new, /employees/:id/edit]
│   ├── EmployeeDetailsComponent [/employees/:id]
│   ├── DepartmentsComponent     [/departments]
│   ├── PositionsComponent       [/positions]
│   ├── VacationsComponent       [/vacations]
│   ├── SettingsComponent        [/settings]
│   └── NotFoundComponent        [/**]
└── ToastComponent       (Signal-driven, OnPush)
```

---

## Security Model

### Authentication
- Mock credential store in `AuthService` (replaces a real auth endpoint)
- Session stored in `sessionStorage` — destroyed when the tab closes
- `AuthGuard` (`CanActivateFn`) redirects unauthenticated users to `/login` with `returnUrl`

### Role-Based Access Control (RBAC)
| Role | Accessible Routes |
|------|------------------|
| `hr_admin` | All routes |
| `employee` | `/dashboard`, `/employees` (read), `/employees/:id` (read), `/vacations` |

### Row-Level Security (RLS) on Vacations
- Employees can only **submit** vacations for their own `employeeId`
- Employees cannot **approve/reject** any vacation (admin-only action)
- Enforced in `AuthService.canEditVacation()` and checked in `VacationsComponent`

### Input Sanitisation
- All user input goes through Angular Reactive Forms with strict validators
- No `innerHTML` or `bypassSecurityTrust*` calls — Angular's built-in template escaping applies everywhere
- `StorageService` JSON-parses within `try/catch` — malformed data returns `[]` instead of crashing

---

## Failure Modes & Recovery

| Failure | Behaviour |
|---------|-----------|
| `localStorage` quota exceeded | `StorageService.safeSet()` throws; caught by `GlobalErrorHandler`; user sees toast |
| Corrupted `localStorage` JSON | `parse<T>()` returns `null`; service falls back to `[]` |
| Unauthenticated navigation | `authGuard` redirects to `/login?returnUrl=...` |
| Insufficient role | `roleGuard` shows error toast and redirects to `/dashboard` |
| Unknown route | `NotFoundComponent` with link back to dashboard |
| Unhandled JS error | `GlobalErrorHandler` catches, logs (dev only), shows user-friendly toast |

---

## Environment Configuration

| Variable | `environment.ts` | `environment.prod.ts` |
|----------|-----------------|----------------------|
| `production` | `false` | `true` |
| `debug` | `true` | `false` |
| `appVersion` | `1.0.0` | `1.0.0` |

Switched at build time by Angular's `fileReplacements` in `angular.json`.  
In `production` mode: `GlobalErrorHandler` shows generic messages instead of stack traces.

---

## Performance Characteristics

- **Initial load:** ~80–120 KB gzipped (Angular framework + root chunk)
- **Per-feature chunk:** ~15–40 KB gzipped (lazy-loaded on first navigation)
- **Change detection:** OnPush on every component → no unnecessary re-renders
- **`@for` loops:** All use `track item.id` — O(1) DOM patch on list updates
- **nginx gzip:** All JS/CSS served compressed at level 6
- **Static asset caching:** `1y` + `immutable` on hashed filenames
