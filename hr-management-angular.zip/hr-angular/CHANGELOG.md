# Changelog

All notable changes to HR სისტემა follow [Semantic Versioning](https://semver.org/).

---

## [1.1.0] — 2026-07-19

### Added
- **Auth system** — `AuthService` (Angular Signals), `AuthGuard`, `RoleGuard` factory
- **Login page** — public route with demo credentials displayed
- **GlobalErrorHandler** — catches all unhandled errors; production mode shows generic message
- **Environment configs** — `environment.ts` / `environment.prod.ts` with build-time file replacement
- **Row-Level Security** — employees can only manage their own vacations
- **Production Dockerfile** — multi-stage Node.js build → nginx:alpine
- **docker-compose.yml** + **docker-compose.dev.yml**
- **nginx.conf** — security headers, gzip, SPA fallback, health check endpoint
- **Unit tests** — SalaryPipe, GeorgianDatePipe, StorageService, AuthService, authGuard
- **karma.conf.js** — coverage thresholds and ChromeHeadlessCI launcher
- **ESLint** — `.eslintrc.json` replacing the broken flat config
- **CI/CD** — three-job pipeline: quality → build-and-test → docker (main only)
- **docs/ARCHITECTURE.md** — data flow, failure modes, security model
- **docs/DEPLOYMENT.md** — all three deployment options with step-by-step instructions

### Fixed
- **Critical:** `employees/new` route was shadowed by `employees/:id` — route ordering corrected
- **Critical:** `employees/:id/edit` same shadowing issue — fixed
- **Memory leak** in `AppComponent` — `router.events` subscription now uses `takeUntilDestroyed`
- **Missing `ChangeDetectionStrategy.OnPush`** on all four shared components
- **Salary pipe** — `toLocaleString('ka-GE')` was platform-inconsistent; replaced with regex grouping
- **eslint.config.js** — CJS `require()` with ESM packages crashed `ng lint`; replaced with `.eslintrc.json`

### Changed
- Sidebar hides admin-only nav items (Departments, Positions, Settings) for `employee` role
- Header now shows current user name, role badge, and Logout button
- `StorageService` fully wrapped in `try/catch` with `QuotaExceededError` propagation

---

## [1.0.0] — 2026-07-17

### Added
- Initial release — complete HR Management SPA
- Dashboard with stat cards, recent hires, pending vacations, department bar chart
- Employee CRUD — list, add/edit form, details view, cascade delete
- Reactive Forms with Georgian validation messages throughout
- Department management — unique name validation, delete restriction
- Position management — salary range validation, delete restriction
- Vacation management — date overlap check, approve/reject, `onLeave` auto-status
- Settings — JSON export/import/reset with confirm dialog
- 15 seed employees, 4 departments, 5 positions, 5 vacation requests
- Custom pipes: `SalaryPipe` (5200 → "5 200 ₾"), `GeorgianDatePipe` (ISO → dd/MM/yyyy)
- Shared components: ConfirmDialog, StatusBadge, EmptyState, Toast, Sidebar, Header
- Lazy-loaded routes via `loadComponent`
- `ChangeDetectionStrategy.OnPush` on all feature components
- `ToastService` built on Angular Signals
- GitHub Actions CI — lint → build → test
