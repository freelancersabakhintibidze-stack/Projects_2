# HR სისტემა — Angular 17 (Production Edition)

სრული, production-ready შიდა HR მართვის სისტემა, აგებული Angular 17-ით.  
**Full-Stack Production Reality** სტანდარტებით — Auth, Guards, OnPush, GlobalErrorHandler, CI/CD, bulletproof Storage.

> **მთელი ინტერფეისი ქართულ ენაზეა.**

---

## 🚀 გაშვება

```bash
npm install
ng serve          # Development → http://localhost:4200
```

### სადემო მომხმარებლები (პირველი გაშვებისთვის)

| როლი | მომხმარებელი | პაროლი |
|------|-------------|--------|
| 👑 HR ადმინი | `admin` | `admin123` |
| 👤 თანამშრომელი | `user` | `user123` |

---

## ⚙️ სხვა ბრძანებები

```bash
npm run build           # Production build → dist/
ng serve --open         # Dev server + ავტო-გახსნა ბრაუზერში
ng lint                 # ESLint კოდის ხარისხის შემოწმება
ng test                 # Unit ტესტები (Karma + Jasmine)
ng build --configuration production  # prod bundle (env swap)
```

---

## 🏗️ Production Reality Stack

| პრინციპი | განხორციელება |
|----------|--------------|
| **Auth & Permissions** | `AuthService` (Signals) + `AuthGuard` + `RoleGuard` |
| **Row-Level Security** | Employee-only შეუძლია მხოლოდ საკუთარი შვებულება |
| **Error Tracking** | `GlobalErrorHandler` — quota/XSS/unknown errors |
| **Performance** | `ChangeDetectionStrategy.OnPush` ყველა კომპონენტზე |
| **trackBy** | `@for` ყველა loop-ში `track item.id` |
| **Bulletproof Storage** | `try/catch` + `QuotaExceededError` fallback |
| **Environment Configs** | `environment.ts` / `environment.prod.ts` + fileReplacements |
| **CI/CD** | `.github/workflows/ci.yml` (lint + build + test) |
| **Zero `any`** | TypeScript strict mode, ყველგან typed |
| **No console.log** | `environment.debug` flag გვარიგებს log-ებს |

---

## 📦 ტექნოლოგიური სტეკი

| ფენა | ტექნოლოგია |
|------|-----------|
| Framework | **Angular 17** (Standalone Components) |
| ენა | **TypeScript 5.4** (strict mode) |
| Auth | Mock **AuthService** with Signals + Guards |
| ნავიგაცია | **Angular Router** (lazy loading + guards) |
| ფორმები | **Reactive Forms** + custom validators |
| მდგომარეობა | **RxJS BehaviorSubject** + **Angular Signals** |
| Error Handling | **GlobalErrorHandler** (`ErrorHandler`) |
| მონაცემები | **Browser `localStorage`** (bulletproof) |
| Lint | **@angular-eslint** |
| CI/CD | **GitHub Actions** |
| სტილი | Custom **SCSS** (CSS variables, responsive) |
| ფონტი | Noto Sans Georgian + Inter |

---

## 📁 პროექტის სტრუქტურა

```
src/
├── environments/
│   ├── environment.ts          # Debug mode ON
│   └── environment.prod.ts     # Debug OFF, production=true
└── app/
    ├── core/
    │   ├── models/             # Employee, Department, Position, Vacation, Auth
    │   ├── services/           # StorageService, AuthService, EmployeeService, …, ToastService
    │   ├── guards/             # authGuard (CanActivateFn), roleGuard (factory)
    │   └── handlers/           # GlobalErrorHandler (implements ErrorHandler)
    ├── features/
    │   ├── login/              # LoginComponent (public route)
    │   ├── dashboard/          # სტატისტიკა, ჩარტი
    │   ├── employees/
    │   │   ├── employee-list/  # OnPush, BehaviorSubject, search/filter/sort/page
    │   │   ├── employee-form/  # Reactive Form, custom validators
    │   │   └── employee-details/
    │   ├── departments/        # CRUD + delete guard
    │   ├── positions/          # CRUD + range validation
    │   ├── vacations/          # RLS + approve/reject
    │   ├── settings/           # Export/Import/Reset + env badge
    │   └── not-found/          # 404
    ├── shared/
    │   ├── components/         # sidebar, header (logout), status-badge, confirm-dialog, toast, empty-state
    │   └── pipes/              # salary.pipe, georgian-date.pipe
    ├── app.component.ts        # Login/App layout switcher (OnPush + Signal)
    ├── app.routes.ts           # authGuard + roleGuard on protected routes
    └── app.config.ts           # GlobalErrorHandler provider
```

---

## 🔐 Auth & Role System

```
/login               → public (no guard)
/dashboard           → authGuard
/employees           → authGuard          (read: all users)
/employees/new       → authGuard + roleGuard(['hr_admin'])
/employees/:id/edit  → authGuard + roleGuard(['hr_admin'])
/departments         → authGuard + roleGuard(['hr_admin'])
/positions           → authGuard + roleGuard(['hr_admin'])
/vacations           → authGuard          (RLS enforced in component)
/settings            → authGuard + roleGuard(['hr_admin'])
```

**Row-Level Security on Vacations:**  
- HR Admin — approve/reject any vacation  
- Standard Employee — can only submit for their own linked employeeId

---

## ✅ ყველა FR და NFR

### Functional Requirements
- [x] FR-1: Dashboard (stat cards, last 5 hires, pending vacations, dept chart)
- [x] FR-2: Employees (CRUD, search, filter, sort, pagination, Georgian validation, cascade delete)
- [x] FR-3: Departments (CRUD, unique name, delete restriction)
- [x] FR-4: Positions (CRUD, minSalary < maxSalary, delete restriction)
- [x] FR-5: Vacations (RLS, overlap check, approve/reject, onLeave auto-update)
- [x] FR-6: Data Management (auto-save, seed data, export/import, reset)

### Non-Functional Requirements
- [x] `no any` — zero any types
- [x] localStorage only through `StorageService`
- [x] `ChangeDetectionStrategy.OnPush` on every component
- [x] `track item.id` on every `@for` loop
- [x] `GlobalErrorHandler` — catches + displays errors without crashing
- [x] `QuotaExceededError` fallback in `StorageService`
- [x] Lazy loading via `loadComponent` on all routes
- [x] Guards: `authGuard` + `roleGuard` factory
- [x] Environment configs swapped at build time
- [x] GitHub Actions CI/CD (lint + build + test)
- [x] ESLint config (`eslint.config.js`)
- [x] Responsive: 1920px / 1366px / 768px / 375px
- [x] Georgian language throughout

### Bonus
- [x] Angular Signals (`AuthService`, `ToastService`, `AppComponent`)
- [x] Mobile responsive

---

## 🎁 Screenshots

> _Add screenshots after first run:_
> - `docs/screenshots/login.png`
> - `docs/screenshots/dashboard.png`
> - `docs/screenshots/employees.png`
> - `docs/screenshots/vacations.png`

---

## 🔄 CI/CD Pipeline

`.github/workflows/ci.yml` triggers on every push to `main` / `develop`:

```
npm ci → ng lint → ng build --prod → ng test (ChromeHeadless)
```

Artifacts (dist/) are uploaded on `main` branch pushes.
