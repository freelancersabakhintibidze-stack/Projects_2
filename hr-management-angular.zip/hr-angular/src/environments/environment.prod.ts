export const environment = {
  production: true,
  debug: false,
  appVersion: '1.0.0',
  appName: 'HR სისტემა',
};
