export const environment = {
  production: false,
  debug: true,
  appVersion: '1.0.0',
  appName: 'HR სისტემა',
};
