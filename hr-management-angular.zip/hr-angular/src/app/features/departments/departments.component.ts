import {
  Component, OnInit, OnDestroy, ChangeDetectionStrategy, ChangeDetectorRef, inject,
} from '@angular/core';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators, AbstractControl, ValidationErrors } from '@angular/forms';
import { Subscription } from 'rxjs';
import { Department } from '../../core/models/department.model';
import { DepartmentService } from '../../core/services/department.service';
import { EmployeeService } from '../../core/services/employee.service';
import { ToastService } from '../../core/services/toast.service';
import { EmptyStateComponent } from '../../shared/components/empty-state/empty-state.component';
import { ConfirmDialogComponent } from '../../shared/components/confirm-dialog/confirm-dialog.component';

@Component({
  selector: 'app-departments',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [ReactiveFormsModule, EmptyStateComponent, ConfirmDialogComponent],
  template: `
    <div class="page-content">
      <div class="page-header">
        <h1>🏢 დეპარტამენტები</h1>
        <button class="btn btn-primary" (click)="openAdd()">+ დამატება</button>
      </div>

      <div class="table-wrapper">
        <table>
          <thead>
            <tr>
              <th>დასახელება</th><th>აღწერა</th><th>ხელმძღვანელი</th>
              <th>თანამშრომლები</th><th style="text-align:center;">მოქმედება</th>
            </tr>
          </thead>
          <tbody>
            @if (departments.length === 0) {
              <tr><td colspan="5"><app-empty-state icon="🏢" title="დეპარტამენტები ვერ მოიძებნა" text="" /></td></tr>
            }
            @for (dept of departments; track dept.id) {
              <tr>
                <td style="font-weight:600;">{{ dept.name }}</td>
                <td style="color:var(--color-text-secondary);">{{ dept.description || '—' }}</td>
                <td>{{ getHeadName(dept.headEmployeeId) }}</td>
                <td><span class="badge badge-info">{{ getEmpCount(dept.id) }} თანამ.</span></td>
                <td>
                  <div style="display:flex;gap:6px;justify-content:center;">
                    <button class="btn btn-ghost btn-icon btn-sm" (click)="openEdit(dept)">✏️</button>
                    <button class="btn btn-ghost btn-icon btn-sm" (click)="openDelete(dept)">🗑️</button>
                  </div>
                </td>
              </tr>
            }
          </tbody>
        </table>
      </div>
    </div>

    @if (showModal) {
      <div class="modal-overlay" (click)="closeModal($event)">
        <div class="modal" role="dialog">
          <div class="modal-header">
            <h2>{{ editTarget ? 'დეპარტამენტის რედაქტირება' : 'ახალი დეპარტამენტი' }}</h2>
            <button class="btn btn-ghost btn-icon" (click)="showModal=false; cdr.markForCheck()">✕</button>
          </div>
          <div class="modal-body">
            <form [formGroup]="form">
              <div class="form-group">
                <label class="form-label">დასახელება *</label>
                <input class="form-control" [class.is-invalid]="touched('name')"
                       formControlName="name" placeholder="დეპარტამენტის სახელი" />
                @if (err('name','required'))  { <span class="error-msg">სახელი სავალდებულოა</span> }
                @if (err('name','nameTaken')) { <span class="error-msg">ეს სახელი უკვე გამოყენებულია</span> }
              </div>
              <div class="form-group">
                <label class="form-label">აღწერა</label>
                <textarea class="form-control" formControlName="description" rows="3"></textarea>
              </div>
              <div class="form-group">
                <label class="form-label">ხელმძღვანელი</label>
                <select class="form-control" formControlName="headEmployeeId">
                  <option value="">— არ არის მითითებული —</option>
                  @for (e of employees; track e.id) {
                    <option [value]="e.id">{{ e.firstName }} {{ e.lastName }}</option>
                  }
                </select>
              </div>
            </form>
          </div>
          <div class="modal-footer">
            <button class="btn btn-outline" (click)="showModal=false; cdr.markForCheck()">გაუქმება</button>
            <button class="btn btn-primary" [disabled]="form.invalid" (click)="save()">შენახვა</button>
          </div>
        </div>
      </div>
    }

    <app-confirm-dialog
      [visible]="showDelete"
      title="დეპარტამენტის წაშლა"
      [message]="deleteMessage"
      confirmLabel="კი, წავშლი"
      confirmClass="btn-danger"
      (confirm)="doDelete()"
      (cancel)="showDelete=false; cdr.markForCheck()" />
  `,
})
export class DepartmentsComponent implements OnInit, OnDestroy {
  private deptSvc = inject(DepartmentService);
  private empSvc  = inject(EmployeeService);
  private toast   = inject(ToastService);
  private fb      = inject(FormBuilder);
  cdr             = inject(ChangeDetectorRef);
  private sub!: Subscription;

  departments: Department[] = [];
  employees: { id: string; firstName: string; lastName: string }[] = [];
  form!: FormGroup;
  showModal = false; showDelete = false;
  editTarget:   Department | null = null;
  deleteTarget: Department | null = null;
  deleteMessage = '';

  ngOnInit(): void {
    this.employees = this.empSvc.getAll().filter((e) => e.status !== 'terminated');
    this.sub = this.deptSvc.departments$.subscribe((list) => {
      this.departments = list; this.cdr.markForCheck();
    });
    this.buildForm();
  }
  ngOnDestroy(): void { this.sub?.unsubscribe(); }

  buildForm(): void {
    this.form = this.fb.group({
      name:           ['', [Validators.required, this.nameTakenValidator.bind(this)]],
      description:    [''],
      headEmployeeId: [''],
    });
  }

  private nameTakenValidator(ctrl: AbstractControl): ValidationErrors | null {
    if (!ctrl.value) return null;
    return this.deptSvc.isNameTaken(ctrl.value as string, this.editTarget?.id)
      ? { nameTaken: true } : null;
  }

  touched(f: string): boolean { const c = this.form.get(f); return !!c && c.invalid && (c.dirty || c.touched); }
  err(f: string, e: string): boolean { return !!this.form.get(f)?.hasError(e) && this.touched(f); }

  openAdd(): void  { this.editTarget = null; this.buildForm(); this.showModal = true; this.cdr.markForCheck(); }
  openEdit(dept: Department): void {
    this.editTarget = dept; this.buildForm(); this.form.patchValue(dept);
    this.showModal = true; this.cdr.markForCheck();
  }

  openDelete(dept: Department): void {
    const count = this.getEmpCount(dept.id);
    if (count > 0) { this.toast.error(`წაშლა შეუძლებელია — დეპარტამენტში ${count} თანამშრომელია`); return; }
    this.deleteTarget  = dept;
    this.deleteMessage = `დარწმუნებული ხართ, რომ გსურთ დეპარტამენტის "${dept.name}" წაშლა?`;
    this.showDelete    = true; this.cdr.markForCheck();
  }

  save(): void {
    if (this.form.invalid) { this.form.markAllAsTouched(); return; }
    const val = this.form.value as Omit<Department, 'id'>;
    if (this.editTarget) { this.deptSvc.update(this.editTarget.id, val); this.toast.success('დეპარტამენტი განახლდა'); }
    else                 { this.deptSvc.add(val); this.toast.success('დეპარტამენტი დაემატა'); }
    this.showModal = false; this.cdr.markForCheck();
  }

  doDelete(): void {
    if (!this.deleteTarget) return;
    this.deptSvc.delete(this.deleteTarget.id);
    this.toast.success('დეპარტამენტი წაშლილია');
    this.showDelete = false; this.cdr.markForCheck();
  }

  closeModal(e: MouseEvent): void {
    if ((e.target as HTMLElement).classList.contains('modal-overlay')) {
      this.showModal = false; this.cdr.markForCheck();
    }
  }

  getEmpCount(deptId: string): number { return this.empSvc.getAll().filter((e) => e.departmentId === deptId).length; }
  getHeadName(headId?: string): string {
    if (!headId) return '—';
    const e = this.empSvc.getById(headId);
    return e ? `${e.firstName} ${e.lastName}` : '—';
  }
}
