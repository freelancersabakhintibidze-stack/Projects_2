import {
  Component, OnInit, OnDestroy, ChangeDetectionStrategy, ChangeDetectorRef, inject,
} from '@angular/core';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Subscription } from 'rxjs';
import { Position, PositionLevel } from '../../core/models/position.model';
import { PositionService } from '../../core/services/position.service';
import { EmployeeService } from '../../core/services/employee.service';
import { ToastService } from '../../core/services/toast.service';
import { SalaryPipe } from '../../shared/pipes/salary.pipe';
import { EmptyStateComponent } from '../../shared/components/empty-state/empty-state.component';
import { ConfirmDialogComponent } from '../../shared/components/confirm-dialog/confirm-dialog.component';

const LEVELS: PositionLevel[] = ['Junior', 'Middle', 'Senior', 'Lead'];
const LEVEL_CLASSES: Record<PositionLevel, string> = {
  Junior: 'badge-info', Middle: 'badge-primary', Senior: 'badge-warning', Lead: 'badge-success',
};

@Component({
  selector: 'app-positions',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [ReactiveFormsModule, SalaryPipe, EmptyStateComponent, ConfirmDialogComponent],
  template: `
    <div class="page-content">
      <div class="page-header">
        <h1>💼 პოზიციები</h1>
        <button class="btn btn-primary" (click)="openAdd()">+ დამატება</button>
      </div>

      <div class="table-wrapper">
        <table>
          <thead>
            <tr>
              <th>პოზიცია</th><th>დონე</th><th>მინ. ანაზღ.</th><th>მაქს. ანაზღ.</th>
              <th>თანამშრომლები</th><th style="text-align:center;">მოქმედება</th>
            </tr>
          </thead>
          <tbody>
            @if (positions.length === 0) {
              <tr><td colspan="6"><app-empty-state icon="💼" title="პოზიციები ვერ მოიძებნა" text="" /></td></tr>
            }
            @for (pos of positions; track pos.id) {
              <tr>
                <td style="font-weight:600;">{{ pos.title }}</td>
                <td><span class="badge" [class]="levelClass(pos.level)">{{ pos.level }}</span></td>
                <td>{{ pos.minSalary | salary }}</td>
                <td>{{ pos.maxSalary | salary }}</td>
                <td><span class="badge badge-info">{{ getEmpCount(pos.id) }}</span></td>
                <td>
                  <div style="display:flex;gap:6px;justify-content:center;">
                    <button class="btn btn-ghost btn-icon btn-sm" (click)="openEdit(pos)">✏️</button>
                    <button class="btn btn-ghost btn-icon btn-sm" (click)="openDelete(pos)">🗑️</button>
                  </div>
                </td>
              </tr>
            }
          </tbody>
        </table>
      </div>
    </div>

    @if (showModal) {
      <div class="modal-overlay" (click)="closeModal($event)">
        <div class="modal" role="dialog">
          <div class="modal-header">
            <h2>{{ editTarget ? 'პოზიციის რედაქტირება' : 'ახალი პოზიცია' }}</h2>
            <button class="btn btn-ghost btn-icon" (click)="showModal=false; cdr.markForCheck()">✕</button>
          </div>
          <div class="modal-body">
            <form [formGroup]="form">
              <div class="form-group">
                <label class="form-label">პოზიციის დასახელება *</label>
                <input class="form-control" [class.is-invalid]="touched('title')"
                       formControlName="title" placeholder="მაგ. Frontend დეველოპერი" />
                @if (err('title','required')) { <span class="error-msg">დასახელება სავალდებულოა</span> }
              </div>
              <div class="form-group">
                <label class="form-label">დონე *</label>
                <select class="form-control" formControlName="level">
                  @for (l of levels; track l) { <option [value]="l">{{ l }}</option> }
                </select>
              </div>
              <div class="form-grid">
                <div class="form-group">
                  <label class="form-label">მინ. ანაზღაურება *</label>
                  <input class="form-control" [class.is-invalid]="touched('minSalary')"
                         formControlName="minSalary" type="number" placeholder="1000" />
                  @if (err('minSalary','required')) { <span class="error-msg">სავალდებულოა</span> }
                  @if (err('minSalary','min'))      { <span class="error-msg">0-ზე მეტი უნდა იყოს</span> }
                </div>
                <div class="form-group">
                  <label class="form-label">მაქს. ანაზღაურება *</label>
                  <input class="form-control" [class.is-invalid]="touched('maxSalary') || hasRangeErr"
                         formControlName="maxSalary" type="number" placeholder="5000" />
                  @if (err('maxSalary','required')) { <span class="error-msg">სავალდებულოა</span> }
                  @if (hasRangeErr) { <span class="error-msg">მაქს. ანაზღ. მინ.-ზე მეტი უნდა იყოს</span> }
                </div>
              </div>
            </form>
          </div>
          <div class="modal-footer">
            <button class="btn btn-outline" (click)="showModal=false; cdr.markForCheck()">გაუქმება</button>
            <button class="btn btn-primary" [disabled]="form.invalid || hasRangeErr" (click)="save()">შენახვა</button>
          </div>
        </div>
      </div>
    }

    <app-confirm-dialog
      [visible]="showDelete"
      title="პოზიციის წაშლა"
      [message]="deleteMessage"
      confirmLabel="კი, წავშლი"
      confirmClass="btn-danger"
      (confirm)="doDelete()"
      (cancel)="showDelete=false; cdr.markForCheck()" />
  `,
})
export class PositionsComponent implements OnInit, OnDestroy {
  private posSvc = inject(PositionService);
  private empSvc = inject(EmployeeService);
  private toast  = inject(ToastService);
  private fb     = inject(FormBuilder);
  cdr            = inject(ChangeDetectorRef);
  private sub!: Subscription;

  positions: Position[] = [];
  levels = LEVELS;
  form!: FormGroup;
  showModal = false; showDelete = false;
  editTarget:   Position | null = null;
  deleteTarget: Position | null = null;
  deleteMessage = '';

  ngOnInit(): void {
    this.sub = this.posSvc.positions$.subscribe((list) => {
      this.positions = list; this.cdr.markForCheck();
    });
    this.buildForm();
  }
  ngOnDestroy(): void { this.sub?.unsubscribe(); }

  buildForm(): void {
    this.form = this.fb.group({
      title:     ['', Validators.required],
      level:     ['Junior', Validators.required],
      minSalary: [null, [Validators.required, Validators.min(1)]],
      maxSalary: [null, [Validators.required, Validators.min(1)]],
    });
  }

  get hasRangeErr(): boolean {
    const min = Number(this.form.get('minSalary')?.value);
    const max = Number(this.form.get('maxSalary')?.value);
    return !!min && !!max && max <= min;
  }

  touched(f: string): boolean { const c = this.form.get(f); return !!c && c.invalid && (c.dirty || c.touched); }
  err(f: string, e: string): boolean { return !!this.form.get(f)?.hasError(e) && this.touched(f); }
  levelClass(level: PositionLevel): string { return LEVEL_CLASSES[level]; }

  openAdd(): void { this.editTarget = null; this.buildForm(); this.showModal = true; this.cdr.markForCheck(); }
  openEdit(pos: Position): void {
    this.editTarget = pos; this.buildForm(); this.form.patchValue(pos);
    this.showModal = true; this.cdr.markForCheck();
  }

  openDelete(pos: Position): void {
    const count = this.getEmpCount(pos.id);
    if (count > 0) { this.toast.error(`წაშლა შეუძლებელია — ${count} თანამშრომელი ამ პოზიციაზეა`); return; }
    this.deleteTarget  = pos;
    this.deleteMessage = `დარწმუნებული ხართ, რომ გსურთ პოზიციის "${pos.title}" წაშლა?`;
    this.showDelete    = true; this.cdr.markForCheck();
  }

  save(): void {
    if (this.form.invalid || this.hasRangeErr) { this.form.markAllAsTouched(); return; }
    const val = this.form.value as Omit<Position, 'id'>;
    if (this.editTarget) { this.posSvc.update(this.editTarget.id, val); this.toast.success('პოზიცია განახლდა'); }
    else                 { this.posSvc.add(val); this.toast.success('პოზიცია დაემატა'); }
    this.showModal = false; this.cdr.markForCheck();
  }

  doDelete(): void {
    if (!this.deleteTarget) return;
    this.posSvc.delete(this.deleteTarget.id);
    this.toast.success('პოზიცია წაშლილია');
    this.showDelete = false; this.cdr.markForCheck();
  }

  closeModal(e: MouseEvent): void {
    if ((e.target as HTMLElement).classList.contains('modal-overlay')) {
      this.showModal = false; this.cdr.markForCheck();
    }
  }

  getEmpCount(posId: string): number { return this.empSvc.getAll().filter((e) => e.positionId === posId).length; }
}
