import { Component, ChangeDetectionStrategy } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-not-found',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [RouterLink],
  template: `
    <div style="display:flex;align-items:center;justify-content:center;height:80vh;text-align:center;padding:24px;">
      <div>
        <div style="font-size:80px;margin-bottom:16px;">🔍</div>
        <h1 style="font-size:32px;font-weight:800;margin-bottom:8px;color:var(--color-text-primary);">404</h1>
        <h2 style="font-size:20px;font-weight:600;margin-bottom:12px;color:var(--color-text-secondary);">
          გვერდი ვერ მოიძებნა
        </h2>
        <p style="color:var(--color-text-muted);margin-bottom:28px;font-size:15px;max-width:360px;">
          მოძებნილი URL არ არსებობს. შესაძლოა ბმული შეიცვალა ან წაიშალა.
        </p>
        <a routerLink="/dashboard" class="btn btn-primary" style="font-size:15px;padding:10px 24px;">
          🏠 მთავარ გვერდზე დაბრუნება
        </a>
      </div>
    </div>
  `,
})
export class NotFoundComponent {}
