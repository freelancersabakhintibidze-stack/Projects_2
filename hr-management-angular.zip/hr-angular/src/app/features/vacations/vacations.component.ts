import {
  Component, OnInit, OnDestroy, ChangeDetectionStrategy, ChangeDetectorRef, inject,
} from '@angular/core';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Subscription } from 'rxjs';
import { VacationRequest, VacationStatus } from '../../core/models/vacation.model';
import { VacationService } from '../../core/services/vacation.service';
import { EmployeeService } from '../../core/services/employee.service';
import { AuthService } from '../../core/services/auth.service';
import { ToastService } from '../../core/services/toast.service';
import { GeorgianDatePipe } from '../../shared/pipes/georgian-date.pipe';
import { StatusBadgeComponent } from '../../shared/components/status-badge/status-badge.component';
import { EmptyStateComponent } from '../../shared/components/empty-state/empty-state.component';
import { ConfirmDialogComponent } from '../../shared/components/confirm-dialog/confirm-dialog.component';

@Component({
  selector: 'app-vacations',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [ReactiveFormsModule, GeorgianDatePipe, StatusBadgeComponent, EmptyStateComponent, ConfirmDialogComponent],
  template: `
    <div class="page-content">
      <div class="page-header">
        <h1>🌴 შვებულებები</h1>
        <button class="btn btn-primary" (click)="openAdd()">+ მოთხოვნა</button>
      </div>

      <!-- Status Filter -->
      <div class="filters-row" style="margin-bottom:16px;">
        @for (s of statusOptions; track s.value) {
          <button class="btn" [class.btn-secondary]="filterStatus===s.value"
                  [class.btn-outline]="filterStatus!==s.value"
                  (click)="filterStatus=s.value; applyFilter(); detectChanges()">
            {{ s.label }}
          </button>
        }
      </div>

      <div class="table-wrapper">
        <table>
          <thead>
            <tr>
              <th>თანამშრომელი</th>
              <th>ტიპი</th>
              <th>დაწყება</th>
              <th>დასრულება</th>
              <th>ხანგრძლივობა</th>
              <th>სტატუსი</th>
              <th>კომენტარი</th>
              @if (auth.isAdmin()) { <th style="text-align:center;">მოქმედება</th> }
            </tr>
          </thead>
          <tbody>
            @if (filtered.length === 0) {
              <tr><td [colSpan]="auth.isAdmin() ? 8 : 7">
                <app-empty-state icon="🌴" title="შვებულების მოთხოვნები ვერ მოიძებნა" text="" />
              </td></tr>
            }
            @for (v of filtered; track v.id) {
              <tr>
                <td style="font-weight:600;">{{ getEmpName(v.employeeId) }}</td>
                <td><span class="badge badge-primary">{{ typeLabel(v.type) }}</span></td>
                <td>{{ v.startDate | georgianDate }}</td>
                <td>{{ v.endDate | georgianDate }}</td>
                <td style="font-weight:600;">{{ calcDays(v.startDate, v.endDate) }} დღე</td>
                <td><app-status-badge [status]="v.status" /></td>
                <td style="color:var(--color-text-muted);font-size:13px;">{{ v.comment || '—' }}</td>
                @if (auth.isAdmin()) {
                  <td>
                    <div style="display:flex;gap:4px;justify-content:center;">
                      @if (v.status === 'pending') {
                        <button class="btn btn-sm" style="background:#dcfce7;color:#15803d;border:none;" (click)="approve(v)">✓ დამტკ.</button>
                        <button class="btn btn-sm" style="background:#fee2e2;color:#b91c1c;border:none;" (click)="reject(v)">✕ უარყ.</button>
                      }
                    </div>
                  </td>
                }
              </tr>
            }
          </tbody>
        </table>
      </div>
    </div>

    <!-- Add Modal -->
    @if (showModal) {
      <div class="modal-overlay" (click)="closeModal($event)">
        <div class="modal" role="dialog">
          <div class="modal-header">
            <h2>შვებულების მოთხოვნა</h2>
            <button class="btn btn-ghost btn-icon" (click)="showModal=false; detectChanges()">✕</button>
          </div>
          <div class="modal-body">
            <form [formGroup]="form">
              @if (auth.isAdmin()) {
                <div class="form-group">
                  <label class="form-label">თანამშრომელი *</label>
                  <select class="form-control" [class.is-invalid]="touched('employeeId')" formControlName="employeeId">
                    <option value="">— აირჩიეთ —</option>
                    @for (e of activeEmployees; track e.id) {
                      <option [value]="e.id">{{ e.firstName }} {{ e.lastName }}</option>
                    }
                  </select>
                  @if (err('employeeId','required')) { <span class="error-msg">თანამშრომელი სავალდებულოა</span> }
                </div>
              }
              <div class="form-group">
                <label class="form-label">ტიპი *</label>
                <select class="form-control" formControlName="type">
                  <option value="paid">ანაზღაურებადი</option>
                  <option value="unpaid">ანაზღაურების გარეშე</option>
                  <option value="sick">ავადმყოფობა</option>
                </select>
              </div>
              <div class="form-grid">
                <div class="form-group">
                  <label class="form-label">დაწყება *</label>
                  <input class="form-control" [class.is-invalid]="touched('startDate')"
                         formControlName="startDate" type="date" (change)="onDateChange()" />
                  @if (err('startDate','required')) { <span class="error-msg">სავალდებულოა</span> }
                </div>
                <div class="form-group">
                  <label class="form-label">დასრულება *</label>
                  <input class="form-control" [class.is-invalid]="touched('endDate') || hasDateErr"
                         formControlName="endDate" type="date" (change)="onDateChange()" />
                  @if (err('endDate','required')) { <span class="error-msg">სავალდებულოა</span> }
                  @if (hasDateErr)    { <span class="error-msg">დასრულება დაწყებაზე გვიანი უნდა იყოს</span> }
                  @if (hasOverlapErr) { <span class="error-msg">თარიღები ეწინააღმდეგება დამტკიცებულ შვებულებას</span> }
                </div>
              </div>
              <div class="form-group">
                <label class="form-label">კომენტარი</label>
                <textarea class="form-control" formControlName="comment" rows="3" placeholder="სურვილისამებრ..."></textarea>
              </div>
            </form>
          </div>
          <div class="modal-footer">
            <button class="btn btn-outline" (click)="showModal=false; detectChanges()">გაუქმება</button>
            <button class="btn btn-primary" [disabled]="form.invalid || hasDateErr || hasOverlapErr" (click)="save()">გაგზავნა</button>
          </div>
        </div>
      </div>
    }

    <app-confirm-dialog
      [visible]="showConfirm"
      [title]="confirmTitle"
      [message]="confirmMsg"
      [confirmLabel]="confirmLabel"
      [confirmClass]="confirmClass"
      (confirm)="doConfirm()"
      (cancel)="showConfirm=false; detectChanges()" />
  `,
})
export class VacationsComponent implements OnInit, OnDestroy {
  private vacSvc = inject(VacationService);
  private empSvc = inject(EmployeeService);
  private toast  = inject(ToastService);
  private fb     = inject(FormBuilder);
  private cdr    = inject(ChangeDetectorRef);
  auth           = inject(AuthService);

  private sub!: Subscription;
  vacations: VacationRequest[] = [];
  filtered:  VacationRequest[] = [];
  activeEmployees: { id: string; firstName: string; lastName: string }[] = [];

  filterStatus = '';
  statusOptions = [
    { value: '', label: 'ყველა' },
    { value: 'pending',  label: 'მოლოდინში' },
    { value: 'approved', label: 'დამტკიცებული' },
    { value: 'rejected', label: 'უარყოფილი' },
  ];

  form!: FormGroup;
  showModal = false; hasDateErr = false; hasOverlapErr = false;
  showConfirm = false; confirmTitle = ''; confirmMsg = '';
  confirmLabel = ''; confirmClass = 'btn-primary';
  confirmTarget: VacationRequest | null = null;
  confirmAction: VacationStatus = 'approved';

  ngOnInit(): void {
    this.activeEmployees = this.empSvc.getAll().filter((e) => e.status !== 'terminated');
    this.sub = this.vacSvc.vacations$.subscribe((list) => {
      this.vacations = list; this.applyFilter(); this.cdr.markForCheck();
    });
    this.buildForm();
  }
  ngOnDestroy(): void { this.sub?.unsubscribe(); }

  buildForm(): void {
    // RLS: if non-admin, pre-fill their own employeeId
    const currentEmpId = this.auth.currentUser()?.employeeId ?? '';
    this.form = this.fb.group({
      employeeId: [this.auth.isAdmin() ? '' : currentEmpId, Validators.required],
      type:       ['paid', Validators.required],
      startDate:  ['', Validators.required],
      endDate:    ['', Validators.required],
      comment:    [''],
    });
    this.hasDateErr = false; this.hasOverlapErr = false;
  }

  applyFilter(): void {
    this.filtered = (this.filterStatus
      ? this.vacations.filter((v) => v.status === this.filterStatus)
      : [...this.vacations]
    ).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  }

  onDateChange(): void {
    const start = this.form.get('startDate')?.value as string;
    const end   = this.form.get('endDate')?.value as string;
    const empId = this.form.get('employeeId')?.value as string;
    this.hasDateErr    = !!(start && end && end <= start);
    this.hasOverlapErr = !!(empId && start && end && !this.hasDateErr && this.vacSvc.hasOverlap(empId, start, end));
    this.cdr.markForCheck();
  }

  openAdd(): void { this.buildForm(); this.showModal = true; this.cdr.markForCheck(); }

  save(): void {
    if (this.form.invalid || this.hasDateErr || this.hasOverlapErr) { this.form.markAllAsTouched(); return; }
    const val = this.form.value as { employeeId: string; type: 'paid'|'unpaid'|'sick'; startDate: string; endDate: string; comment: string };
    this.vacSvc.add({ ...val, status: 'pending' });
    this.toast.success('შვებულების მოთხოვნა გაიგზავნა');
    this.showModal = false; this.cdr.markForCheck();
  }

  approve(v: VacationRequest): void {
    if (!this.auth.canEditVacation(v.employeeId)) { this.toast.error('წვდომა შეზღუდულია'); return; }
    this.confirmTarget = v; this.confirmAction = 'approved';
    this.confirmTitle  = 'შვებულების დამტკიცება';
    this.confirmMsg    = `დარწმუნებული ხართ, რომ გსურთ ${this.getEmpName(v.employeeId)}-ის შვებულება დაამტკიცოთ?`;
    this.confirmLabel  = 'დამტკიცება'; this.confirmClass = 'btn-primary';
    this.showConfirm   = true; this.cdr.markForCheck();
  }

  reject(v: VacationRequest): void {
    if (!this.auth.canEditVacation(v.employeeId)) { this.toast.error('წვდომა შეზღუდულია'); return; }
    this.confirmTarget = v; this.confirmAction = 'rejected';
    this.confirmTitle  = 'შვებულების უარყოფა';
    this.confirmMsg    = `დარწმუნებული ხართ, რომ გსურთ ${this.getEmpName(v.employeeId)}-ის შვებულება უარყოთ?`;
    this.confirmLabel  = 'უარყოფა'; this.confirmClass = 'btn-danger';
    this.showConfirm   = true; this.cdr.markForCheck();
  }

  doConfirm(): void {
    if (!this.confirmTarget) return;
    this.vacSvc.updateStatus(this.confirmTarget.id, this.confirmAction);
    this.toast.success(this.confirmAction === 'approved' ? 'შვებულება დამტკიცდა' : 'შვებულება უარყოფილია');
    this.showConfirm = false; this.cdr.markForCheck();
  }

  closeModal(e: MouseEvent): void {
    if ((e.target as HTMLElement).classList.contains('modal-overlay')) {
      this.showModal = false; this.cdr.markForCheck();
    }
  }
  detectChanges(): void { this.cdr.markForCheck(); }

  touched(f: string): boolean { const c = this.form.get(f); return !!c && c.invalid && (c.dirty || c.touched); }
  err(f: string, e: string): boolean { return !!this.form.get(f)?.hasError(e) && this.touched(f); }
  getEmpName(id: string): string { const e = this.empSvc.getById(id); return e ? `${e.firstName} ${e.lastName}` : '—'; }
  typeLabel(type: string): string {
    const map: Record<string, string> = { paid: 'ანაზღ.', unpaid: 'ანაზღ. გარეშე', sick: 'ავადმყოფობა' };
    return map[type] ?? type;
  }
  calcDays(start: string, end: string): number {
    return Math.max(1, Math.round((new Date(end).getTime() - new Date(start).getTime()) / 86_400_000) + 1);
  }
}
