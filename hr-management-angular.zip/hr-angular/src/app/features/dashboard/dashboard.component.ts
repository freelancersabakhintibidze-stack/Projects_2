import {
  Component, OnInit, ChangeDetectionStrategy, ChangeDetectorRef, inject,
} from '@angular/core';
import { RouterLink } from '@angular/router';
import { EmployeeService } from '../../core/services/employee.service';
import { DepartmentService } from '../../core/services/department.service';
import { VacationService } from '../../core/services/vacation.service';
import { PositionService } from '../../core/services/position.service';
import { Employee } from '../../core/models/employee.model';
import { VacationRequest } from '../../core/models/vacation.model';
import { GeorgianDatePipe } from '../../shared/pipes/georgian-date.pipe';
import { SalaryPipe } from '../../shared/pipes/salary.pipe';
import { StatusBadgeComponent } from '../../shared/components/status-badge/status-badge.component';

interface DeptStat { name: string; count: number; pct: number; }

@Component({
  selector: 'app-dashboard',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [RouterLink, GeorgianDatePipe, SalaryPipe, StatusBadgeComponent],
  template: `
    <div class="page-content">
      <!-- Stat Cards -->
      <div class="stat-cards">
        <div class="stat-card">
          <div class="stat-icon" style="background:#e0e7ff;">👥</div>
          <div class="stat-value">{{ totalEmployees }}</div>
          <div class="stat-label">სულ თანამშრომელი</div>
        </div>
        <div class="stat-card">
          <div class="stat-icon" style="background:#dcfce7;">✅</div>
          <div class="stat-value">{{ activeEmployees }}</div>
          <div class="stat-label">აქტიური</div>
        </div>
        <div class="stat-card">
          <div class="stat-icon" style="background:#fef9c3;">🌴</div>
          <div class="stat-value">{{ onLeaveEmployees }}</div>
          <div class="stat-label">შვებულებაში</div>
        </div>
        <div class="stat-card">
          <div class="stat-icon" style="background:#ede9fe;">🏢</div>
          <div class="stat-value">{{ totalDepartments }}</div>
          <div class="stat-label">დეპარტამენტი</div>
        </div>
        <div class="stat-card">
          <div class="stat-icon" style="background:#fce7f3;">⏳</div>
          <div class="stat-value">{{ pendingVacations }}</div>
          <div class="stat-label">განხილვაში</div>
        </div>
      </div>

      <div class="dashboard-grid">
        <!-- Recent Hires -->
        <div class="card">
          <div class="section-header">🆕 ბოლოს დაქირავებული</div>
          @if (recentHires.length === 0) {
            <p style="color:var(--color-text-muted);font-size:13px;">ჩანაწერები არ მოიძებნა</p>
          } @else {
            <table>
              <thead><tr><th>სახელი</th><th>პოზიცია</th><th>მიღების თარიღი</th><th>სტატუსი</th></tr></thead>
              <tbody>
                @for (emp of recentHires; track emp.id) {
                  <tr>
                    <td>
                      <a [routerLink]="['/employees', emp.id]" style="color:var(--color-accent);font-weight:600;">
                        {{ emp.firstName }} {{ emp.lastName }}
                      </a>
                    </td>
                    <td>{{ getPositionTitle(emp.positionId) }}</td>
                    <td>{{ emp.hireDate | georgianDate }}</td>
                    <td><app-status-badge [status]="emp.status" /></td>
                  </tr>
                }
              </tbody>
            </table>
          }
        </div>

        <!-- Pending Vacations -->
        <div class="card">
          <div class="section-header" style="display:flex;align-items:center;justify-content:space-between;">
            <span>⏳ მოლოდინში — შვებულებები</span>
            <a routerLink="/vacations" class="btn btn-ghost btn-sm" style="font-size:12px;">ყველა →</a>
          </div>
          @if (pendingList.length === 0) {
            <p style="color:var(--color-text-muted);font-size:13px;">მოლოდინში მყოფი მოთხოვნები არ არის</p>
          } @else {
            @for (v of pendingList; track v.id) {
              <div class="vacation-item">
                <div>
                  <div style="font-weight:600;font-size:13px;">{{ getEmployeeName(v.employeeId) }}</div>
                  <div style="color:var(--color-text-muted);font-size:12px;">
                    {{ v.startDate | georgianDate }} — {{ v.endDate | georgianDate }}
                    · {{ calcDays(v.startDate, v.endDate) }} დღე
                  </div>
                </div>
                <app-status-badge [status]="v.status" />
              </div>
            }
          }
        </div>

        <!-- Dept Distribution -->
        <div class="card" style="grid-column:1/-1;">
          <div class="section-header">📊 თანამშრომლები დეპარტამენტის მიხედვით</div>
          <div class="dept-chart">
            @for (dept of deptStats; track dept.name) {
              <div class="dept-row">
                <span class="dept-name">{{ dept.name }}</span>
                <div class="dept-bar-wrap">
                  <div class="dept-bar" [style.width.%]="dept.pct"></div>
                </div>
                <span class="dept-count">{{ dept.count }} თანამ.</span>
              </div>
            }
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .dashboard-grid { display:grid; grid-template-columns:1fr 1fr; gap:20px; }
    .vacation-item { display:flex; align-items:center; justify-content:space-between; padding:10px 0; border-bottom:1px solid var(--color-border); &:last-child{border-bottom:none;} }
    .dept-chart { display:flex; flex-direction:column; gap:12px; }
    .dept-row   { display:flex; align-items:center; gap:14px; }
    .dept-name  { min-width:160px; font-size:13px; font-weight:600; }
    .dept-bar-wrap { flex:1; height:10px; background:var(--color-bg); border-radius:999px; overflow:hidden; }
    .dept-bar   { height:100%; background:var(--color-accent); border-radius:999px; transition:width .4s ease; }
    .dept-count { min-width:80px; font-size:13px; color:var(--color-text-secondary); text-align:right; }
    @media (max-width:768px) { .dashboard-grid { grid-template-columns:1fr; } }
  `],
})
export class DashboardComponent implements OnInit {
  private empSvc  = inject(EmployeeService);
  private deptSvc = inject(DepartmentService);
  private vacSvc  = inject(VacationService);
  private posSvc  = inject(PositionService);
  private cdr     = inject(ChangeDetectorRef);

  totalEmployees = 0; activeEmployees = 0; onLeaveEmployees = 0;
  totalDepartments = 0; pendingVacations = 0;
  recentHires: Employee[] = [];
  pendingList: VacationRequest[] = [];
  deptStats: DeptStat[] = [];

  ngOnInit(): void {
    const employees   = this.empSvc.getAll();
    const departments = this.deptSvc.getAll();
    const vacations   = this.vacSvc.getAll();

    this.totalEmployees   = employees.length;
    this.activeEmployees  = employees.filter((e) => e.status === 'active').length;
    this.onLeaveEmployees = employees.filter((e) => e.status === 'onLeave').length;
    this.totalDepartments = departments.length;
    this.pendingList      = vacations.filter((v) => v.status === 'pending').slice(0, 5);
    this.pendingVacations = this.pendingList.length;
    this.recentHires      = [...employees].sort((a, b) => b.hireDate.localeCompare(a.hireDate)).slice(0, 5);

    const maxCount = Math.max(...departments.map(
      (d) => employees.filter((e) => e.departmentId === d.id).length,
    ), 1);
    this.deptStats = departments.map((d) => {
      const count = employees.filter((e) => e.departmentId === d.id).length;
      return { name: d.name, count, pct: Math.round((count / maxCount) * 100) };
    });
    this.cdr.markForCheck();
  }

  getPositionTitle(posId: string): string { return this.posSvc.getById(posId)?.title ?? '—'; }
  getEmployeeName(empId: string): string {
    const e = this.empSvc.getById(empId);
    return e ? `${e.firstName} ${e.lastName}` : '—';
  }
  calcDays(start: string, end: string): number {
    return Math.max(1, Math.round((new Date(end).getTime() - new Date(start).getTime()) / 86_400_000) + 1);
  }
}
