import {
  Component, OnInit, ChangeDetectionStrategy, ChangeDetectorRef, inject,
} from '@angular/core';
import { Router, ActivatedRoute, RouterLink } from '@angular/router';
import {
  ReactiveFormsModule, FormBuilder, FormGroup,
  Validators, AbstractControl, ValidationErrors,
} from '@angular/forms';
import { EmployeeService } from '../../../core/services/employee.service';
import { DepartmentService } from '../../../core/services/department.service';
import { PositionService } from '../../../core/services/position.service';
import { ToastService } from '../../../core/services/toast.service';
import { Position } from '../../../core/models/position.model';
import { Department } from '../../../core/models/department.model';

@Component({
  selector: 'app-employee-form',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [RouterLink, ReactiveFormsModule],
  template: `
    <div class="page-content">
      <div class="page-header">
        <h1>{{ isEdit ? '✏️ რედაქტირება' : '➕ ახალი თანამშრომელი' }}</h1>
        <a routerLink="/employees" class="btn btn-outline">← უკან</a>
      </div>

      <div class="card" style="max-width:800px;">
        <form [formGroup]="form" (ngSubmit)="submit()">
          <div class="section-header">პირადი ინფორმაცია</div>
          <div class="form-grid">
            <div class="form-group">
              <label class="form-label">სახელი *</label>
              <input class="form-control" [class.is-invalid]="touched('firstName')"
                     formControlName="firstName" placeholder="სახელი" />
              @if (err('firstName','required'))  { <span class="error-msg">სახელი სავალდებულოა</span> }
              @if (err('firstName','minlength')) { <span class="error-msg">მინიმუმ 2 სიმბოლო</span> }
            </div>
            <div class="form-group">
              <label class="form-label">გვარი *</label>
              <input class="form-control" [class.is-invalid]="touched('lastName')"
                     formControlName="lastName" placeholder="გვარი" />
              @if (err('lastName','required'))  { <span class="error-msg">გვარი სავალდებულოა</span> }
              @if (err('lastName','minlength')) { <span class="error-msg">მინიმუმ 2 სიმბოლო</span> }
            </div>
            <div class="form-group">
              <label class="form-label">ელ-ფოსტა *</label>
              <input class="form-control" [class.is-invalid]="touched('email')"
                     formControlName="email" type="email" placeholder="example@company.ge" />
              @if (err('email','required'))   { <span class="error-msg">ელ-ფოსტა სავალდებულოა</span> }
              @if (err('email','email'))      { <span class="error-msg">ელ-ფოსტის ფორმატი არასწორია</span> }
              @if (err('email','emailTaken')) { <span class="error-msg">ეს ელ-ფოსტა უკვე გამოყენებულია</span> }
            </div>
            <div class="form-group">
              <label class="form-label">ტელეფონი * (9 ციფრი)</label>
              <input class="form-control" [class.is-invalid]="touched('phone')"
                     formControlName="phone" placeholder="5XXXXXXXX" maxlength="9" />
              @if (err('phone','required')) { <span class="error-msg">ტელეფონი სავალდებულოა</span> }
              @if (err('phone','pattern'))  { <span class="error-msg">ტელეფონი უნდა შეიცავდეს ზუსტად 9 ციფრს</span> }
            </div>
            <div class="form-group">
              <label class="form-label">დაბადების თარიღი</label>
              <input class="form-control" formControlName="birthDate" type="date" />
            </div>
          </div>

          <div class="section-header" style="margin-top:8px;">სამუშაო ინფორმაცია</div>
          <div class="form-grid">
            <div class="form-group">
              <label class="form-label">დეპარტამენტი *</label>
              <select class="form-control" [class.is-invalid]="touched('departmentId')" formControlName="departmentId">
                <option value="">-- აირჩიეთ --</option>
                @for (d of departments; track d.id) { <option [value]="d.id">{{ d.name }}</option> }
              </select>
              @if (err('departmentId','required')) { <span class="error-msg">დეპარტამენტი სავალდებულოა</span> }
            </div>
            <div class="form-group">
              <label class="form-label">პოზიცია *</label>
              <select class="form-control" [class.is-invalid]="touched('positionId')"
                      formControlName="positionId" (change)="onPositionChange()">
                <option value="">-- აირჩიეთ --</option>
                @for (p of positions; track p.id) {
                  <option [value]="p.id">{{ p.title }} ({{ p.level }})</option>
                }
              </select>
              @if (err('positionId','required')) { <span class="error-msg">პოზიცია სავალდებულოა</span> }
            </div>
            <div class="form-group">
              <label class="form-label">
                ანაზღაურება (₾) *
                @if (selectedPosition) {
                  <span style="font-weight:400;color:var(--color-text-muted);font-size:12px;">
                    {{ selectedPosition.minSalary }} – {{ selectedPosition.maxSalary }}
                  </span>
                }
              </label>
              <input class="form-control" [class.is-invalid]="touched('salary')"
                     formControlName="salary" type="number" placeholder="ანაზღაურება" />
              @if (err('salary','required'))    { <span class="error-msg">ანაზღაურება სავალდებულოა</span> }
              @if (err('salary','min'))         { <span class="error-msg">ანაზღაურება დადებითი რიცხვი უნდა იყოს</span> }
              @if (err('salary','salaryRange')) {
                <span class="error-msg">ანაზღაურება უნდა იყოს {{ selectedPosition?.minSalary }} – {{ selectedPosition?.maxSalary }} ₾ შორის</span>
              }
            </div>
            <div class="form-group">
              <label class="form-label">მიღების თარიღი *</label>
              <input class="form-control" [class.is-invalid]="touched('hireDate')"
                     formControlName="hireDate" type="date" [max]="today" />
              @if (err('hireDate','required'))   { <span class="error-msg">მიღების თარიღი სავალდებულოა</span> }
              @if (err('hireDate','futureDate')) { <span class="error-msg">მიღების თარიღი მომავალში ვერ იქნება</span> }
            </div>
            <div class="form-group">
              <label class="form-label">სტატუსი *</label>
              <select class="form-control" formControlName="status">
                <option value="active">აქტიური</option>
                <option value="onLeave">შვებულებაში</option>
                <option value="terminated">გათავისუფლებული</option>
              </select>
            </div>
          </div>

          <div style="display:flex;gap:12px;justify-content:flex-end;margin-top:8px;">
            <a routerLink="/employees" class="btn btn-outline">გაუქმება</a>
            <button type="submit" class="btn btn-primary" [disabled]="form.invalid">
              {{ isEdit ? 'შენახვა' : 'დამატება' }}
            </button>
          </div>
        </form>
      </div>
    </div>
  `,
})
export class EmployeeFormComponent implements OnInit {
  private fb      = inject(FormBuilder);
  private empSvc  = inject(EmployeeService);
  private deptSvc = inject(DepartmentService);
  private posSvc  = inject(PositionService);
  private toast   = inject(ToastService);
  private router  = inject(Router);
  private route   = inject(ActivatedRoute);
  private cdr     = inject(ChangeDetectorRef);

  form!: FormGroup;
  isEdit = false; editId: string | null = null;
  departments: Department[] = [];
  positions:   Position[]   = [];
  selectedPosition: Position | null = null;
  today = new Date().toISOString().split('T')[0];

  ngOnInit(): void {
    this.departments = this.deptSvc.getAll();
    this.positions   = this.posSvc.getAll();

    this.form = this.fb.group({
      firstName:    ['', [Validators.required, Validators.minLength(2)]],
      lastName:     ['', [Validators.required, Validators.minLength(2)]],
      email:        ['', [Validators.required, Validators.email, this.emailUniqueValidator.bind(this)]],
      phone:        ['', [Validators.required, Validators.pattern(/^\d{9}$/)]],
      birthDate:    [''],
      departmentId: ['', Validators.required],
      positionId:   ['', Validators.required],
      salary:       [null, [Validators.required, Validators.min(1)]],
      hireDate:     ['', [Validators.required, this.futureDateValidator]],
      status:       ['active', Validators.required],
    });

    this.editId = this.route.snapshot.paramMap.get('id');
    this.isEdit = !!this.editId && this.route.snapshot.url.some((s) => s.path === 'edit');

    if (this.isEdit && this.editId) {
      const emp = this.empSvc.getById(this.editId);
      if (emp) {
        this.form.patchValue(emp);
        this.selectedPosition = this.posSvc.getById(emp.positionId) ?? null;
        this.form.get('salary')?.addValidators(this.salaryRangeValidator.bind(this));
      }
    }
    this.cdr.markForCheck();
  }

  onPositionChange(): void {
    const posId = this.form.get('positionId')?.value as string;
    this.selectedPosition = this.posSvc.getById(posId) ?? null;
    const ctrl = this.form.get('salary');
    ctrl?.clearValidators();
    ctrl?.addValidators([Validators.required, Validators.min(1), this.salaryRangeValidator.bind(this)]);
    ctrl?.updateValueAndValidity();
    this.cdr.markForCheck();
  }

  private futureDateValidator(ctrl: AbstractControl): ValidationErrors | null {
    if (!ctrl.value) return null;
    return ctrl.value > new Date().toISOString().split('T')[0] ? { futureDate: true } : null;
  }

  private salaryRangeValidator(ctrl: AbstractControl): ValidationErrors | null {
    if (!this.selectedPosition || !ctrl.value) return null;
    const val = Number(ctrl.value);
    return (val < this.selectedPosition.minSalary || val > this.selectedPosition.maxSalary)
      ? { salaryRange: true } : null;
  }

  private emailUniqueValidator(ctrl: AbstractControl): ValidationErrors | null {
    if (!ctrl.value) return null;
    return this.empSvc.isEmailTaken(ctrl.value as string, this.editId ?? undefined)
      ? { emailTaken: true } : null;
  }

  touched(f: string): boolean { const c = this.form.get(f); return !!c && c.invalid && (c.dirty || c.touched); }
  err(f: string, e: string): boolean { return !!this.form.get(f)?.hasError(e) && this.touched(f); }

  submit(): void {
    if (this.form.invalid) { this.form.markAllAsTouched(); return; }
    const val = this.form.value as {
      firstName: string; lastName: string; email: string; phone: string; birthDate: string;
      departmentId: string; positionId: string; salary: number; hireDate: string;
      status: 'active' | 'onLeave' | 'terminated';
    };
    if (this.isEdit && this.editId) {
      this.empSvc.update(this.editId, val); this.toast.success('თანამშრომელი განახლდა');
    } else {
      this.empSvc.add(val); this.toast.success('თანამშრომელი დაემატა');
    }
    void this.router.navigate(['/employees']);
  }
}
