import {
  Component, OnInit, ChangeDetectionStrategy, ChangeDetectorRef, inject,
} from '@angular/core';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { EmployeeService } from '../../../core/services/employee.service';
import { DepartmentService } from '../../../core/services/department.service';
import { PositionService } from '../../../core/services/position.service';
import { VacationService } from '../../../core/services/vacation.service';
import { ToastService } from '../../../core/services/toast.service';
import { AuthService } from '../../../core/services/auth.service';
import { Employee } from '../../../core/models/employee.model';
import { VacationRequest } from '../../../core/models/vacation.model';
import { GeorgianDatePipe } from '../../../shared/pipes/georgian-date.pipe';
import { SalaryPipe } from '../../../shared/pipes/salary.pipe';
import { StatusBadgeComponent } from '../../../shared/components/status-badge/status-badge.component';
import { ConfirmDialogComponent } from '../../../shared/components/confirm-dialog/confirm-dialog.component';

@Component({
  selector: 'app-employee-details',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [RouterLink, GeorgianDatePipe, SalaryPipe, StatusBadgeComponent, ConfirmDialogComponent],
  template: `
    <div class="page-content">
      @if (!employee) {
        <div class="card" style="text-align:center;padding:60px;">
          <p style="font-size:48px;">🔍</p>
          <h2 style="margin:16px 0 8px;">თანამშრომელი ვერ მოიძებნა</h2>
          <p style="color:var(--color-text-muted);margin-bottom:24px;">მოძებნილი ID-ის მიხედვით ჩანაწერი არ არსებობს.</p>
          <a routerLink="/employees" class="btn btn-primary">← სიაში დაბრუნება</a>
        </div>
      } @else {
        <div class="page-header">
          <h1>👤 {{ employee.firstName }} {{ employee.lastName }}</h1>
          <div style="display:flex;gap:10px;">
            <a routerLink="/employees" class="btn btn-outline">← უკან</a>
            @if (auth.isAdmin()) {
              <a [routerLink]="['/employees', employee.id, 'edit']" class="btn btn-secondary">✏️ რედაქტირება</a>
              <button class="btn btn-danger" (click)="showDelete=true; cdr.markForCheck()">🗑️ წაშლა</button>
            }
          </div>
        </div>

        <div class="card" style="margin-bottom:20px;">
          <div style="display:flex;align-items:center;gap:20px;margin-bottom:24px;flex-wrap:wrap;">
            <div class="avatar-lg">{{ initials }}</div>
            <div>
              <h2 style="font-size:20px;margin-bottom:4px;">{{ employee.firstName }} {{ employee.lastName }}</h2>
              <p style="color:var(--color-text-secondary);">{{ positionTitle }}</p>
              <app-status-badge [status]="employee.status" />
            </div>
          </div>
          <div class="detail-grid">
            <div class="detail-item"><div class="detail-label">ელ-ფოსტა</div><div class="detail-value">{{ employee.email }}</div></div>
            <div class="detail-item"><div class="detail-label">ტელეფონი</div><div class="detail-value">{{ employee.phone }}</div></div>
            <div class="detail-item"><div class="detail-label">დეპარტამენტი</div><div class="detail-value">{{ deptName }}</div></div>
            <div class="detail-item"><div class="detail-label">პოზიცია</div><div class="detail-value">{{ positionTitle }}</div></div>
            <div class="detail-item"><div class="detail-label">ანაზღაურება</div><div class="detail-value">{{ employee.salary | salary }}</div></div>
            <div class="detail-item"><div class="detail-label">მიღების თარიღი</div><div class="detail-value">{{ employee.hireDate | georgianDate }}</div></div>
            @if (employee.birthDate) {
              <div class="detail-item"><div class="detail-label">დაბადების თარიღი</div><div class="detail-value">{{ employee.birthDate | georgianDate }}</div></div>
            }
          </div>
        </div>

        <div class="card">
          <div class="section-header">🌴 შვებულებების ისტორია</div>
          @if (vacations.length === 0) {
            <p style="color:var(--color-text-muted);font-size:13px;padding:20px 0;">შვებულების ჩანაწერები არ მოიძებნა</p>
          } @else {
            <div class="table-wrapper" style="border:none;box-shadow:none;">
              <table>
                <thead><tr><th>ტიპი</th><th>დაწყება</th><th>დასრულება</th><th>ხანგრძლივობა</th><th>სტატუსი</th><th>კომენტარი</th></tr></thead>
                <tbody>
                  @for (v of vacations; track v.id) {
                    <tr>
                      <td><span class="badge badge-primary">{{ vacTypeLabel(v.type) }}</span></td>
                      <td>{{ v.startDate | georgianDate }}</td>
                      <td>{{ v.endDate | georgianDate }}</td>
                      <td>{{ calcDays(v.startDate, v.endDate) }} დღე</td>
                      <td><app-status-badge [status]="v.status" /></td>
                      <td style="color:var(--color-text-muted);font-size:13px;">{{ v.comment || '—' }}</td>
                    </tr>
                  }
                </tbody>
              </table>
            </div>
          }
        </div>
      }
    </div>

    <app-confirm-dialog
      [visible]="showDelete"
      title="თანამშრომლის წაშლა"
      message="დარწმუნებული ხართ, რომ გსურთ წაშლა? ყველა შვებულების მოთხოვნაც წაიშლება."
      confirmLabel="კი, წავშლი"
      confirmClass="btn-danger"
      (confirm)="doDelete()"
      (cancel)="showDelete=false; cdr.markForCheck()" />
  `,
  styles: [`.avatar-lg { width:72px; height:72px; border-radius:50%; background:var(--color-primary); color:#fff; display:flex; align-items:center; justify-content:center; font-size:22px; font-weight:700; }`],
})
export class EmployeeDetailsComponent implements OnInit {
  private route   = inject(ActivatedRoute);
  private router  = inject(Router);
  private empSvc  = inject(EmployeeService);
  private deptSvc = inject(DepartmentService);
  private posSvc  = inject(PositionService);
  private vacSvc  = inject(VacationService);
  private toast   = inject(ToastService);
  cdr             = inject(ChangeDetectorRef);
  auth            = inject(AuthService);

  employee:      Employee | undefined;
  vacations:     VacationRequest[] = [];
  deptName      = ''; positionTitle = ''; initials = ''; showDelete = false;

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('id');
    if (!id) return;
    this.employee      = this.empSvc.getById(id);
    if (!this.employee) { this.cdr.markForCheck(); return; }
    this.deptName      = this.deptSvc.getById(this.employee.departmentId)?.name ?? '—';
    this.positionTitle = this.posSvc.getById(this.employee.positionId)?.title ?? '—';
    this.initials      = `${this.employee.firstName[0]}${this.employee.lastName[0]}`.toUpperCase();
    this.vacations     = this.vacSvc.getByEmployee(id).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
    this.cdr.markForCheck();
  }

  doDelete(): void {
    if (!this.employee) return;
    this.vacSvc.deleteByEmployee(this.employee.id);
    this.empSvc.delete(this.employee.id);
    this.toast.success(`${this.employee.firstName} ${this.employee.lastName} წაშლილია`);
    void this.router.navigate(['/employees']);
  }

  vacTypeLabel(type: string): string {
    const map: Record<string, string> = { paid:'ანაზღაურებადი', unpaid:'ანაზღაურების გარეშე', sick:'ავადმყოფობა' };
    return map[type] ?? type;
  }
  calcDays(start: string, end: string): number {
    return Math.max(1, Math.round((new Date(end).getTime() - new Date(start).getTime()) / 86_400_000) + 1);
  }
}
