import {
  Component, OnInit, OnDestroy, ChangeDetectionStrategy, ChangeDetectorRef, inject,
} from '@angular/core';
import { RouterLink } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { Subscription } from 'rxjs';
import { Employee } from '../../../core/models/employee.model';
import { EmployeeService } from '../../../core/services/employee.service';
import { DepartmentService } from '../../../core/services/department.service';
import { PositionService } from '../../../core/services/position.service';
import { VacationService } from '../../../core/services/vacation.service';
import { AuthService } from '../../../core/services/auth.service';
import { ToastService } from '../../../core/services/toast.service';
import { GeorgianDatePipe } from '../../../shared/pipes/georgian-date.pipe';
import { SalaryPipe } from '../../../shared/pipes/salary.pipe';
import { StatusBadgeComponent } from '../../../shared/components/status-badge/status-badge.component';
import { EmptyStateComponent } from '../../../shared/components/empty-state/empty-state.component';
import { ConfirmDialogComponent } from '../../../shared/components/confirm-dialog/confirm-dialog.component';

type SortField = 'name' | 'hireDate' | 'salary';
type SortDir   = 'asc' | 'desc';

@Component({
  selector: 'app-employee-list',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [
    RouterLink, FormsModule,
    GeorgianDatePipe, SalaryPipe,
    StatusBadgeComponent, EmptyStateComponent, ConfirmDialogComponent,
  ],
  template: `
    <div class="page-content">
      <div class="page-header">
        <h1>👤 თანამშრომლები</h1>
        @if (auth.isAdmin()) {
          <a routerLink="/employees/new" class="btn btn-primary">+ დამატება</a>
        }
      </div>

      <!-- Filters -->
      <div class="filters-row">
        <div class="search-input">
          <span class="search-icon">🔍</span>
          <input class="form-control" type="text" placeholder="სახელი, გვარი ან ელ-ფოსტა..."
                 [(ngModel)]="searchTerm" (ngModelChange)="onFilterChange()" />
        </div>
        <select class="form-control filter-select" [(ngModel)]="filterDept" (ngModelChange)="onFilterChange()">
          <option value="">ყველა დეპარტამენტი</option>
          @for (d of departments; track d.id) {
            <option [value]="d.id">{{ d.name }}</option>
          }
        </select>
        <select class="form-control filter-select" [(ngModel)]="filterStatus" (ngModelChange)="onFilterChange()">
          <option value="">ყველა სტატუსი</option>
          <option value="active">აქტიური</option>
          <option value="onLeave">შვებულებაში</option>
          <option value="terminated">გათავისუფლებული</option>
        </select>
      </div>

      <!-- Table -->
      <div class="table-wrapper">
        <table>
          <thead>
            <tr>
              <th class="sortable" (click)="toggleSort('name')">
                სახელი / გვარი <span class="sort-icon" [class.active]="sortField==='name'">{{ sortIcon('name') }}</span>
              </th>
              <th>ელ-ფოსტა</th>
              <th>დეპარტამენტი</th>
              <th>პოზიცია</th>
              <th class="sortable" (click)="toggleSort('salary')">
                ანაზღაურება <span class="sort-icon" [class.active]="sortField==='salary'">{{ sortIcon('salary') }}</span>
              </th>
              <th class="sortable" (click)="toggleSort('hireDate')">
                მიღების თარიღი <span class="sort-icon" [class.active]="sortField==='hireDate'">{{ sortIcon('hireDate') }}</span>
              </th>
              <th>სტატუსი</th>
              @if (auth.isAdmin()) { <th style="text-align:center;">მოქმედება</th> }
            </tr>
          </thead>
          <tbody>
            @if (paged.length === 0) {
              <tr>
                <td [colSpan]="auth.isAdmin() ? 8 : 7">
                  <app-empty-state icon="👤" title="თანამშრომლები არ მოიძებნა" text="სცადეთ ფილტრების შეცვლა." />
                </td>
              </tr>
            }
            @for (emp of paged; track emp.id) {
              <tr>
                <td>
                  <a [routerLink]="['/employees', emp.id]" style="font-weight:600;color:var(--color-accent);">
                    {{ emp.firstName }} {{ emp.lastName }}
                  </a>
                </td>
                <td>{{ emp.email }}</td>
                <td>{{ getDeptName(emp.departmentId) }}</td>
                <td>{{ getPosTitle(emp.positionId) }}</td>
                <td>{{ emp.salary | salary }}</td>
                <td>{{ emp.hireDate | georgianDate }}</td>
                <td><app-status-badge [status]="emp.status" /></td>
                @if (auth.isAdmin()) {
                  <td>
                    <div style="display:flex;gap:6px;justify-content:center;">
                      <a [routerLink]="['/employees', emp.id]" class="btn btn-ghost btn-icon btn-sm">👁️</a>
                      <a [routerLink]="['/employees', emp.id, 'edit']" class="btn btn-ghost btn-icon btn-sm">✏️</a>
                      <button class="btn btn-ghost btn-icon btn-sm" (click)="openDelete(emp)">🗑️</button>
                    </div>
                  </td>
                }
              </tr>
            }
          </tbody>
        </table>

        @if (filtered.length > 0) {
          <div class="pagination">
            <span class="pagination-info">
              {{ (currentPage-1)*pageSize + 1 }}–{{ min(currentPage*pageSize, filtered.length) }}
              სულ {{ filtered.length }}-დან
            </span>
            <div class="pagination-controls">
              <button class="page-btn" [disabled]="currentPage===1" (click)="setPage(currentPage-1)">‹</button>
              @for (p of pages; track p) {
                <button class="page-btn" [class.active]="p===currentPage" (click)="setPage(p)">{{ p }}</button>
              }
              <button class="page-btn" [disabled]="currentPage===totalPages" (click)="setPage(currentPage+1)">›</button>
            </div>
          </div>
        }
      </div>
    </div>

    <app-confirm-dialog
      [visible]="showDelete"
      title="თანამშრომლის წაშლა"
      [message]="deleteMessage"
      confirmLabel="კი, წავშლი"
      confirmClass="btn-danger"
      (confirm)="doDelete()"
      (cancel)="showDelete=false" />
  `,
})
export class EmployeeListComponent implements OnInit, OnDestroy {
  private empSvc  = inject(EmployeeService);
  private deptSvc = inject(DepartmentService);
  private posSvc  = inject(PositionService);
  private vacSvc  = inject(VacationService);
  private toast   = inject(ToastService);
  private cdr     = inject(ChangeDetectorRef);
  auth            = inject(AuthService);

  private sub!: Subscription;
  employees:   Employee[] = [];
  departments: { id: string; name: string }[] = [];
  positions:   { id: string; title: string }[] = [];
  filtered:    Employee[] = [];
  paged:       Employee[] = [];

  searchTerm = ''; filterDept = ''; filterStatus = '';
  sortField: SortField = 'name'; sortDir: SortDir = 'asc';
  currentPage = 1; pageSize = 10; totalPages = 1; pages: number[] = [];

  showDelete = false; deleteTarget: Employee | null = null; deleteMessage = '';

  ngOnInit(): void {
    this.departments = this.deptSvc.getAll();
    this.positions   = this.posSvc.getAll();
    this.sub = this.empSvc.employees$.subscribe((list) => {
      this.employees = list;
      this.applyFilters();
      this.cdr.markForCheck();
    });
  }
  ngOnDestroy(): void { this.sub?.unsubscribe(); }

  onFilterChange(): void { this.currentPage = 1; this.applyFilters(); }

  applyFilters(): void {
    const term = this.searchTerm.toLowerCase().trim();
    let list = this.employees.filter((e) => {
      const matchSearch = !term || e.firstName.toLowerCase().includes(term) ||
        e.lastName.toLowerCase().includes(term) || e.email.toLowerCase().includes(term);
      return matchSearch &&
        (!this.filterDept   || e.departmentId === this.filterDept) &&
        (!this.filterStatus || e.status === this.filterStatus);
    });
    list = list.sort((a, b) => {
      let cmp = 0;
      if (this.sortField === 'name')     cmp = `${a.firstName}${a.lastName}`.localeCompare(`${b.firstName}${b.lastName}`);
      if (this.sortField === 'hireDate') cmp = a.hireDate.localeCompare(b.hireDate);
      if (this.sortField === 'salary')   cmp = a.salary - b.salary;
      return this.sortDir === 'asc' ? cmp : -cmp;
    });
    this.filtered    = list;
    this.totalPages  = Math.max(1, Math.ceil(list.length / this.pageSize));
    this.currentPage = Math.min(this.currentPage, this.totalPages);
    this.pages       = Array.from({ length: this.totalPages }, (_, i) => i + 1);
    this.paged       = list.slice((this.currentPage - 1) * this.pageSize, this.currentPage * this.pageSize);
  }

  toggleSort(field: SortField): void {
    this.sortDir = this.sortField === field ? (this.sortDir === 'asc' ? 'desc' : 'asc') : 'asc';
    this.sortField = field;
    this.applyFilters();
  }
  sortIcon(field: SortField): string { return this.sortField !== field ? '↕' : this.sortDir === 'asc' ? '↑' : '↓'; }
  setPage(p: number): void { this.currentPage = p; this.applyFilters(); }
  min(a: number, b: number): number { return Math.min(a, b); }
  getDeptName(id: string): string { return this.departments.find((d) => d.id === id)?.name ?? '—'; }
  getPosTitle(id: string): string  { return this.positions.find((p) => p.id === id)?.title ?? '—'; }

  openDelete(emp: Employee): void {
    this.deleteTarget  = emp;
    this.deleteMessage = `დარწმუნებული ხართ, რომ გსურთ წაშალოთ ${emp.firstName} ${emp.lastName}? ყველა შვებულების მოთხოვნაც წაიშლება.`;
    this.showDelete    = true;
  }
  doDelete(): void {
    if (!this.deleteTarget) return;
    this.vacSvc.deleteByEmployee(this.deleteTarget.id);
    this.empSvc.delete(this.deleteTarget.id);
    this.toast.success(`${this.deleteTarget.firstName} ${this.deleteTarget.lastName} წაშლილია`);
    this.showDelete = false; this.deleteTarget = null;
  }
}
