import {
  Component, ChangeDetectionStrategy, ChangeDetectorRef, inject,
} from '@angular/core';
import { StorageService } from '../../core/services/storage.service';
import { EmployeeService } from '../../core/services/employee.service';
import { DepartmentService } from '../../core/services/department.service';
import { PositionService } from '../../core/services/position.service';
import { VacationService } from '../../core/services/vacation.service';
import { ToastService } from '../../core/services/toast.service';
import { ConfirmDialogComponent } from '../../shared/components/confirm-dialog/confirm-dialog.component';
import { environment } from '../../../environments/environment';

@Component({
  selector: 'app-settings',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [ConfirmDialogComponent],
  template: `
    <div class="page-content">
      <div class="page-header">
        <h1>⚙️ პარამეტრები</h1>
        @if (!env.production) {
          <span class="badge badge-warning">🛠 Development Mode</span>
        }
      </div>

      <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;max-width:900px;">
        <div class="card">
          <div class="settings-icon">📤</div>
          <h3 class="settings-title">მონაცემების ექსპორტი</h3>
          <p class="settings-desc">ყველა მონაცემი ჩამოიტვირთება JSON ფაილში.</p>
          <button class="btn btn-secondary" (click)="exportData()">📥 JSON ჩამოტვირთვა</button>
        </div>

        <div class="card">
          <div class="settings-icon">📥</div>
          <h3 class="settings-title">მონაცემების იმპორტი</h3>
          <p class="settings-desc">ატვირთეთ ადრე ექსპორტირებული JSON ფაილი.</p>
          <button class="btn btn-secondary" (click)="fileInput.click()">📂 JSON ატვირთვა</button>
          <input #fileInput type="file" accept=".json" style="display:none;" (change)="importData($event)" />
        </div>

        <div class="card" style="border-color:var(--color-danger-bg);">
          <div class="settings-icon">🔄</div>
          <h3 class="settings-title" style="color:var(--color-danger);">მონაცემების გადაყენება</h3>
          <p class="settings-desc">სისტემა დაუბრუნდება საწყის მდგომარეობას. ყველა ამჟამინდელი ჩანაწერი წაიშლება.</p>
          <button class="btn btn-danger" (click)="showReset=true; cdr.markForCheck()">♻️ გადაყენება</button>
        </div>

        <div class="card">
          <div class="settings-icon">ℹ️</div>
          <h3 class="settings-title">სისტემის შესახებ</h3>
          <div style="display:flex;flex-direction:column;gap:8px;margin-top:8px;">
            <div class="info-row"><span>ვერსია</span><strong>{{ env.appVersion }}</strong></div>
            <div class="info-row"><span>ჩარჩო</span><strong>Angular 17</strong></div>
            <div class="info-row"><span>გარემო</span><strong>{{ env.production ? 'Production' : 'Development' }}</strong></div>
            <div class="info-row"><span>Debug</span><strong>{{ env.debug ? 'On' : 'Off' }}</strong></div>
            <div class="info-row"><span>შენახვა</span><strong>localStorage</strong></div>
          </div>
        </div>
      </div>
    </div>

    <app-confirm-dialog
      [visible]="showReset"
      title="მონაცემების გადაყენება"
      message="ეს მოქმედება წაშლის ყველა ამჟამინდელ ჩანაწერს. გსურთ გაგრძელება?"
      confirmLabel="კი, გადავაყენოთ"
      confirmClass="btn-danger"
      (confirm)="doReset()"
      (cancel)="showReset=false; cdr.markForCheck()" />
  `,
  styles: [`
    .settings-icon { font-size:32px; margin-bottom:12px; }
    .settings-title { font-size:16px; font-weight:700; margin-bottom:8px; }
    .settings-desc  { font-size:13px; color:var(--color-text-secondary); margin-bottom:16px; line-height:1.6; }
    .info-row { display:flex; justify-content:space-between; font-size:13px; padding:6px 0; border-bottom:1px solid var(--color-border); &:last-child{border-bottom:none;} span{color:var(--color-text-secondary);} }
    @media (max-width:640px) { :host ::ng-deep .page-content > div { grid-template-columns:1fr !important; } }
  `],
})
export class SettingsComponent {
  private storage = inject(StorageService);
  private empSvc  = inject(EmployeeService);
  private deptSvc = inject(DepartmentService);
  private posSvc  = inject(PositionService);
  private vacSvc  = inject(VacationService);
  private toast   = inject(ToastService);
  cdr             = inject(ChangeDetectorRef);

  showReset = false;
  env       = environment;

  exportData(): void {
    const json = this.storage.exportAll();
    const blob = new Blob([json], { type: 'application/json' });
    const url  = URL.createObjectURL(blob);
    const a    = document.createElement('a');
    a.href     = url;
    a.download = `hr-backup-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
    this.toast.success('მონაცემები წარმატებით ჩამოიტვირთა');
  }

  importData(event: Event): void {
    const input = event.target as HTMLInputElement;
    const file  = input.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        this.storage.importAll(e.target?.result as string);
        this.empSvc.reload(); this.deptSvc.reload();
        this.posSvc.reload(); this.vacSvc.reload();
        this.toast.success('მონაცემები წარმატებით შემოიტვირთა');
      } catch {
        this.toast.error('ფაილის წაკითხვა ვერ მოხერხდა — გთხოვთ გადაამოწმოთ ფორმატი');
      }
      input.value = '';
    };
    reader.readAsText(file);
  }

  doReset(): void {
    this.storage.reset();
    this.empSvc.reload(); this.deptSvc.reload();
    this.posSvc.reload(); this.vacSvc.reload();
    this.toast.success('სისტემა გადაყენდა საწყის მდგომარეობაში');
    this.showReset = false; this.cdr.markForCheck();
  }
}
