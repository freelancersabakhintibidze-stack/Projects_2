import {
  Component, ChangeDetectionStrategy, ChangeDetectorRef, inject
} from '@angular/core';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from '../../core/services/auth.service';

@Component({
  selector: 'app-login',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [ReactiveFormsModule],
  template: `
    <div class="login-page">
      <div class="login-card">
        <div class="login-brand">
          <span class="login-icon">👥</span>
          <h1>HR სისტემა</h1>
          <p>შიდა HR მართვის პლატფორმა</p>
        </div>

        <form [formGroup]="form" (ngSubmit)="submit()">
          @if (errorMsg) {
            <div class="alert-error" role="alert">⚠️ {{ errorMsg }}</div>
          }

          <div class="form-group">
            <label class="form-label">მომხმარებელი</label>
            <input class="form-control" formControlName="username"
                   placeholder="admin / user" autocomplete="username" />
          </div>
          <div class="form-group">
            <label class="form-label">პაროლი</label>
            <input class="form-control" formControlName="password"
                   type="password" placeholder="პაროლი" autocomplete="current-password" />
          </div>
          <button type="submit" class="btn btn-primary" style="width:100%;justify-content:center;"
                  [disabled]="form.invalid || loading">
            {{ loading ? 'შესვლა...' : '🔐 შესვლა' }}
          </button>
        </form>

        <div class="demo-creds">
          <p class="demo-title">სადემო მონაცემები</p>
          <div class="cred-row">
            <span class="badge badge-success">HR ადმინი</span>
            <code>admin</code> / <code>admin123</code>
          </div>
          <div class="cred-row">
            <span class="badge badge-info">თანამშრომელი</span>
            <code>user</code> / <code>user123</code>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .login-page {
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      background: var(--color-primary);
      padding: 24px;
    }
    .login-card {
      background: var(--color-surface);
      border-radius: var(--radius-lg);
      padding: 40px;
      width: 100%;
      max-width: 400px;
      box-shadow: var(--shadow-lg);
    }
    .login-brand {
      text-align: center;
      margin-bottom: 32px;
      .login-icon { font-size: 48px; display: block; margin-bottom: 12px; }
      h1 { font-size: 22px; font-weight: 800; margin-bottom: 6px; }
      p  { color: var(--color-text-muted); font-size: 13px; }
    }
    .alert-error {
      background: var(--color-danger-bg);
      color: var(--color-danger-text);
      border: 1px solid #fca5a5;
      border-radius: var(--radius);
      padding: 10px 14px;
      margin-bottom: 16px;
      font-size: 13px;
    }
    .demo-creds {
      margin-top: 28px;
      padding: 16px;
      background: var(--color-bg);
      border-radius: var(--radius);
      border: 1px dashed var(--color-border);
      .demo-title { font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing:.05em; color:var(--color-text-muted); margin-bottom:10px; }
      .cred-row { display: flex; align-items: center; gap: 8px; margin-bottom: 6px; font-size:13px; &:last-child{margin-bottom:0;} }
      code { background:#f1f5f9; padding:2px 6px; border-radius:4px; font-family:monospace; }
    }
  `],
})
export class LoginComponent {
  private fb    = inject(FormBuilder);
  private auth  = inject(AuthService);
  private router  = inject(Router);
  private route   = inject(ActivatedRoute);
  private cdr     = inject(ChangeDetectorRef);

  form: FormGroup = this.fb.group({
    username: ['', Validators.required],
    password: ['', Validators.required],
  });

  errorMsg = '';
  loading  = false;

  submit(): void {
    if (this.form.invalid) { this.form.markAllAsTouched(); return; }
    this.loading  = true;
    this.errorMsg = '';

    const { username, password } = this.form.value as { username: string; password: string };
    const error = this.auth.login(username, password);

    if (error) {
      this.errorMsg = error;
      this.loading  = false;
      this.cdr.markForCheck();
      return;
    }

    const returnUrl = (this.route.snapshot.queryParams['returnUrl'] as string) ?? '/dashboard';
    void this.router.navigateByUrl(returnUrl);
  }
}
