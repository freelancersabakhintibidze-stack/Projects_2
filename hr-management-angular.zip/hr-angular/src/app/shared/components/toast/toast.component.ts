import { Component, inject, ChangeDetectionStrategy } from '@angular/core';
import { NgClass } from '@angular/common';
import { ToastService } from '../../../core/services/toast.service';

const ICONS: Record<string, string> = {
  success: '✅',
  error:   '❌',
  warning: '⚠️',
  info:    'ℹ️',
};

@Component({
  selector: 'app-toast',
  standalone: true,
  // Signals-based toasts work naturally with OnPush — the signal change
  // automatically schedules a view update without markForCheck.
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [NgClass],
  template: `
    <div class="toast-container" aria-live="polite" aria-atomic="false">
      @for (toast of toastService.toasts(); track toast.id) {
        <div class="toast" [ngClass]="'toast-' + toast.type" role="alert">
          <span class="toast-icon" aria-hidden="true">{{ icon(toast.type) }}</span>
          <span class="toast-message">{{ toast.message }}</span>
          <button class="btn btn-ghost btn-icon btn-sm"
                  style="margin-left:auto;padding:2px 6px;opacity:.6;"
                  [attr.aria-label]="'დახურვა'"
                  (click)="toastService.dismiss(toast.id)">✕</button>
        </div>
      }
    </div>
  `,
})
export class ToastComponent {
  readonly toastService = inject(ToastService);

  icon(type: string): string {
    return ICONS[type] ?? '•';
  }
}
