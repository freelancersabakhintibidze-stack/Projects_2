import { Component, Input, ChangeDetectionStrategy, inject } from '@angular/core';
import { AuthService } from '../../../core/services/auth.service';

@Component({
  selector: 'app-header',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <header class="app-header">
      <div class="header-title">
        @if (title) { <h1>{{ title }}</h1> }
      </div>
      <div class="header-right">
        <span class="header-date">{{ today }}</span>
        <div class="user-info">
          <div class="avatar">{{ initials }}</div>
          <div class="user-meta">
            <span class="user-name">{{ auth.userName() }}</span>
            <span class="user-role">{{ roleLabel }}</span>
          </div>
        </div>
        <button class="btn btn-ghost btn-sm" (click)="auth.logout()" title="გასვლა">
          🚪 გასვლა
        </button>
      </div>
    </header>
  `,
  styles: [`
    .app-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 0 24px;
      height: 60px;
      background: var(--color-surface);
      border-bottom: 1px solid var(--color-border);
      box-shadow: var(--shadow-sm);
      flex-shrink: 0;
    }
    h1 { font-size: 17px; font-weight: 700; color: var(--color-text-primary); }
    .header-right {
      display: flex; align-items: center; gap: 14px;
    }
    .header-date { font-size: 12px; color: var(--color-text-muted); }
    .user-info { display: flex; align-items: center; gap: 10px; }
    .avatar {
      width: 34px; height: 34px; border-radius: 50%;
      background: var(--color-primary); color: #fff;
      display: flex; align-items: center; justify-content: center;
      font-size: 12px; font-weight: 700;
    }
    .user-meta { display: flex; flex-direction: column; line-height: 1.3; }
    .user-name  { font-size: 13px; font-weight: 600; }
    .user-role  { font-size: 11px; color: var(--color-text-muted); }
    @media (max-width: 768px) {
      .app-header { padding: 0 16px; }
      .header-date, .user-meta { display: none; }
    }
  `],
})
export class HeaderComponent {
  @Input() title = '';

  auth  = inject(AuthService);
  today = new Date().toLocaleDateString('ka-GE', { year:'numeric', month:'long', day:'numeric' });

  get initials(): string {
    const name = this.auth.userName();
    return name.split(' ').map((w) => w[0] ?? '').join('').toUpperCase().slice(0, 2);
  }

  get roleLabel(): string {
    return this.auth.isAdmin() ? 'HR ადმინი' : 'თანამშრომელი';
  }
}
