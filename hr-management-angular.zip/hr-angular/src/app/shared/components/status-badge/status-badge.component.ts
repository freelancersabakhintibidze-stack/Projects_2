import { Component, Input, ChangeDetectionStrategy } from '@angular/core';
import { NgClass } from '@angular/common';

type Status = 'active' | 'onLeave' | 'terminated' | 'pending' | 'approved' | 'rejected';

const STATUS_MAP: Record<Status, { label: string; cls: string }> = {
  active:     { label: 'აქტიური',          cls: 'badge-success' },
  onLeave:    { label: 'შვებულებაში',      cls: 'badge-warning' },
  terminated: { label: 'გათავისუფლებული', cls: 'badge-danger'  },
  pending:    { label: 'მოლოდინში',        cls: 'badge-neutral' },
  approved:   { label: 'დამტკიცებული',    cls: 'badge-success' },
  rejected:   { label: 'უარყოფილი',       cls: 'badge-danger'  },
};

@Component({
  selector: 'app-status-badge',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [NgClass],
  template: `<span class="badge" [ngClass]="info.cls">{{ info.label }}</span>`,
})
export class StatusBadgeComponent {
  @Input({ required: true }) status!: Status;

  get info(): { label: string; cls: string } {
    return STATUS_MAP[this.status] ?? { label: this.status, cls: 'badge-neutral' };
  }
}
