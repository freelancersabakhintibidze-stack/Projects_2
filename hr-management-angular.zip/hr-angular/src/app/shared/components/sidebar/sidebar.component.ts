import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { RouterLink, RouterLinkActive } from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';

interface NavItem { path: string; label: string; icon: string; adminOnly?: boolean; }

@Component({
  selector: 'app-sidebar',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [RouterLink, RouterLinkActive],
  template: `
    <aside class="sidebar">
      <div class="sidebar-brand">
        <span class="brand-icon">👥</span>
        <span class="brand-text">HR სისტემა</span>
      </div>

      <nav class="sidebar-nav">
        @for (item of visibleItems; track item.path) {
          <a class="nav-item"
             [routerLink]="item.path"
             routerLinkActive="active"
             [routerLinkActiveOptions]="{ exact: item.path === '/dashboard' }">
            <span class="nav-icon">{{ item.icon }}</span>
            <span class="nav-label">{{ item.label }}</span>
          </a>
        }
      </nav>

      <div class="sidebar-footer">
        @if (auth.isAdmin()) {
          <a class="nav-item" routerLink="/settings" routerLinkActive="active">
            <span class="nav-icon">⚙️</span>
            <span class="nav-label">პარამეტრები</span>
          </a>
        }
        <div class="role-badge">
          <span class="badge" [class]="auth.isAdmin() ? 'badge-warning' : 'badge-info'">
            {{ auth.isAdmin() ? '👑 HR ადმინი' : '👤 თანამშრომელი' }}
          </span>
        </div>
      </div>
    </aside>
  `,
  styles: [`
    .sidebar {
      width: 240px; min-width: 240px; height: 100vh;
      background: var(--color-primary);
      display: flex; flex-direction: column;
      position: sticky; top: 0; overflow-y: auto; z-index: 100;
    }
    .sidebar-brand {
      display: flex; align-items: center; gap: 10px;
      padding: 22px 20px 18px;
      border-bottom: 1px solid rgba(255,255,255,0.1);
    }
    .brand-icon { font-size: 22px; }
    .brand-text { font-size: 16px; font-weight: 700; color: #fff; }
    .sidebar-nav { flex: 1; padding: 14px 12px; display: flex; flex-direction: column; gap: 3px; }
    .sidebar-footer { padding: 12px 12px 20px; border-top: 1px solid rgba(255,255,255,0.08); display:flex;flex-direction:column;gap:8px; }
    .role-badge { padding: 0 4px; }
    .nav-item {
      display: flex; align-items: center; gap: 10px;
      padding: 9px 12px; border-radius: 8px;
      color: rgba(255,255,255,0.7); font-size: 14px; font-weight: 500;
      transition: all 0.18s ease; cursor: pointer; text-decoration: none;
      &:hover { background: rgba(255,255,255,0.08); color: #fff; }
      &.active { background: var(--color-accent); color: #fff; }
    }
    .nav-icon { font-size: 17px; opacity: 0.85; }
    @media (max-width: 768px) {
      .sidebar { width: 64px; min-width: 64px; }
      .brand-text, .nav-label, .role-badge { display: none; }
      .sidebar-brand { justify-content: center; padding: 18px 0; }
      .nav-item { justify-content: center; padding: 10px; }
    }
  `],
})
export class SidebarComponent {
  auth = inject(AuthService);

  private allItems: NavItem[] = [
    { path: '/dashboard',   label: 'მთავარი',         icon: '🏠' },
    { path: '/employees',   label: 'თანამშრომლები',  icon: '👤' },
    { path: '/departments', label: 'დეპარტამენტები', icon: '🏢', adminOnly: true },
    { path: '/positions',   label: 'პოზიციები',       icon: '💼', adminOnly: true },
    { path: '/vacations',   label: 'შვებულებები',     icon: '🌴' },
  ];

  get visibleItems(): NavItem[] {
    return this.allItems.filter((i) => !i.adminOnly || this.auth.isAdmin());
  }
}
