import { Component, Input, ChangeDetectionStrategy } from '@angular/core';

@Component({
  selector: 'app-empty-state',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="empty-state">
      <div class="empty-icon">{{ icon }}</div>
      <div class="empty-title">{{ title }}</div>
      @if (text) { <div class="empty-text">{{ text }}</div> }
    </div>
  `,
})
export class EmptyStateComponent {
  @Input() icon  = '📭';
  @Input() title = 'ჩანაწერები არ მოიძებნა';
  @Input() text  = '';
}
