import {
  Component, Input, Output, EventEmitter, ChangeDetectionStrategy,
} from '@angular/core';

@Component({
  selector: 'app-confirm-dialog',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @if (visible) {
      <div class="modal-overlay" (click)="onOverlayClick($event)">
        <div class="modal" role="dialog" aria-modal="true"
             aria-labelledby="confirm-title" aria-describedby="confirm-msg">
          <div class="modal-header">
            <h2 id="confirm-title">{{ title }}</h2>
            <button class="btn btn-ghost btn-icon" (click)="cancel.emit()"
                    aria-label="გაუქმება">✕</button>
          </div>
          <div class="modal-body">
            <p id="confirm-msg"
               style="color:var(--color-text-secondary);font-size:15px;line-height:1.6;">
              {{ message }}
            </p>
          </div>
          <div class="modal-footer">
            <button class="btn btn-outline" (click)="cancel.emit()">გაუქმება</button>
            <button class="btn" [class]="confirmClass" (click)="confirm.emit()">
              {{ confirmLabel }}
            </button>
          </div>
        </div>
      </div>
    }
  `,
})
export class ConfirmDialogComponent {
  @Input() visible      = false;
  @Input() title        = 'დადასტურება';
  @Input() message      = 'დარწმუნებული ხართ, რომ გსურთ ამ მოქმედების შესრულება?';
  @Input() confirmLabel = 'კი, დარწმუნებული ვარ';
  @Input() confirmClass = 'btn-danger';

  @Output() confirm = new EventEmitter<void>();
  @Output() cancel  = new EventEmitter<void>();

  onOverlayClick(e: MouseEvent): void {
    if ((e.target as HTMLElement).classList.contains('modal-overlay')) {
      this.cancel.emit();
    }
  }
}
