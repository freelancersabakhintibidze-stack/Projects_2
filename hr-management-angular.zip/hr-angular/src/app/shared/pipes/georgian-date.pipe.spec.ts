import { GeorgianDatePipe } from './georgian-date.pipe';

describe('GeorgianDatePipe', () => {
  let pipe: GeorgianDatePipe;

  beforeEach(() => {
    pipe = new GeorgianDatePipe();
  });

  it('should create', () => {
    expect(pipe).toBeTruthy();
  });

  it('should format ISO date string as dd/MM/yyyy', () => {
    expect(pipe.transform('2025-07-17')).toBe('17/07/2025');
  });

  it('should strip time portion from ISO datetime string', () => {
    expect(pipe.transform('2025-01-05T09:30:00Z')).toBe('05/01/2025');
  });

  it('should pad single-digit day and month with leading zero', () => {
    expect(pipe.transform('2024-03-04')).toBe('04/03/2024');
  });

  it('should return "—" for null', () => {
    expect(pipe.transform(null)).toBe('—');
  });

  it('should return "—" for undefined', () => {
    expect(pipe.transform(undefined)).toBe('—');
  });

  it('should return "—" for empty string', () => {
    expect(pipe.transform('')).toBe('—');
  });
});
