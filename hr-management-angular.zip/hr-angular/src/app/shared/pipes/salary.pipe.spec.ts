import { SalaryPipe } from './salary.pipe';

describe('SalaryPipe', () => {
  let pipe: SalaryPipe;

  beforeEach(() => {
    pipe = new SalaryPipe();
  });

  it('should create', () => {
    expect(pipe).toBeTruthy();
  });

  it('should format whole thousands with non-breaking space separator', () => {
    expect(pipe.transform(5200)).toBe('5\u00A0200 ₾');
  });

  it('should format values under 1000 without separator', () => {
    expect(pipe.transform(500)).toBe('500 ₾');
  });

  it('should format millions correctly', () => {
    expect(pipe.transform(1_000_000)).toBe('1\u00A0000\u00A0000 ₾');
  });

  it('should return "—" for null', () => {
    expect(pipe.transform(null)).toBe('—');
  });

  it('should return "—" for undefined', () => {
    expect(pipe.transform(undefined)).toBe('—');
  });

  it('should return "—" for NaN', () => {
    expect(pipe.transform(NaN)).toBe('—');
  });

  it('should handle zero', () => {
    expect(pipe.transform(0)).toBe('0 ₾');
  });

  it('should handle negative values', () => {
    expect(pipe.transform(-1500)).toBe('-1\u00A0500 ₾');
  });

  it('should truncate decimal part (salary is always integer)', () => {
    expect(pipe.transform(1500.99)).toBe('1\u00A0500 ₾');
  });
});
