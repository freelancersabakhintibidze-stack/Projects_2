import { Pipe, PipeTransform } from '@angular/core';

/**
 * Formats a number as Georgian salary notation: 5200 → "5 200 ₾"
 * Uses manual grouping (space separator) to avoid platform-specific
 * toLocaleString() inconsistencies across Node.js environments.
 */
@Pipe({ name: 'salary', standalone: true, pure: true })
export class SalaryPipe implements PipeTransform {
  transform(value: number | null | undefined): string {
    if (value == null || isNaN(value)) return '—';
    const intPart   = Math.floor(Math.abs(value));
    const formatted = intPart.toString().replace(/\B(?=(\d{3})+(?!\d))/g, '\u00A0');
    const sign      = value < 0 ? '-' : '';
    return `${sign}${formatted} ₾`;
  }
}
