import { Pipe, PipeTransform } from '@angular/core';

@Pipe({ name: 'georgianDate', standalone: true })
export class GeorgianDatePipe implements PipeTransform {
  transform(value: string | null | undefined): string {
    if (!value) return '—';
    const [year, month, day] = value.split('T')[0].split('-');
    return `${day}/${month}/${year}`;
  }
}
