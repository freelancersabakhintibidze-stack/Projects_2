import { Routes } from '@angular/router';
import { authGuard } from './core/guards/auth.guard';
import { roleGuard } from './core/guards/role.guard';

export const routes: Routes = [
  // ── Public ────────────────────────────────────────────────────────────────
  {
    path: 'login',
    loadComponent: () =>
      import('./features/login/login.component').then((m) => m.LoginComponent),
  },

  // ── Root redirect ─────────────────────────────────────────────────────────
  { path: '', redirectTo: 'dashboard', pathMatch: 'full' },

  // ── Dashboard ─────────────────────────────────────────────────────────────
  {
    path: 'dashboard',
    canActivate: [authGuard],
    loadComponent: () =>
      import('./features/dashboard/dashboard.component').then(
        (m) => m.DashboardComponent,
      ),
  },

  // ── Employees ─────────────────────────────────────────────────────────────
  // IMPORTANT: specific static paths MUST come before parameterised :id paths.
  // Angular matches routes in declaration order; 'employees/new' would be
  // swallowed by 'employees/:id' if :id were declared first.

  {
    path: 'employees',
    canActivate: [authGuard],
    loadComponent: () =>
      import('./features/employees/employee-list/employee-list.component').then(
        (m) => m.EmployeeListComponent,
      ),
  },
  {
    // Static path — must be above employees/:id
    path: 'employees/new',
    canActivate: [authGuard, roleGuard(['hr_admin'])],
    loadComponent: () =>
      import('./features/employees/employee-form/employee-form.component').then(
        (m) => m.EmployeeFormComponent,
      ),
  },
  {
    // :id/edit — must be above employees/:id (two-segment match wins anyway
    // but explicit ordering prevents future ambiguity)
    path: 'employees/:id/edit',
    canActivate: [authGuard, roleGuard(['hr_admin'])],
    loadComponent: () =>
      import('./features/employees/employee-form/employee-form.component').then(
        (m) => m.EmployeeFormComponent,
      ),
  },
  {
    // Catch-all parameterised path — declared last among employee routes
    path: 'employees/:id',
    canActivate: [authGuard],
    loadComponent: () =>
      import(
        './features/employees/employee-details/employee-details.component'
      ).then((m) => m.EmployeeDetailsComponent),
  },

  // ── Departments & Positions — hr_admin only ───────────────────────────────
  {
    path: 'departments',
    canActivate: [authGuard, roleGuard(['hr_admin'])],
    loadComponent: () =>
      import('./features/departments/departments.component').then(
        (m) => m.DepartmentsComponent,
      ),
  },
  {
    path: 'positions',
    canActivate: [authGuard, roleGuard(['hr_admin'])],
    loadComponent: () =>
      import('./features/positions/positions.component').then(
        (m) => m.PositionsComponent,
      ),
  },

  // ── Vacations — authenticated users; RLS enforced inside component ────────
  {
    path: 'vacations',
    canActivate: [authGuard],
    loadComponent: () =>
      import('./features/vacations/vacations.component').then(
        (m) => m.VacationsComponent,
      ),
  },

  // ── Settings — hr_admin only ──────────────────────────────────────────────
  {
    path: 'settings',
    canActivate: [authGuard, roleGuard(['hr_admin'])],
    loadComponent: () =>
      import('./features/settings/settings.component').then(
        (m) => m.SettingsComponent,
      ),
  },

  // ── 404 ───────────────────────────────────────────────────────────────────
  {
    path: '**',
    loadComponent: () =>
      import('./features/not-found/not-found.component').then(
        (m) => m.NotFoundComponent,
      ),
  },
];
