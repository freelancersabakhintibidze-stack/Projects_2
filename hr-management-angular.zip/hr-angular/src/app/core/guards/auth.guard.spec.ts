import { TestBed } from '@angular/core/testing';
import { Router, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree } from '@angular/router';
import { authGuard } from './auth.guard';
import { AuthService } from '../services/auth.service';

describe('authGuard', () => {
  let authServiceSpy: jasmine.SpyObj<AuthService>;
  let routerSpy:      jasmine.SpyObj<Router>;

  const mockRoute = {} as ActivatedRouteSnapshot;
  const mockState = { url: '/dashboard' } as RouterStateSnapshot;

  beforeEach(() => {
    authServiceSpy = jasmine.createSpyObj('AuthService', ['isLoggedIn', 'currentUser']);
    routerSpy      = jasmine.createSpyObj('Router', ['createUrlTree', 'navigate']);
    routerSpy.createUrlTree.and.returnValue({} as UrlTree);

    TestBed.configureTestingModule({
      providers: [
        { provide: AuthService, useValue: authServiceSpy },
        { provide: Router,      useValue: routerSpy      },
      ],
    });
  });

  it('should allow navigation when logged in', () => {
    authServiceSpy.isLoggedIn.and.returnValue(true);
    const result = TestBed.runInInjectionContext(() =>
      authGuard(mockRoute, mockState),
    );
    expect(result).toBeTrue();
  });

  it('should redirect to /login when not logged in', () => {
    authServiceSpy.isLoggedIn.and.returnValue(false);
    TestBed.runInInjectionContext(() => authGuard(mockRoute, mockState));
    expect(routerSpy.createUrlTree).toHaveBeenCalledWith(
      ['/login'],
      jasmine.objectContaining({ queryParams: { returnUrl: '/dashboard' } }),
    );
  });
});
