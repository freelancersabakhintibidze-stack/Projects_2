import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { AuthService } from '../services/auth.service';
import { ToastService } from '../services/toast.service';
import { UserRole } from '../models/auth.model';

/**
 * Factory that creates a guard for a specific set of allowed roles.
 * Usage: canActivate: [authGuard, roleGuard(['hr_admin'])]
 */
export const roleGuard = (allowedRoles: UserRole[]): CanActivateFn => {
  return () => {
    const auth   = inject(AuthService);
    const router = inject(Router);
    const toast  = inject(ToastService);

    const user = auth.currentUser();
    if (user && allowedRoles.includes(user.role)) return true;

    toast.error('წვდომა შეზღუდულია — HR ადმინის უფლებები საჭიროა');
    return router.createUrlTree(['/dashboard']);
  };
};
