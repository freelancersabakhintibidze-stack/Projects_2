export type VacationType   = 'paid' | 'unpaid' | 'sick';
export type VacationStatus = 'pending' | 'approved' | 'rejected';

export interface VacationRequest {
  id: string;
  employeeId: string;
  startDate: string;
  endDate: string;
  type: VacationType;
  status: VacationStatus;
  comment?: string;
  createdAt: string;
}
