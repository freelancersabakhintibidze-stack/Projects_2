export interface Employee {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  departmentId: string;
  positionId: string;
  salary: number;
  hireDate: string;
  status: 'active' | 'onLeave' | 'terminated';
  birthDate?: string;
}
