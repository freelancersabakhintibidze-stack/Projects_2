export type PositionLevel = 'Junior' | 'Middle' | 'Senior' | 'Lead';

export interface Position {
  id: string;
  title: string;
  level: PositionLevel;
  minSalary: number;
  maxSalary: number;
}
