export interface Department {
  id: string;
  name: string;
  description?: string;
  headEmployeeId?: string;
}
