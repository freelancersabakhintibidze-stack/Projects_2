export type UserRole = 'hr_admin' | 'employee';

export interface AuthUser {
  id: string;
  username: string;
  role: UserRole;
  displayName: string;
  employeeId?: string; // linked HR employee record (if any)
}

export interface MockCredential {
  id: string;
  username: string;
  password: string;
  role: UserRole;
  displayName: string;
  employeeId?: string;
}
