import { Injectable, inject } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { Employee } from '../models/employee.model';
import { StorageService } from './storage.service';

@Injectable({ providedIn: 'root' })
export class EmployeeService {
  private storage = inject(StorageService);
  private _employees$ = new BehaviorSubject<Employee[]>(this.storage.getEmployees());

  get employees$(): Observable<Employee[]> {
    return this._employees$.asObservable();
  }

  getAll(): Employee[] {
    return this._employees$.value;
  }

  getById(id: string): Employee | undefined {
    return this._employees$.value.find((e) => e.id === id);
  }

  isEmailTaken(email: string, excludeId?: string): boolean {
    return this._employees$.value.some(
      (e) => e.email.toLowerCase() === email.toLowerCase() && e.id !== excludeId
    );
  }

  add(data: Omit<Employee, 'id'>): Employee {
    const employee: Employee = { id: crypto.randomUUID(), ...data };
    const updated = [...this._employees$.value, employee];
    this.persist(updated);
    return employee;
  }

  update(id: string, data: Partial<Omit<Employee, 'id'>>): void {
    const updated = this._employees$.value.map((e) =>
      e.id === id ? { ...e, ...data } : e
    );
    this.persist(updated);
  }

  delete(id: string): void {
    const updated = this._employees$.value.filter((e) => e.id !== id);
    this.persist(updated);
  }

  setStatus(id: string, status: Employee['status']): void {
    this.update(id, { status });
  }

  reload(): void {
    this._employees$.next(this.storage.getEmployees());
  }

  private persist(employees: Employee[]): void {
    this.storage.setEmployees(employees);
    this._employees$.next(employees);
  }
}
