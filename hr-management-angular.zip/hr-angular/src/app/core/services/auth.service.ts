import { Injectable, signal, computed, inject } from '@angular/core';
import { Router } from '@angular/router';
import { AuthUser, MockCredential } from '../models/auth.model';

const SESSION_KEY = 'hr_session';

/** Mock credential store — simulates what a real auth endpoint would validate. */
const MOCK_CREDENTIALS: MockCredential[] = [
  {
    id: 'u1',
    username: 'admin',
    password: 'admin123',
    role: 'hr_admin',
    displayName: 'HR ადმინი',
  },
  {
    id: 'u2',
    username: 'user',
    password: 'user123',
    role: 'employee',
    displayName: 'სტანდარტული მომხმარებელი',
    employeeId: 'e4', // linked to a seed employee
  },
];

@Injectable({ providedIn: 'root' })
export class AuthService {
  private router = inject(Router);

  /** Reactive current-user state via Angular Signal. */
  readonly currentUser = signal<AuthUser | null>(this.loadSession());

  /** Derived signals for convenience. */
  readonly isLoggedIn = computed(() => this.currentUser() !== null);
  readonly isAdmin    = computed(() => this.currentUser()?.role === 'hr_admin');
  readonly userName   = computed(() => this.currentUser()?.displayName ?? '');

  /**
   * Validates credentials and starts a session.
   * @returns error message string if login fails, null on success.
   */
  login(username: string, password: string): string | null {
    const found = MOCK_CREDENTIALS.find(
      (c) => c.username === username.trim() && c.password === password,
    );
    if (!found) return 'მომხმარებლის სახელი ან პაროლი არასწორია';

    const user: AuthUser = {
      id:          found.id,
      username:    found.username,
      role:        found.role,
      displayName: found.displayName,
      employeeId:  found.employeeId,
    };
    try {
      sessionStorage.setItem(SESSION_KEY, JSON.stringify(user));
    } catch {
      // Fallback: session persists only in memory
    }
    this.currentUser.set(user);
    return null;
  }

  logout(): void {
    sessionStorage.removeItem(SESSION_KEY);
    this.currentUser.set(null);
    void this.router.navigate(['/login']);
  }

  /**
   * Role-Level Security check.
   * Admin can do anything; employee can only act on their own records.
   */
  canEditVacation(vacationEmployeeId: string): boolean {
    const user = this.currentUser();
    if (!user) return false;
    if (user.role === 'hr_admin') return true;
    return user.employeeId === vacationEmployeeId;
  }

  private loadSession(): AuthUser | null {
    try {
      const raw = sessionStorage.getItem(SESSION_KEY);
      return raw ? (JSON.parse(raw) as AuthUser) : null;
    } catch {
      return null;
    }
  }
}
