import { Injectable, inject } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { Department } from '../models/department.model';
import { StorageService } from './storage.service';

@Injectable({ providedIn: 'root' })
export class DepartmentService {
  private storage = inject(StorageService);
  private _departments$ = new BehaviorSubject<Department[]>(this.storage.getDepartments());

  get departments$(): Observable<Department[]> {
    return this._departments$.asObservable();
  }

  getAll(): Department[] {
    return this._departments$.value;
  }

  getById(id: string): Department | undefined {
    return this._departments$.value.find((d) => d.id === id);
  }

  isNameTaken(name: string, excludeId?: string): boolean {
    return this._departments$.value.some(
      (d) => d.name.trim().toLowerCase() === name.trim().toLowerCase() && d.id !== excludeId
    );
  }

  add(data: Omit<Department, 'id'>): Department {
    const dept: Department = { id: crypto.randomUUID(), ...data };
    this.persist([...this._departments$.value, dept]);
    return dept;
  }

  update(id: string, data: Partial<Omit<Department, 'id'>>): void {
    this.persist(
      this._departments$.value.map((d) => (d.id === id ? { ...d, ...data } : d))
    );
  }

  delete(id: string): void {
    this.persist(this._departments$.value.filter((d) => d.id !== id));
  }

  reload(): void {
    this._departments$.next(this.storage.getDepartments());
  }

  private persist(departments: Department[]): void {
    this.storage.setDepartments(departments);
    this._departments$.next(departments);
  }
}
