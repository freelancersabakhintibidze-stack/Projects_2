import { Injectable, inject } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { VacationRequest, VacationStatus } from '../models/vacation.model';
import { StorageService } from './storage.service';
import { EmployeeService } from './employee.service';

@Injectable({ providedIn: 'root' })
export class VacationService {
  private storage        = inject(StorageService);
  private employeeService = inject(EmployeeService);
  private _vacations$ = new BehaviorSubject<VacationRequest[]>(this.storage.getVacations());

  get vacations$(): Observable<VacationRequest[]> {
    return this._vacations$.asObservable();
  }

  getAll(): VacationRequest[] {
    return this._vacations$.value;
  }

  getByEmployee(employeeId: string): VacationRequest[] {
    return this._vacations$.value.filter((v) => v.employeeId === employeeId);
  }

  hasOverlap(employeeId: string, startDate: string, endDate: string, excludeId?: string): boolean {
    return this._vacations$.value
      .filter((v) => v.employeeId === employeeId && v.status === 'approved' && v.id !== excludeId)
      .some((v) => startDate <= v.endDate && endDate >= v.startDate);
  }

  add(data: Omit<VacationRequest, 'id' | 'createdAt'>): VacationRequest {
    const vacation: VacationRequest = {
      id: crypto.randomUUID(),
      createdAt: new Date().toISOString(),
      ...data,
    };
    this.persist([...this._vacations$.value, vacation]);
    return vacation;
  }

  updateStatus(id: string, status: VacationStatus): void {
    const vacation = this._vacations$.value.find((v) => v.id === id);
    if (!vacation) return;

    const updated = this._vacations$.value.map((v) =>
      v.id === id ? { ...v, status } : v
    );
    this.persist(updated);

    // Business rule: if approved and currently active → set employee to onLeave
    if (status === 'approved') {
      const today = new Date().toISOString().split('T')[0];
      if (vacation.startDate <= today && vacation.endDate >= today) {
        this.employeeService.setStatus(vacation.employeeId, 'onLeave');
      }
    }
  }

  deleteByEmployee(employeeId: string): void {
    this.persist(this._vacations$.value.filter((v) => v.employeeId !== employeeId));
  }

  reload(): void {
    this._vacations$.next(this.storage.getVacations());
  }

  private persist(vacations: VacationRequest[]): void {
    this.storage.setVacations(vacations);
    this._vacations$.next(vacations);
  }
}
