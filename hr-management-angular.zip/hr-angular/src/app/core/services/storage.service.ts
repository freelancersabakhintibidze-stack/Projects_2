import { Injectable } from '@angular/core';
import { Employee } from '../models/employee.model';
import { Department } from '../models/department.model';
import { Position } from '../models/position.model';
import { VacationRequest } from '../models/vacation.model';

const KEYS = {
  EMPLOYEES:   'hr_employees',
  DEPARTMENTS: 'hr_departments',
  POSITIONS:   'hr_positions',
  VACATIONS:   'hr_vacations',
  INITIALIZED: 'hr_initialized',
} as const;

const SEED_DEPARTMENTS: Department[] = [
  { id: 'd1', name: 'განვითარება',       description: 'პროგრამული უზრუნველყოფის შემუშავება', headEmployeeId: 'e1' },
  { id: 'd2', name: 'ხარისხის კონტროლი', description: 'პროდუქტის ხარისხის უზრუნველყოფა',      headEmployeeId: 'e6' },
  { id: 'd3', name: 'DevOps',             description: 'ინფრასტრუქტურა და CI/CD',              headEmployeeId: 'e11' },
  { id: 'd4', name: 'პროდუქტის მართვა',  description: 'პროდუქტის სტრატეგია და განვითარება' },
];

const SEED_POSITIONS: Position[] = [
  { id: 'p1', title: 'Frontend დეველოპერი', level: 'Senior', minSalary: 3000, maxSalary: 6000 },
  { id: 'p2', title: 'Backend დეველოპერი',  level: 'Middle', minSalary: 2500, maxSalary: 5500 },
  { id: 'p3', title: 'QA ინჟინერი',         level: 'Junior', minSalary: 1500, maxSalary: 3500 },
  { id: 'p4', title: 'DevOps ინჟინერი',     level: 'Lead',   minSalary: 4000, maxSalary: 8000 },
  { id: 'p5', title: 'პროდუქტ მენეჯერი',   level: 'Senior', minSalary: 3500, maxSalary: 7000 },
];

const SEED_EMPLOYEES: Employee[] = [
  { id:'e1',  firstName:'გიორგი',  lastName:'მამულაშვილი', email:'giorgi.m@company.ge',  phone:'595123456', departmentId:'d1', positionId:'p1', salary:5200, hireDate:'2021-03-15', status:'active',    birthDate:'1990-07-12' },
  { id:'e2',  firstName:'ნინო',    lastName:'კვარაცხელია', email:'nino.k@company.ge',    phone:'599234567', departmentId:'d1', positionId:'p2', salary:4100, hireDate:'2022-01-10', status:'active',    birthDate:'1993-04-22' },
  { id:'e3',  firstName:'დავით',   lastName:'ბერიძე',      email:'davit.b@company.ge',   phone:'598345678', departmentId:'d1', positionId:'p1', salary:4800, hireDate:'2020-08-01', status:'onLeave',   birthDate:'1988-11-30' },
  { id:'e4',  firstName:'ანა',     lastName:'გელაშვილი',  email:'ana.g@company.ge',     phone:'591456789', departmentId:'d1', positionId:'p2', salary:3500, hireDate:'2023-04-18', status:'active',    birthDate:'1995-02-14' },
  { id:'e5',  firstName:'ლუკა',    lastName:'ჯანელიძე',   email:'luka.j@company.ge',    phone:'593567890', departmentId:'d1', positionId:'p1', salary:5500, hireDate:'2019-06-25', status:'active',    birthDate:'1987-09-08' },
  { id:'e6',  firstName:'მარიამ',  lastName:'ხოჭოლავა',   email:'mariam.kh@company.ge', phone:'577678901', departmentId:'d2', positionId:'p3', salary:3200, hireDate:'2022-07-05', status:'active',    birthDate:'1992-01-19' },
  { id:'e7',  firstName:'ნიკა',    lastName:'სხირტლაძე',  email:'nika.s@company.ge',    phone:'571789012', departmentId:'d2', positionId:'p3', salary:2800, hireDate:'2023-09-12', status:'active',    birthDate:'1997-06-03' },
  { id:'e8',  firstName:'თამარ',   lastName:'ჩიქოვანი',   email:'tamar.ch@company.ge',  phone:'555890123', departmentId:'d2', positionId:'p3', salary:2600, hireDate:'2024-01-22', status:'active',    birthDate:'1999-12-15' },
  { id:'e9',  firstName:'ბექა',    lastName:'ღვინიაშვილი',email:'beka.g@company.ge',    phone:'568901234', departmentId:'d2', positionId:'p3', salary:3000, hireDate:'2022-11-08', status:'active',    birthDate:'1994-08-27' },
  { id:'e10', firstName:'სალომე',  lastName:'ბაგრატიონი', email:'salome.b@company.ge',  phone:'579012345', departmentId:'d2', positionId:'p3', salary:2700, hireDate:'2023-06-30', status:'terminated',birthDate:'1998-03-11' },
  { id:'e11', firstName:'ზურაბ',   lastName:'ელიაშვილი',  email:'zurab.e@company.ge',   phone:'595123789', departmentId:'d3', positionId:'p4', salary:7500, hireDate:'2018-02-14', status:'active',    birthDate:'1985-05-20' },
  { id:'e12', firstName:'ქეთევან', lastName:'ნადირაძე',   email:'ketevan.n@company.ge', phone:'599234890', departmentId:'d3', positionId:'p4', salary:5800, hireDate:'2020-10-01', status:'active',    birthDate:'1991-10-07' },
  { id:'e13', firstName:'ირაკლი',  lastName:'ლომიძე',     email:'irakli.l@company.ge',  phone:'598345901', departmentId:'d3', positionId:'p4', salary:5200, hireDate:'2021-05-17', status:'active',    birthDate:'1989-07-25' },
  { id:'e14', firstName:'ელენე',   lastName:'ტაბატაძე',   email:'elene.t@company.ge',   phone:'591456012', departmentId:'d4', positionId:'p5', salary:6500, hireDate:'2020-03-09', status:'active',    birthDate:'1990-02-28' },
  { id:'e15', firstName:'გვანცა',  lastName:'ფარჯიანი',   email:'gvantsa.p@company.ge', phone:'593567123', departmentId:'d4', positionId:'p5', salary:5900, hireDate:'2021-11-23', status:'active',    birthDate:'1993-09-16' },
];

const SEED_VACATIONS: VacationRequest[] = [
  { id:'v1', employeeId:'e3',  startDate:'2025-07-01', endDate:'2025-07-14', type:'paid',   status:'approved', comment:'ზაფხულის შვებულება',  createdAt:'2025-06-15T10:00:00Z' },
  { id:'v2', employeeId:'e7',  startDate:'2025-07-20', endDate:'2025-07-25', type:'paid',   status:'pending',  comment:'',                    createdAt:'2025-07-01T09:30:00Z' },
  { id:'v3', employeeId:'e2',  startDate:'2025-08-01', endDate:'2025-08-10', type:'unpaid', status:'pending',  comment:'ოჯახური საქმეები',    createdAt:'2025-07-05T14:00:00Z' },
  { id:'v4', employeeId:'e5',  startDate:'2025-06-01', endDate:'2025-06-05', type:'sick',   status:'approved', comment:'ავადმყოფობა',          createdAt:'2025-06-01T08:00:00Z' },
  { id:'v5', employeeId:'e12', startDate:'2025-09-15', endDate:'2025-09-20', type:'paid',   status:'rejected', comment:'',                    createdAt:'2025-07-10T11:00:00Z' },
];

@Injectable({ providedIn: 'root' })
export class StorageService {

  initialize(): void {
    if (this.safeGet(KEYS.INITIALIZED)) return;
    this.setDepartments(SEED_DEPARTMENTS);
    this.setPositions(SEED_POSITIONS);
    this.setEmployees(SEED_EMPLOYEES);
    this.setVacations(SEED_VACATIONS);
    this.safeSet(KEYS.INITIALIZED, 'true');
  }

  reset(): void {
    this.safeRemove(KEYS.INITIALIZED);
    this.initialize();
  }

  /* ---- Employees ---- */
  getEmployees(): Employee[]          { return this.parse<Employee[]>(KEYS.EMPLOYEES) ?? []; }
  setEmployees(v: Employee[]): void   { this.safeSet(KEYS.EMPLOYEES, JSON.stringify(v)); }

  /* ---- Departments ---- */
  getDepartments(): Department[]         { return this.parse<Department[]>(KEYS.DEPARTMENTS) ?? []; }
  setDepartments(v: Department[]): void  { this.safeSet(KEYS.DEPARTMENTS, JSON.stringify(v)); }

  /* ---- Positions ---- */
  getPositions(): Position[]         { return this.parse<Position[]>(KEYS.POSITIONS) ?? []; }
  setPositions(v: Position[]): void  { this.safeSet(KEYS.POSITIONS, JSON.stringify(v)); }

  /* ---- Vacations ---- */
  getVacations(): VacationRequest[]         { return this.parse<VacationRequest[]>(KEYS.VACATIONS) ?? []; }
  setVacations(v: VacationRequest[]): void  { this.safeSet(KEYS.VACATIONS, JSON.stringify(v)); }

  /* ---- Export / Import ---- */
  exportAll(): string {
    return JSON.stringify({
      employees:   this.getEmployees(),
      departments: this.getDepartments(),
      positions:   this.getPositions(),
      vacations:   this.getVacations(),
    }, null, 2);
  }

  importAll(json: string): void {
    const data = JSON.parse(json) as {
      employees?: Employee[];
      departments?: Department[];
      positions?: Position[];
      vacations?: VacationRequest[];
    };
    if (data.employees)   this.setEmployees(data.employees);
    if (data.departments) this.setDepartments(data.departments);
    if (data.positions)   this.setPositions(data.positions);
    if (data.vacations)   this.setVacations(data.vacations);
  }

  /* ---- Safe localStorage wrappers (bulletproof) ---- */
  private safeGet(key: string): string | null {
    try {
      return localStorage.getItem(key);
    } catch {
      return null; // SecurityError or similar
    }
  }

  private safeSet(key: string, value: string): void {
    try {
      localStorage.setItem(key, value);
    } catch (err) {
      // QuotaExceededError — propagate so GlobalErrorHandler can notify the user
      throw err;
    }
  }

  private safeRemove(key: string): void {
    try {
      localStorage.removeItem(key);
    } catch {
      // Silently ignore removal errors
    }
  }

  private parse<T>(key: string): T | null {
    const raw = this.safeGet(key);
    if (!raw) return null;
    try {
      return JSON.parse(raw) as T;
    } catch {
      return null; // Corrupted data — treat as empty
    }
  }
}
