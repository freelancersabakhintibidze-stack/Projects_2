import { TestBed } from '@angular/core/testing';
import { Router } from '@angular/router';
import { AuthService } from './auth.service';

describe('AuthService', () => {
  let service: AuthService;
  let routerSpy: jasmine.SpyObj<Router>;

  beforeEach(() => {
    sessionStorage.clear();
    routerSpy = jasmine.createSpyObj('Router', ['navigate']);

    TestBed.configureTestingModule({
      providers: [
        AuthService,
        { provide: Router, useValue: routerSpy },
      ],
    });
    service = TestBed.inject(AuthService);
  });

  afterEach(() => sessionStorage.clear());

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  describe('initial state', () => {
    it('should not be logged in initially', () => {
      expect(service.isLoggedIn()).toBeFalse();
    });

    it('should have null currentUser initially', () => {
      expect(service.currentUser()).toBeNull();
    });
  });

  describe('login()', () => {
    it('should return null on valid admin credentials', () => {
      const err = service.login('admin', 'admin123');
      expect(err).toBeNull();
    });

    it('should set currentUser to hr_admin role', () => {
      service.login('admin', 'admin123');
      expect(service.currentUser()?.role).toBe('hr_admin');
    });

    it('should return null on valid user credentials', () => {
      const err = service.login('user', 'user123');
      expect(err).toBeNull();
    });

    it('should set currentUser to employee role', () => {
      service.login('user', 'user123');
      expect(service.currentUser()?.role).toBe('employee');
    });

    it('should return error message on wrong password', () => {
      const err = service.login('admin', 'wrong');
      expect(err).toBeTruthy();
    });

    it('should return error message on unknown username', () => {
      const err = service.login('nobody', 'pass');
      expect(err).toBeTruthy();
    });

    it('should set isLoggedIn to true after successful login', () => {
      service.login('admin', 'admin123');
      expect(service.isLoggedIn()).toBeTrue();
    });

    it('should set isAdmin to true for hr_admin', () => {
      service.login('admin', 'admin123');
      expect(service.isAdmin()).toBeTrue();
    });

    it('should set isAdmin to false for employee', () => {
      service.login('user', 'user123');
      expect(service.isAdmin()).toBeFalse();
    });
  });

  describe('logout()', () => {
    it('should clear currentUser', () => {
      service.login('admin', 'admin123');
      service.logout();
      expect(service.currentUser()).toBeNull();
    });

    it('should set isLoggedIn to false', () => {
      service.login('admin', 'admin123');
      service.logout();
      expect(service.isLoggedIn()).toBeFalse();
    });

    it('should navigate to /login', () => {
      service.login('admin', 'admin123');
      service.logout();
      expect(routerSpy.navigate).toHaveBeenCalledWith(['/login']);
    });
  });

  describe('canEditVacation()', () => {
    it('should return false when not logged in', () => {
      expect(service.canEditVacation('e1')).toBeFalse();
    });

    it('should return true for admin regardless of employeeId', () => {
      service.login('admin', 'admin123');
      expect(service.canEditVacation('any-employee-id')).toBeTrue();
    });

    it('should return true for employee editing their own vacation', () => {
      service.login('user', 'user123');
      const empId = service.currentUser()?.employeeId ?? '';
      expect(service.canEditVacation(empId)).toBeTrue();
    });

    it('should return false for employee editing another vacation', () => {
      service.login('user', 'user123');
      expect(service.canEditVacation('some-other-employee')).toBeFalse();
    });
  });

  describe('session persistence', () => {
    it('should restore session from sessionStorage', () => {
      service.login('admin', 'admin123');
      // Simulate page reload: create a new instance that reads sessionStorage
      const newService = new AuthService();
      expect(newService.isLoggedIn()).toBeTrue();
    });
  });
});
