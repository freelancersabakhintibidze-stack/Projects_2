import { TestBed } from '@angular/core/testing';
import { StorageService } from './storage.service';

describe('StorageService', () => {
  let service: StorageService;

  beforeEach(() => {
    localStorage.clear();
    TestBed.configureTestingModule({});
    service = TestBed.inject(StorageService);
  });

  afterEach(() => {
    localStorage.clear();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  describe('initialize()', () => {
    it('should seed all four entity types on first call', () => {
      service.initialize();
      expect(service.getEmployees().length).toBeGreaterThan(0);
      expect(service.getDepartments().length).toBeGreaterThan(0);
      expect(service.getPositions().length).toBeGreaterThan(0);
      expect(service.getVacations().length).toBeGreaterThan(0);
    });

    it('should not overwrite existing data on second call', () => {
      service.initialize();
      const originalCount = service.getEmployees().length;
      service.initialize(); // second call — should be no-op
      expect(service.getEmployees().length).toBe(originalCount);
    });
  });

  describe('Employees CRUD', () => {
    beforeEach(() => service.initialize());

    it('should persist employees to localStorage', () => {
      const employees = service.getEmployees();
      expect(employees.length).toBeGreaterThanOrEqual(15);
    });

    it('should round-trip employee data', () => {
      const original = service.getEmployees();
      service.setEmployees(original);
      const reloaded = service.getEmployees();
      expect(reloaded).toEqual(original);
    });

    it('should return empty array when key is missing', () => {
      localStorage.removeItem('hr_employees');
      expect(service.getEmployees()).toEqual([]);
    });
  });

  describe('reset()', () => {
    it('should restore seed data', () => {
      service.initialize();
      service.setEmployees([]); // wipe
      expect(service.getEmployees().length).toBe(0);
      service.reset();
      expect(service.getEmployees().length).toBeGreaterThan(0);
    });
  });

  describe('exportAll / importAll', () => {
    beforeEach(() => service.initialize());

    it('should export valid JSON with all four keys', () => {
      const json   = service.exportAll();
      const parsed = JSON.parse(json) as Record<string, unknown>;
      expect(parsed['employees']).toBeDefined();
      expect(parsed['departments']).toBeDefined();
      expect(parsed['positions']).toBeDefined();
      expect(parsed['vacations']).toBeDefined();
    });

    it('should import and overwrite existing data', () => {
      const backup = service.exportAll();
      service.setEmployees([]);
      service.importAll(backup);
      expect(service.getEmployees().length).toBeGreaterThan(0);
    });
  });

  describe('corrupted data resilience', () => {
    it('should return empty array for corrupted employees JSON', () => {
      localStorage.setItem('hr_employees', '{ not valid json !!');
      expect(service.getEmployees()).toEqual([]);
    });
  });
});
