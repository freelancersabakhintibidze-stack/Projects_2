import { Injectable, inject } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { Position } from '../models/position.model';
import { StorageService } from './storage.service';

@Injectable({ providedIn: 'root' })
export class PositionService {
  private storage = inject(StorageService);
  private _positions$ = new BehaviorSubject<Position[]>(this.storage.getPositions());

  get positions$(): Observable<Position[]> {
    return this._positions$.asObservable();
  }

  getAll(): Position[] {
    return this._positions$.value;
  }

  getById(id: string): Position | undefined {
    return this._positions$.value.find((p) => p.id === id);
  }

  add(data: Omit<Position, 'id'>): Position {
    const position: Position = { id: crypto.randomUUID(), ...data };
    this.persist([...this._positions$.value, position]);
    return position;
  }

  update(id: string, data: Partial<Omit<Position, 'id'>>): void {
    this.persist(
      this._positions$.value.map((p) => (p.id === id ? { ...p, ...data } : p))
    );
  }

  delete(id: string): void {
    this.persist(this._positions$.value.filter((p) => p.id !== id));
  }

  reload(): void {
    this._positions$.next(this.storage.getPositions());
  }

  private persist(positions: Position[]): void {
    this.storage.setPositions(positions);
    this._positions$.next(positions);
  }
}
