import { ErrorHandler, Injectable, inject, NgZone } from '@angular/core';
import { environment } from '../../../environments/environment';
import { ToastService } from '../services/toast.service';

@Injectable()
export class GlobalErrorHandler implements ErrorHandler {
  private toast  = inject(ToastService);
  private zone   = inject(NgZone);

  handleError(error: unknown): void {
    const message = this.extractMessage(error);

    // Only log in debug mode — strips all output in production
    if (environment.debug) {
      console.error('[GlobalErrorHandler]', error);
    }

    // Quota-exceeded: user-facing recovery message
    if (message.includes('QuotaExceededError') || message.includes('quota')) {
      this.zone.run(() =>
        this.toast.error('შენახვის სივრცე ამოიწურა — გთხოვთ გაათავისუფლოთ ადგილი'),
      );
      return;
    }

    // Generic user-facing error — don't expose internals in production
    const userMessage = environment.production
      ? 'მოულოდნელი შეცდომა. გთხოვთ სცადოთ ხელახლა.'
      : `შეცდომა: ${message}`;

    this.zone.run(() => this.toast.error(userMessage));
  }

  private extractMessage(error: unknown): string {
    if (error instanceof Error) return error.message;
    if (typeof error === 'string') return error;
    try { return JSON.stringify(error); } catch { return 'Unknown error'; }
  }
}
