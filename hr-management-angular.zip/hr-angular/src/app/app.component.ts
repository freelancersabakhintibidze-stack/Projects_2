import {
  Component, OnInit, inject,
  ChangeDetectionStrategy, signal, DestroyRef,
} from '@angular/core';
import { RouterOutlet, Router, NavigationEnd } from '@angular/router';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { filter } from 'rxjs/operators';
import { StorageService } from './core/services/storage.service';
import { SidebarComponent } from './shared/components/sidebar/sidebar.component';
import { HeaderComponent } from './shared/components/header/header.component';
import { ToastComponent } from './shared/components/toast/toast.component';

const ROUTE_TITLES: Record<string, string> = {
  '/dashboard':   'მთავარი',
  '/employees':   'თანამშრომლები',
  '/departments': 'დეპარტამენტები',
  '/positions':   'პოზიციები',
  '/vacations':   'შვებულებები',
  '/settings':    'პარამეტრები',
};

@Component({
  selector: 'app-root',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [RouterOutlet, SidebarComponent, HeaderComponent, ToastComponent],
  template: `
    @if (showLayout()) {
      <div class="app-layout">
        <app-sidebar />
        <div class="main-area">
          <app-header [title]="pageTitle()" />
          <main class="main-content">
            <router-outlet />
          </main>
        </div>
      </div>
    } @else {
      <router-outlet />
    }
    <app-toast />
  `,
  styles: [`
    .app-layout {
      display: flex;
      height: 100vh;
      overflow: hidden;
    }
    .main-area {
      flex: 1;
      display: flex;
      flex-direction: column;
      min-width: 0;
      overflow: hidden;
    }
    .main-content {
      flex: 1;
      overflow-y: auto;
    }
  `],
})
export class AppComponent implements OnInit {
  private storage    = inject(StorageService);
  private router     = inject(Router);
  private destroyRef = inject(DestroyRef);

  showLayout = signal(false);
  pageTitle  = signal('');

  ngOnInit(): void {
    this.storage.initialize();

    // takeUntilDestroyed(this.destroyRef) automatically unsubscribes when
    // the component is destroyed, preventing memory leaks.
    this.router.events
      .pipe(
        filter((e): e is NavigationEnd => e instanceof NavigationEnd),
        takeUntilDestroyed(this.destroyRef),
      )
      .subscribe((e) => {
        const url = e.urlAfterRedirects;
        const isLoginPage = url === '/login' || url.startsWith('/login?');
        this.showLayout.set(!isLoginPage);
        this.pageTitle.set(this.resolveTitle(url));
      });
  }

  private resolveTitle(url: string): string {
    if (url.includes('/new'))  return 'თანამშრომლის დამატება';
    if (url.includes('/edit')) return 'თანამშრომლის რედაქტირება';
    for (const [key, title] of Object.entries(ROUTE_TITLES)) {
      if (url === key || url.startsWith(`${key}/`)) return title;
    }
    return 'HR სისტემა';
  }
}
