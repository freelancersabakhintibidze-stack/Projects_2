// Karma configuration file — used by `ng test`
// https://karma-runner.github.io/latest/config/configuration-file.html

'use strict';

module.exports = function (config) {
  config.set({
    basePath: '',
    frameworks: ['jasmine', '@angular-devkit/build-angular'],
    plugins: [
      require('karma-jasmine'),
      require('karma-chrome-launcher'),
      require('karma-jasmine-html-reporter'),
      require('karma-coverage'),
      require('@angular-devkit/build-angular/plugins/karma'),
    ],
    client: {
      jasmine: {
        // Randomise test order to catch order-dependent failures
        random: true,
        seed: 4321,
        failFast: false,
      },
      clearContext: false,
    },
    jasmineHtmlReporter: {
      suppressAll: true,
    },
    coverageReporter: {
      dir:     require('path').join(__dirname, './coverage/hr-management'),
      subdir:  '.',
      reporters: [
        { type: 'html' },
        { type: 'text-summary' },
        { type: 'lcovonly' },  // Required for codecov / GitHub Actions upload
      ],
      check: {
        global: {
          statements: 60,
          branches:   50,
          functions:  60,
          lines:      60,
        },
      },
    },
    reporters: ['progress', 'kjhtml'],
    browsers: ['ChromeHeadless'],
    customLaunchers: {
      ChromeHeadlessCI: {
        base: 'ChromeHeadless',
        flags: ['--no-sandbox', '--disable-gpu', '--disable-dev-shm-usage'],
      },
    },
    restartOnFileChange: true,
    singleRun: false,
    logLevel: config.LOG_INFO,
  });
};
