# InvoiceFlow AI

A full-stack invoicing SaaS for freelancers — create invoices in seconds, track payment status, and generate payment reminder emails in three tones (Friendly, Firm, Final Notice). No API key required.

## Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | React + Vite + Tailwind CSS + shadcn/ui |
| Backend | Node.js + Express 5 |
| Database | PostgreSQL + Drizzle ORM |
| Auth | JWT (jsonwebtoken) + bcrypt |
| Monorepo | pnpm workspaces |

---

## Prerequisites

- **Node.js** 20+ — https://nodejs.org
- **pnpm** 9+ — `npm install -g pnpm`
- **PostgreSQL** — running locally or a hosted instance (e.g. Supabase, Neon, Railway — all have free tiers)

---

## Quick Start

### 1. Install dependencies

```bash
pnpm install
```

### 2. Set environment variables

Create a `.env` file in the project root:

```env
# PostgreSQL connection string
DATABASE_URL=postgresql://USER:PASSWORD@localhost:5432/invoiceflow

# JWT signing secret — use any long random string
JWT_SECRET=change-me-to-a-long-random-secret

# Session secret (optional, used for future session support)
SESSION_SECRET=another-long-random-secret
```

### 3. Push the database schema

```bash
pnpm --filter @workspace/db run push
```

This creates the `users` and `invoices` tables in your database.

### 4. Run the development servers

**Terminal 1 — API server (port 8080):**
```bash
pnpm --filter @workspace/api-server run dev
```

**Terminal 2 — Frontend (port auto-assigned):**
```bash
pnpm --filter @workspace/invoice-flow run dev
```

Then open the URL shown in Terminal 2 (e.g. `http://localhost:5173`).

---

## Seed Demo Data (optional)

After starting the API server, create a demo account and invoices:

```bash
# 1. Sign up
curl -X POST http://localhost:8080/api/auth/signup \
  -H "Content-Type: application/json" \
  -d '{"name":"Demo User","email":"demo@example.com","password":"demo1234","businessName":"Demo Studio"}'

# 2. Grab the token from the response, then seed invoices:
TOKEN="<paste token here>"

curl -X POST http://localhost:8080/api/invoices \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"clientName":"Acme Corp","clientEmail":"billing@acme.com","amount":4500,"dueDate":"2026-05-15","description":"Website redesign","status":"overdue"}'

curl -X POST http://localhost:8080/api/invoices \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"clientName":"Bright Media","clientEmail":"finance@bright.io","amount":2800,"dueDate":"2026-06-30","description":"Brand identity","status":"unpaid"}'

curl -X POST http://localhost:8080/api/invoices \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"clientName":"Nexus Software","clientEmail":"ap@nexus.com","amount":7200,"dueDate":"2026-04-01","description":"Mobile app design","status":"paid"}'
```

---

## Project Structure

```
invoiceflow-ai/
├── artifacts/
│   ├── api-server/          # Express backend
│   │   └── src/
│   │       ├── routes/      # auth.ts, invoices.ts, users.ts, health.ts
│   │       ├── middlewares/ # auth.ts (JWT requireAuth + signToken)
│   │       └── index.ts     # Express app entry
│   └── invoice-flow/        # React + Vite frontend
│       └── src/
│           ├── pages/       # landing, login, signup, dashboard, invoice-form, settings
│           ├── components/  # layout.tsx + shadcn/ui components
│           └── contexts/    # AuthContext.tsx
├── lib/
│   ├── db/                  # Drizzle ORM schema + client
│   │   └── src/schema/      # users.ts, invoices.ts
│   ├── api-spec/            # OpenAPI specification (source of truth)
│   └── api-client-react/    # Generated React Query hooks + Zod schemas
├── pnpm-workspace.yaml
└── README.md
```

---

## Features

### Dashboard
- Stat cards: total revenue, outstanding balance, overdue amount, paid invoice count
- Invoice table with status badges (paid / unpaid / overdue)
- Create, edit, delete invoices

### AI Reminder Emails (no API key!)
- Click the mail icon on any unpaid or overdue invoice
- Choose a tone: **Friendly**, **Firm**, or **Final Notice**
- Get a complete, ready-to-send email (subject + body) in under a second
- One-click copy to clipboard

### Auth
- Signup and login with email + password
- JWT tokens (30-day expiry) stored in localStorage
- All protected routes redirect to `/login` when unauthenticated

### Settings
- Update name, email, and business name
- Business name appears in all generated reminder emails

---

## API Endpoints

| Method | Path | Auth | Description |
|--------|------|------|-------------|
| POST | `/api/auth/signup` | — | Create account |
| POST | `/api/auth/login` | — | Login |
| GET | `/api/auth/me` | JWT | Get current user |
| GET | `/api/invoices` | JWT | List all invoices |
| POST | `/api/invoices` | JWT | Create invoice |
| GET | `/api/invoices/stats` | JWT | Get invoice statistics |
| GET | `/api/invoices/:id` | JWT | Get single invoice |
| PATCH | `/api/invoices/:id` | JWT | Update invoice |
| DELETE | `/api/invoices/:id` | JWT | Delete invoice |
| POST | `/api/invoices/:id/reminder` | JWT | Generate reminder email |
| PATCH | `/api/users/me` | JWT | Update profile |

---

## Production Build

```bash
# Build the API server
pnpm --filter @workspace/api-server run build

# Build the frontend
pnpm --filter @workspace/invoice-flow run build
```

The API server builds to `artifacts/api-server/dist/index.mjs`.  
The frontend builds to `artifacts/invoice-flow/dist/`.

---

## Environment Variables Reference

| Variable | Required | Description |
|----------|----------|-------------|
| `DATABASE_URL` | Yes | PostgreSQL connection string |
| `JWT_SECRET` | Yes | Secret for signing JWT tokens |
| `SESSION_SECRET` | No | Secret for session middleware |
| `PORT` | No | API server port (default: 8080) |

---

## License

MIT — free to use, modify, and distribute.
