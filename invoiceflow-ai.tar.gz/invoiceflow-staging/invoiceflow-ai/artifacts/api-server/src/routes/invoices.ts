import { Router, type IRouter } from "express";
import { db, invoicesTable, usersTable } from "@workspace/db";
import { eq, and, sql } from "drizzle-orm";
import {
  CreateInvoiceBody,
  UpdateInvoiceBody,
  GetInvoiceParams,
  UpdateInvoiceParams,
  DeleteInvoiceParams,
  GenerateReminderParams,
  GenerateReminderBody,
} from "@workspace/api-zod";
import { requireAuth } from "../middlewares/auth";

const router: IRouter = Router();

function formatInvoice(inv: typeof invoicesTable.$inferSelect) {
  return {
    id: inv.id,
    userId: inv.userId,
    clientName: inv.clientName,
    clientEmail: inv.clientEmail,
    amount: parseFloat(inv.amount),
    dueDate: inv.dueDate,
    description: inv.description ?? null,
    status: inv.status,
    createdAt: inv.createdAt.toISOString(),
    updatedAt: inv.updatedAt.toISOString(),
  };
}

router.get("/invoices", requireAuth, async (req, res): Promise<void> => {
  const invoices = await db
    .select()
    .from(invoicesTable)
    .where(eq(invoicesTable.userId, req.auth!.userId))
    .orderBy(invoicesTable.createdAt);
  res.json(invoices.map(formatInvoice));
});

router.post("/invoices", requireAuth, async (req, res): Promise<void> => {
  const parsed = CreateInvoiceBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [invoice] = await db
    .insert(invoicesTable)
    .values({
      ...parsed.data,
      amount: String(parsed.data.amount),
      userId: req.auth!.userId,
      status: parsed.data.status ?? "unpaid",
    })
    .returning();

  res.status(201).json(formatInvoice(invoice));
});

router.get("/invoices/stats", requireAuth, async (req, res): Promise<void> => {
  const userId = req.auth!.userId;
  const rows = await db
    .select()
    .from(invoicesTable)
    .where(eq(invoicesTable.userId, userId));

  const stats = rows.reduce(
    (acc, inv) => {
      const amount = parseFloat(inv.amount);
      acc.total += 1;
      if (inv.status === "paid") {
        acc.paid += 1;
        acc.totalRevenue += amount;
      } else if (inv.status === "unpaid") {
        acc.unpaid += 1;
        acc.outstandingAmount += amount;
      } else if (inv.status === "overdue") {
        acc.overdue += 1;
        acc.overdueAmount += amount;
        acc.outstandingAmount += amount;
      }
      return acc;
    },
    { total: 0, paid: 0, unpaid: 0, overdue: 0, totalRevenue: 0, outstandingAmount: 0, overdueAmount: 0 }
  );

  res.json(stats);
});

router.get("/invoices/:id", requireAuth, async (req, res): Promise<void> => {
  const params = GetInvoiceParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [invoice] = await db
    .select()
    .from(invoicesTable)
    .where(and(eq(invoicesTable.id, params.data.id), eq(invoicesTable.userId, req.auth!.userId)));

  if (!invoice) {
    res.status(404).json({ error: "Invoice not found" });
    return;
  }

  res.json(formatInvoice(invoice));
});

router.patch("/invoices/:id", requireAuth, async (req, res): Promise<void> => {
  const params = UpdateInvoiceParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const parsed = UpdateInvoiceBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const updateData: Record<string, unknown> = { ...parsed.data };
  if (parsed.data.amount !== undefined) {
    updateData.amount = String(parsed.data.amount);
  }

  const [invoice] = await db
    .update(invoicesTable)
    .set(updateData)
    .where(and(eq(invoicesTable.id, params.data.id), eq(invoicesTable.userId, req.auth!.userId)))
    .returning();

  if (!invoice) {
    res.status(404).json({ error: "Invoice not found" });
    return;
  }

  res.json(formatInvoice(invoice));
});

router.delete("/invoices/:id", requireAuth, async (req, res): Promise<void> => {
  const params = DeleteInvoiceParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [deleted] = await db
    .delete(invoicesTable)
    .where(and(eq(invoicesTable.id, params.data.id), eq(invoicesTable.userId, req.auth!.userId)))
    .returning();

  if (!deleted) {
    res.status(404).json({ error: "Invoice not found" });
    return;
  }

  res.sendStatus(204);
});

router.post("/invoices/:id/reminder", requireAuth, async (req, res): Promise<void> => {
  const params = GenerateReminderParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const body = GenerateReminderBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }

  const [invoice] = await db
    .select()
    .from(invoicesTable)
    .where(and(eq(invoicesTable.id, params.data.id), eq(invoicesTable.userId, req.auth!.userId)));

  if (!invoice) {
    res.status(404).json({ error: "Invoice not found" });
    return;
  }

  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, req.auth!.userId));

  const amount = parseFloat(invoice.amount).toLocaleString("en-US", { style: "currency", currency: "USD" });
  const dueDate = new Date(invoice.dueDate).toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric" });
  const senderName = user?.name ?? "Your Service Provider";
  const businessName = user?.businessName ? user.businessName : senderName;
  const { tone } = body.data;

  let subject: string;
  let emailBody: string;

  if (tone === "friendly") {
    subject = `Friendly Reminder: Invoice for ${invoice.clientName} — ${amount} Due`;
    emailBody = `Hi ${invoice.clientName},

I hope you're doing well! I wanted to send a quick, friendly reminder that invoice payment of ${amount} was due on ${dueDate}.

${invoice.description ? `Services: ${invoice.description}\n\n` : ""}I understand things can get busy, so no worries if this slipped through. Could you take a moment to process this when you have a chance? If you have any questions or need to work out a payment arrangement, please don't hesitate to reach out.

Thank you so much for your continued support — it truly means a lot.

Warm regards,
${senderName}
${businessName}`;
  } else if (tone === "firm") {
    subject = `Payment Overdue: Invoice ${amount} — Action Required`;
    emailBody = `Dear ${invoice.clientName},

I'm writing to follow up on the outstanding invoice of ${amount}, which was due on ${dueDate} and remains unpaid.

${invoice.description ? `Services rendered: ${invoice.description}\n\n` : ""}Please arrange payment at your earliest convenience. If there is a dispute or issue with the invoice, I ask that you contact me within 3 business days so we can resolve it promptly.

Continued non-payment may result in late fees being applied to the outstanding balance.

Please treat this matter with urgency.

Regards,
${senderName}
${businessName}`;
  } else {
    subject = `FINAL NOTICE: Overdue Payment of ${amount} — Immediate Action Required`;
    emailBody = `Dear ${invoice.clientName},

This is a final notice regarding your outstanding payment of ${amount}, which was due on ${dueDate}.

${invoice.description ? `Services rendered: ${invoice.description}\n\n` : ""}Despite previous reminders, this invoice remains unpaid. You are hereby notified that if payment is not received within 7 days of this notice, I will have no choice but to pursue further action, which may include:

• Referral to a collections agency
• Legal action to recover the outstanding amount plus applicable fees
• Reporting to relevant credit bureaus

To avoid these consequences, please make payment immediately or contact me within 48 hours to discuss resolution.

This is your final opportunity to resolve this matter amicably.

${senderName}
${businessName}`;
  }

  res.json({ subject, body: emailBody });
});

export default router;
