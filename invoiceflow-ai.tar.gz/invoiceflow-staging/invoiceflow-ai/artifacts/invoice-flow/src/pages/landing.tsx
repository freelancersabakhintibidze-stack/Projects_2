import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { ArrowRight, CheckCircle2, Zap, Clock, ShieldCheck } from "lucide-react";
import { motion } from "framer-motion";

export default function Landing() {
  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col">
      <header className="h-20 border-b flex items-center justify-between px-6 lg:px-12 bg-card/80 backdrop-blur sticky top-0 z-50">
        <div className="font-bold text-xl tracking-tight text-primary flex items-center gap-2">
          <div className="w-8 h-8 rounded bg-primary flex items-center justify-center">
             <div className="w-3 h-3 bg-white rounded-sm" />
          </div>
          InvoiceFlow
        </div>
        <nav className="hidden md:flex gap-8 text-sm font-medium">
          <a href="#features" className="hover:text-primary transition-colors">Features</a>
          <a href="#pricing" className="hover:text-primary transition-colors">Pricing</a>
        </nav>
        <div className="flex gap-4 items-center">
          <Link href="/login" className="text-sm font-medium hover:text-primary transition-colors">
            Sign in
          </Link>
          <Link href="/signup">
            <Button>Get Started</Button>
          </Link>
        </div>
      </header>

      <main className="flex-1">
        {/* Hero Section */}
        <section className="py-24 lg:py-32 px-6 lg:px-12 text-center max-w-5xl mx-auto">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
            <h1 className="text-5xl lg:text-7xl font-extrabold tracking-tight mb-8 text-balance">
              Invoicing for freelancers who <span className="text-primary">value their time.</span>
            </h1>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto mb-10">
              Professional, clean, and fast. Create invoices in seconds, track payments effortlessly, and never let an overdue invoice slip through the cracks.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Link href="/signup">
                <Button size="lg" className="h-14 px-8 text-lg w-full sm:w-auto">
                  Start Invoicing Free
                  <ArrowRight className="ml-2 w-5 h-5" />
                </Button>
              </Link>
              <p className="text-sm text-muted-foreground sm:hidden mt-2">No credit card required</p>
            </div>
          </motion.div>
        </section>

        {/* Features Grid */}
        <section id="features" className="py-24 bg-secondary px-6 lg:px-12">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-16">
              <h2 className="text-3xl font-bold mb-4">Everything you need to get paid faster</h2>
              <p className="text-muted-foreground text-lg">Designed specifically for the modern independent professional.</p>
            </div>
            <div className="grid md:grid-cols-3 gap-8">
              {[
                {
                  icon: <Zap className="w-8 h-8 text-primary mb-4" />,
                  title: "Lightning Fast Creation",
                  description: "Draft professional invoices in seconds with our streamlined editor."
                },
                {
                  icon: <Clock className="w-8 h-8 text-primary mb-4" />,
                  title: "One-Click Reminders",
                  description: "Generate polite, firm, or final notice reminders instantly when clients are late."
                },
                {
                  icon: <ShieldCheck className="w-8 h-8 text-primary mb-4" />,
                  title: "Business Insights",
                  description: "See your total revenue, outstanding amounts, and business health at a glance."
                }
              ].map((feature, i) => (
                <div key={i} className="bg-card p-8 rounded-2xl border shadow-sm hover:shadow-md transition-shadow">
                  {feature.icon}
                  <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
                  <p className="text-muted-foreground leading-relaxed">{feature.description}</p>
                </div>
              ))}
            </div>
          </div>
        </section>
      </main>

      <footer className="py-12 border-t text-center text-muted-foreground">
        <p>&copy; {new Date().getFullYear()} InvoiceFlow AI. All rights reserved.</p>
      </footer>
    </div>
  );
}
