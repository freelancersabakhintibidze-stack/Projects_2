import { useState } from "react";
import { useLocation } from "wouter";
import {
  useListInvoices,
  useGetInvoiceStats,
  useDeleteInvoice,
  useGenerateReminder,
  getListInvoicesQueryKey,
  getGetInvoiceStatsQueryKey,
} from "@workspace/api-client-react";
import type { Invoice } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { DashboardLayout } from "@/components/layout";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useToast } from "@/hooks/use-toast";
import {
  PlusCircle,
  Pencil,
  Trash2,
  Mail,
  TrendingUp,
  Clock,
  AlertCircle,
  DollarSign,
  Copy,
  Check,
  Loader2,
} from "lucide-react";
import { motion } from "framer-motion";

const STATUS_COLORS: Record<string, string> = {
  paid: "bg-emerald-100 text-emerald-800",
  unpaid: "bg-amber-100 text-amber-800",
  overdue: "bg-red-100 text-red-800",
};

function fmt(amount: number) {
  return new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" }).format(amount);
}

function fmtDate(d: string) {
  return new Date(d + "T00:00:00").toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
  });
}

function StatCard({
  label,
  value,
  icon: Icon,
  color,
}: {
  label: string;
  value: string;
  icon: React.ElementType;
  color: string;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-card border border-border rounded-xl p-6"
    >
      <div className="flex items-start justify-between">
        <div>
          <p className="text-sm text-muted-foreground">{label}</p>
          <p className="text-2xl font-bold mt-1 tracking-tight">{value}</p>
        </div>
        <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${color}`}>
          <Icon className="w-5 h-5" />
        </div>
      </div>
    </motion.div>
  );
}

export default function Dashboard() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [, setLocation] = useLocation();

  const { data: invoices, isLoading: invLoading } = useListInvoices();
  const { data: stats, isLoading: statsLoading } = useGetInvoiceStats();
  const deleteMutation = useDeleteInvoice();
  const reminderMutation = useGenerateReminder();

  const [deleteId, setDeleteId] = useState<number | null>(null);
  const [reminderInvoice, setReminderInvoice] = useState<Invoice | null>(null);
  const [reminderTone, setReminderTone] = useState<"friendly" | "firm" | "final" | null>(null);
  const [reminderResult, setReminderResult] = useState<{ subject: string; body: string } | null>(null);
  const [copied, setCopied] = useState(false);

  const handleDelete = () => {
    if (deleteId === null) return;
    deleteMutation.mutate(
      { id: deleteId },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getListInvoicesQueryKey() });
          queryClient.invalidateQueries({ queryKey: getGetInvoiceStatsQueryKey() });
          toast({ title: "Invoice deleted" });
          setDeleteId(null);
        },
        onError: () => {
          toast({ title: "Failed to delete invoice", variant: "destructive" });
          setDeleteId(null);
        },
      }
    );
  };

  const handleGenerateReminder = (tone: "friendly" | "firm" | "final") => {
    if (!reminderInvoice) return;
    setReminderTone(tone);
    setReminderResult(null);
    reminderMutation.mutate(
      { id: reminderInvoice.id, data: { tone } },
      {
        onSuccess: (data) => setReminderResult(data),
        onError: () => toast({ title: "Failed to generate reminder", variant: "destructive" }),
      }
    );
  };

  const handleCopy = () => {
    if (!reminderResult) return;
    navigator.clipboard
      .writeText(`Subject: ${reminderResult.subject}\n\n${reminderResult.body}`)
      .catch(() => toast({ title: "Copy failed — please copy manually", variant: "destructive" }));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleReminderClose = () => {
    setReminderInvoice(null);
    setReminderResult(null);
    setReminderTone(null);
  };

  return (
    <DashboardLayout>
      <div className="space-y-8">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold tracking-tight">Invoices</h1>
            <p className="text-muted-foreground text-sm mt-1">Manage and track your client invoices</p>
          </div>
          <Button onClick={() => setLocation("/invoices/new")}>
            <PlusCircle className="w-4 h-4 mr-2" />
            New Invoice
          </Button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {statsLoading ? (
            Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-28 rounded-xl" />)
          ) : (
            <>
              <StatCard
                label="Total Revenue"
                value={fmt(stats?.totalRevenue ?? 0)}
                icon={TrendingUp}
                color="bg-primary/10 text-primary"
              />
              <StatCard
                label="Outstanding"
                value={fmt(stats?.outstandingAmount ?? 0)}
                icon={DollarSign}
                color="bg-amber-100 text-amber-600"
              />
              <StatCard
                label="Overdue"
                value={fmt(stats?.overdueAmount ?? 0)}
                icon={AlertCircle}
                color="bg-red-100 text-red-600"
              />
              <StatCard
                label="Paid Invoices"
                value={`${stats?.paid ?? 0} / ${stats?.total ?? 0}`}
                icon={Clock}
                color="bg-emerald-100 text-emerald-600"
              />
            </>
          )}
        </div>

        {/* Invoice table */}
        <div className="bg-card border border-border rounded-xl overflow-hidden">
          <div className="px-6 py-4 border-b border-border">
            <h2 className="font-semibold">All Invoices</h2>
          </div>

          {invLoading ? (
            <div className="divide-y divide-border">
              {Array.from({ length: 4 }).map((_, i) => (
                <div key={i} className="px-6 py-4 flex items-center gap-4">
                  <Skeleton className="h-4 w-32" />
                  <Skeleton className="h-4 w-24 ml-auto" />
                  <Skeleton className="h-6 w-16" />
                </div>
              ))}
            </div>
          ) : !invoices?.length ? (
            <div className="text-center py-16 px-6">
              <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mx-auto mb-4">
                <PlusCircle className="w-7 h-7 text-muted-foreground" />
              </div>
              <h3 className="font-semibold text-lg mb-2">No invoices yet</h3>
              <p className="text-muted-foreground text-sm mb-6">
                Create your first invoice and start getting paid.
              </p>
              <Button onClick={() => setLocation("/invoices/new")}>
                <PlusCircle className="w-4 h-4 mr-2" />
                Create Invoice
              </Button>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-muted/50 text-muted-foreground">
                  <tr>
                    <th className="text-left px-6 py-3 font-medium">Client</th>
                    <th className="text-left px-6 py-3 font-medium hidden md:table-cell">Email</th>
                    <th className="text-right px-6 py-3 font-medium">Amount</th>
                    <th className="text-left px-6 py-3 font-medium hidden sm:table-cell">Due Date</th>
                    <th className="text-left px-6 py-3 font-medium">Status</th>
                    <th className="text-right px-6 py-3 font-medium">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {invoices.map((inv, idx) => (
                    <motion.tr
                      key={inv.id}
                      initial={{ opacity: 0, x: -8 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: idx * 0.04 }}
                      className="hover:bg-muted/30 transition-colors"
                    >
                      <td className="px-6 py-4 font-medium">{inv.clientName}</td>
                      <td className="px-6 py-4 text-muted-foreground hidden md:table-cell">
                        {inv.clientEmail}
                      </td>
                      <td className="px-6 py-4 text-right font-mono font-semibold">
                        {fmt(inv.amount)}
                      </td>
                      <td className="px-6 py-4 text-muted-foreground hidden sm:table-cell">
                        {fmtDate(inv.dueDate)}
                      </td>
                      <td className="px-6 py-4">
                        <span
                          className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium capitalize ${
                            STATUS_COLORS[inv.status] ?? "bg-gray-100 text-gray-800"
                          }`}
                        >
                          {inv.status}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center justify-end gap-1">
                          {(inv.status === "overdue" || inv.status === "unpaid") && (
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-8 w-8"
                              title="Generate reminder email"
                              onClick={() => {
                                setReminderInvoice(inv);
                                setReminderResult(null);
                                setReminderTone(null);
                              }}
                            >
                              <Mail className="w-4 h-4" />
                            </Button>
                          )}
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8"
                            title="Edit invoice"
                            onClick={() => setLocation(`/invoices/${inv.id}/edit`)}
                          >
                            <Pencil className="w-4 h-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8 hover:text-destructive"
                            title="Delete invoice"
                            onClick={() => setDeleteId(inv.id)}
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </td>
                    </motion.tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      {/* Delete confirmation dialog */}
      <AlertDialog open={deleteId !== null} onOpenChange={(open) => { if (!open) setDeleteId(null); }}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete this invoice?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. The invoice will be permanently removed.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive hover:bg-destructive/90 text-destructive-foreground"
              onClick={handleDelete}
            >
              {deleteMutation.isPending ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                "Delete"
              )}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Reminder modal */}
      <Dialog open={!!reminderInvoice} onOpenChange={(open) => { if (!open) handleReminderClose(); }}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Generate Payment Reminder</DialogTitle>
          </DialogHeader>
          {reminderInvoice && (
            <div className="space-y-5">
              <p className="text-sm text-muted-foreground">
                Reminder for{" "}
                <strong>{reminderInvoice.clientName}</strong> —{" "}
                {fmt(reminderInvoice.amount)} due {fmtDate(reminderInvoice.dueDate)}. Choose a tone:
              </p>

              <div className="grid grid-cols-3 gap-3">
                {(["friendly", "firm", "final"] as const).map((tone) => (
                  <button
                    key={tone}
                    onClick={() => handleGenerateReminder(tone)}
                    disabled={reminderMutation.isPending}
                    className={`py-3 px-4 rounded-lg border text-sm font-medium transition-all
                      ${
                        reminderTone === tone
                          ? "border-primary bg-primary text-primary-foreground"
                          : "border-border hover:border-primary hover:bg-primary/5"
                      }
                      disabled:opacity-50 disabled:cursor-not-allowed`}
                  >
                    {reminderMutation.isPending && reminderTone === tone ? (
                      <span className="flex items-center justify-center gap-2">
                        <Loader2 className="w-3 h-3 animate-spin" />
                        {tone === "final" ? "Final Notice" : tone.charAt(0).toUpperCase() + tone.slice(1)}
                      </span>
                    ) : tone === "final" ? (
                      "Final Notice"
                    ) : (
                      tone.charAt(0).toUpperCase() + tone.slice(1)
                    )}
                  </button>
                ))}
              </div>

              {reminderResult && (
                <motion.div
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="space-y-3"
                >
                  <div className="bg-muted rounded-lg p-4">
                    <p className="text-xs text-muted-foreground uppercase tracking-wide mb-1">
                      Subject
                    </p>
                    <p className="text-sm font-medium">{reminderResult.subject}</p>
                  </div>
                  <div className="bg-muted rounded-lg p-4">
                    <p className="text-xs text-muted-foreground uppercase tracking-wide mb-2">
                      Email Body
                    </p>
                    <pre className="text-sm whitespace-pre-wrap font-sans leading-relaxed">
                      {reminderResult.body}
                    </pre>
                  </div>
                  <Button onClick={handleCopy} variant="outline" className="w-full">
                    {copied ? (
                      <>
                        <Check className="w-4 h-4 mr-2 text-emerald-600" /> Copied!
                      </>
                    ) : (
                      <>
                        <Copy className="w-4 h-4 mr-2" /> Copy to Clipboard
                      </>
                    )}
                  </Button>
                </motion.div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </DashboardLayout>
  );
}
