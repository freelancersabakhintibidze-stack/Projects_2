# InvoiceFlow AI

A full-stack invoicing SaaS for freelancers — create invoices in seconds, track payment status, and generate AI-toned payment reminder emails in one click.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 8080)
- `pnpm --filter @workspace/invoice-flow run dev` — run the frontend (Vite)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL`, `JWT_SECRET`, `SESSION_SECRET`

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- Frontend: React + Vite + Tailwind CSS + shadcn/ui + framer-motion + wouter + TanStack Query
- API: Express 5
- DB: PostgreSQL + Drizzle ORM (lib/db)
- Auth: JWT (jsonwebtoken) + bcryptjs — token stored in localStorage under key `invoice_flow_token`
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec in `lib/api-spec`)
- Build: esbuild (CJS bundle)

## Where things live

- `lib/db/src/schema/` — DB schema (users.ts, invoices.ts)
- `lib/api-spec/` — OpenAPI spec (source of truth for API contract)
- `lib/api-client-react/src/generated/` — generated React Query hooks + Zod schemas (do not edit)
- `artifacts/api-server/src/routes/` — Express route handlers (auth, invoices, users, health)
- `artifacts/api-server/src/middlewares/auth.ts` — JWT middleware (`requireAuth`, `signToken`)
- `artifacts/invoice-flow/src/pages/` — All frontend pages
- `artifacts/invoice-flow/src/contexts/AuthContext.tsx` — Auth state management

## Architecture decisions

- **Contract-first API**: OpenAPI spec in `lib/api-spec` drives all codegen. Never write hooks or Zod schemas by hand.
- **JWT in localStorage**: Token stored under key `invoice_flow_token`. `setAuthTokenGetter` from `@workspace/api-client-react` wires it into every API request automatically.
- **Template-based reminders**: No OpenAI API key required. Three tone templates (friendly / firm / final notice) are generated server-side from invoice + user data.
- **Amount as numeric string in DB**: Postgres `numeric` type returns strings; always `parseFloat()` before sending to client, `String()` before writing to DB.

## Product

- **Landing page** — cinematic hero with features, social proof, and signup CTA
- **Auth** — signup / login with JWT, bcrypt password hashing
- **Dashboard** — invoice table with status badges, 4 stat cards (revenue, outstanding, overdue, paid count)
- **Invoice CRUD** — create and edit invoices (client info, amount, due date, status, description)
- **AI Reminders** — one-click reminder generation in 3 tones: Friendly, Firm, Final Notice
- **Settings** — update name, email, business name

## Demo credentials

- Email: `demo@invoiceflow.ai`
- Password: `demo1234`

## User preferences

_Populate as you build — explicit user instructions worth remembering across sessions._

## Gotchas

- Run `pnpm --filter @workspace/api-spec run codegen` after any OpenAPI spec change before editing frontend or backend code.
- DB `amount` field is Postgres `numeric` — always comes back as string, convert with `parseFloat()`.
- Do NOT add leaf workspace packages to root `tsconfig.json` references.
- Use `pnpm run typecheck` (not `build`) to verify — `build` requires workflow-provided env vars.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
