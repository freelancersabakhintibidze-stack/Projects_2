export type BookingStatus = 'Pending' | 'Confirmed' | 'Cancelled';

export interface Booking {
  id: number;
  tourId: number;
  touristName: string;
  touristEmail: string;
  touristPhone: string;
  numberOfPeople: number;
  totalPrice: number; // ALWAYS computed as numberOfPeople * tour.pricePerPerson — never user-entered
  specialRequests?: string;
  status: BookingStatus;
  createdAt: Date;
}
