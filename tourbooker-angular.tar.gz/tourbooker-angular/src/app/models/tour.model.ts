export type TourCategory = 'Sea' | 'Mountain' | 'City Tour' | 'Active Leisure' | 'Cultural';

export interface Tour {
  id: number;
  title: string;
  destination: string;
  country: string;
  description: string;
  category: TourCategory;
  pricePerPerson: number;
  durationDays: number;
  startDate: Date;
  endDate: Date;
  totalSpots: number;
  availableSpots: number;
  imageUrl: string;
  rating: number; // 1–5
}
