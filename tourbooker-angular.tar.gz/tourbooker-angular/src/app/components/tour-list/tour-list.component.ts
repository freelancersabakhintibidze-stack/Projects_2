import { Component, OnInit, OnDestroy } from '@angular/core';
import { RouterLink } from '@angular/router';
import { AsyncPipe, CurrencyPipe, DatePipe, NgClass } from '@angular/common';
import { FormsModule } from '@angular/forms';
import {
  BehaviorSubject,
  Observable,
  combineLatest,
  debounceTime,
  distinctUntilChanged,
  map,
  Subject,
  takeUntil,
} from 'rxjs';
import { TourService } from '../../services/tour.service';
import { Tour, TourCategory } from '../../models/tour.model';

type SortOption = 'default' | 'price-asc' | 'price-desc';

const CATEGORIES: (TourCategory | 'All')[] = [
  'All', 'Mountain', 'Sea', 'Cultural', 'City Tour', 'Active Leisure',
];

@Component({
  selector: 'app-tour-list',
  standalone: true,
  imports: [RouterLink, AsyncPipe, CurrencyPipe, DatePipe, NgClass, FormsModule],
  templateUrl: './tour-list.component.html',
  styleUrls: ['./tour-list.component.scss'],
})
export class TourListComponent implements OnInit, OnDestroy {
  private destroy$ = new Subject<void>();

  readonly categories = CATEGORIES;

  private searchSubject = new BehaviorSubject<string>('');
  private categorySubject = new BehaviorSubject<TourCategory | 'All'>('All');
  private sortSubject = new BehaviorSubject<SortOption>('default');

  searchQuery = '';
  selectedCategory: TourCategory | 'All' = 'All';
  selectedSort: SortOption = 'default';

  filteredTours$!: Observable<Tour[]>;

  constructor(private tourService: TourService) {}

  ngOnInit(): void {
    const search$ = this.searchSubject.asObservable().pipe(
      debounceTime(300),
      distinctUntilChanged(),
    );

    this.filteredTours$ = combineLatest([
      this.tourService.tours$,
      search$,
      this.categorySubject.asObservable(),
      this.sortSubject.asObservable(),
    ]).pipe(
      map(([tours, query, category, sort]) => {
        let result = [...tours];

        if (category !== 'All') {
          result = result.filter(t => t.category === category);
        }

        if (query.trim()) {
          const q = query.toLowerCase();
          result = result.filter(
            t =>
              t.title.toLowerCase().includes(q) ||
              t.destination.toLowerCase().includes(q),
          );
        }

        if (sort === 'price-asc') result.sort((a, b) => a.pricePerPerson - b.pricePerPerson);
        else if (sort === 'price-desc') result.sort((a, b) => b.pricePerPerson - a.pricePerPerson);

        return result;
      }),
      takeUntil(this.destroy$),
    );
  }

  onSearchChange(value: string): void {
    this.searchQuery = value;
    this.searchSubject.next(value);
  }

  onCategoryChange(value: TourCategory | 'All'): void {
    this.selectedCategory = value;
    this.categorySubject.next(value);
  }

  onSortChange(value: SortOption): void {
    this.selectedSort = value;
    this.sortSubject.next(value);
  }

  clearFilters(): void {
    this.searchQuery = '';
    this.selectedCategory = 'All';
    this.selectedSort = 'default';
    this.searchSubject.next('');
    this.categorySubject.next('All');
    this.sortSubject.next('default');
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }
}
