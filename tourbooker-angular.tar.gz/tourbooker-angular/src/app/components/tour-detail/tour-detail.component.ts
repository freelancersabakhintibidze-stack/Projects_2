import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { DatePipe, NgClass } from '@angular/common';
import { TourService } from '../../services/tour.service';
import { BookingService } from '../../services/booking.service';
import { Tour } from '../../models/tour.model';
import { Booking } from '../../models/booking.model';

@Component({
  selector: 'app-tour-detail',
  standalone: true,
  imports: [RouterLink, DatePipe, NgClass],
  templateUrl: './tour-detail.component.html',
  styleUrls: ['./tour-detail.component.scss'],
})
export class TourDetailComponent implements OnInit {
  tour: Tour | undefined;
  recentBookings: Booking[] = [];

  constructor(
    private route: ActivatedRoute,
    private tourService: TourService,
    private bookingService: BookingService,
  ) {}

  ngOnInit(): void {
    const id = Number(this.route.snapshot.paramMap.get('id'));
    this.tour = this.tourService.getTourById(id);
    this.recentBookings = this.bookingService.getBookingsByTourId(id);
  }
}
