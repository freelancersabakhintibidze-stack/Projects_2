import { Component } from '@angular/core';
import { AsyncPipe, DecimalPipe, DatePipe, NgClass } from '@angular/common';
import { RouterLink } from '@angular/router';
import { Observable, map } from 'rxjs';
import { BookingService } from '../../services/booking.service';
import { TourService } from '../../services/tour.service';
import { Booking } from '../../models/booking.model';
import { Tour } from '../../models/tour.model';

export interface BookingWithTour extends Booking {
  tour?: Tour;
}

@Component({
  selector: 'app-my-bookings',
  standalone: true,
  imports: [AsyncPipe, DecimalPipe, DatePipe, NgClass, RouterLink],
  templateUrl: './my-bookings.component.html',
  styleUrls: ['./my-bookings.component.scss'],
})
export class MyBookingsComponent {
  bookings$: Observable<BookingWithTour[]>;
  confirmCancelId: number | null = null;

  constructor(
    private bookingService: BookingService,
    private tourService: TourService,
  ) {
    this.bookings$ = this.bookingService.getBookings().pipe(
      map(bookings =>
        bookings.map(b => ({
          ...b,
          tour: this.tourService.getTourById(b.tourId),
        })),
      ),
    );
  }

  requestCancel(id: number): void {
    this.confirmCancelId = id;
  }

  confirmCancel(): void {
    if (this.confirmCancelId !== null) {
      this.bookingService.cancelBooking(this.confirmCancelId);
      this.confirmCancelId = null;
    }
  }

  dismissCancel(): void {
    this.confirmCancelId = null;
  }
}
