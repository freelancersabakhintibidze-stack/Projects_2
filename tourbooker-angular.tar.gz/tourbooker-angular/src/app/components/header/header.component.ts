import { Component } from '@angular/core';
import { RouterLink, RouterLinkActive } from '@angular/router';
import { AsyncPipe } from '@angular/common';
import { Observable, map } from 'rxjs';
import { BookingService } from '../../services/booking.service';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [RouterLink, RouterLinkActive, AsyncPipe],
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss'],
})
export class HeaderComponent {
  activeBookingCount$: Observable<number>;

  constructor(private bookingService: BookingService) {
    this.activeBookingCount$ = this.bookingService.getBookings().pipe(
      map(bookings => bookings.filter(b => b.status === 'Confirmed' || b.status === 'Pending').length),
    );
  }
}
