import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators, AbstractControl, ValidationErrors, ValidatorFn } from '@angular/forms';
import { DecimalPipe, DatePipe, NgClass } from '@angular/common';
import { RouterLink } from '@angular/router';
import { Subject, takeUntil } from 'rxjs';
import { TourService } from '../../services/tour.service';
import { BookingService } from '../../services/booking.service';
import { Tour } from '../../models/tour.model';

function maxAvailableSpotsValidator(available: number): ValidatorFn {
  return (control: AbstractControl): ValidationErrors | null => {
    const value = Number(control.value);
    return value > available ? { exceedsAvailable: true } : null;
  };
}

@Component({
  selector: 'app-booking-form',
  standalone: true,
  imports: [ReactiveFormsModule, NgClass, DecimalPipe, DatePipe, RouterLink],
  templateUrl: './booking-form.component.html',
  styleUrls: ['./booking-form.component.scss'],
})
export class BookingFormComponent implements OnInit, OnDestroy {
  private destroy$ = new Subject<void>();

  tour: Tour | undefined;
  form!: FormGroup;
  totalPrice = 0;
  submitted = false;
  spotsError = false;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private fb: FormBuilder,
    private tourService: TourService,
    private bookingService: BookingService,
  ) {}

  ngOnInit(): void {
    const tourId = Number(this.route.snapshot.paramMap.get('tourId'));
    this.tour = this.tourService.getTourById(tourId);

    if (!this.tour) return;

    const available = this.tour.availableSpots;

    this.form = this.fb.group({
      firstName: ['', [Validators.required, Validators.minLength(3)]],
      lastName:  ['', [Validators.required, Validators.minLength(3)]],
      email:     ['', [Validators.required, Validators.email]],
      phone:     ['', [Validators.required, Validators.pattern(/^\+?[0-9]{9,15}$/)]],
      numberOfPeople: [
        1,
        [Validators.required, Validators.min(1), maxAvailableSpotsValidator(available)],
      ],
      specialRequests: [''],
    });

    // Spec requirement: subscribe to form.valueChanges to recompute totalPrice live
    this.form.valueChanges
      .pipe(takeUntil(this.destroy$))
      .subscribe(val => {
        const n = Number(val.numberOfPeople);
        this.totalPrice = isNaN(n) || n < 1 ? 0 : n * (this.tour?.pricePerPerson ?? 0);
      });

    this.totalPrice = this.tour.pricePerPerson;
  }

  get f() { return this.form.controls; }

  fieldInvalid(name: string): boolean {
    const ctrl = this.form.get(name);
    return !!ctrl && ctrl.invalid && (ctrl.touched || ctrl.dirty);
  }

  onSubmit(): void {
    this.submitted = true;
    this.spotsError = false;

    if (!this.form.valid || !this.tour) return;

    const { firstName, lastName, email, phone, numberOfPeople, specialRequests } = this.form.value;
    const people = Number(numberOfPeople);

    const reduced = this.tourService.reduceAvailableSpots(this.tour.id, people);
    if (!reduced) {
      this.spotsError = true;
      return;
    }

    this.bookingService.createBooking({
      tourId: this.tour.id,
      touristName: `${firstName.trim()} ${lastName.trim()}`,
      touristEmail: email.trim().toLowerCase(),
      touristPhone: phone.trim(),
      numberOfPeople: people,
      totalPrice: this.totalPrice,
      specialRequests: specialRequests?.trim() || undefined,
    });

    this.router.navigate(['/my-bookings']);
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }
}
