import { Routes } from '@angular/router';

export const routes: Routes = [
  { path: '', redirectTo: 'tours', pathMatch: 'full' },
  {
    path: 'tours',
    loadComponent: () =>
      import('./components/tour-list/tour-list.component').then(m => m.TourListComponent),
  },
  {
    path: 'tours/:id',
    loadComponent: () =>
      import('./components/tour-detail/tour-detail.component').then(m => m.TourDetailComponent),
  },
  {
    path: 'booking/:tourId',
    loadComponent: () =>
      import('./components/booking-form/booking-form.component').then(m => m.BookingFormComponent),
  },
  {
    path: 'my-bookings',
    loadComponent: () =>
      import('./components/my-bookings/my-bookings.component').then(m => m.MyBookingsComponent),
  },
  { path: '**', redirectTo: 'tours' },
];
