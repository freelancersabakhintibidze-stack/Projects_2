import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { Booking, BookingStatus } from '../models/booking.model';
import { TourService } from './tour.service';

export interface CreateBookingData {
  tourId: number;
  touristName: string;
  touristEmail: string;
  touristPhone: string;
  numberOfPeople: number;
  totalPrice: number;
  specialRequests?: string;
}

@Injectable({ providedIn: 'root' })
export class BookingService {
  private bookingsSubject = new BehaviorSubject<Booking[]>([]);

  constructor(private tourService: TourService) {}

  getBookings(): Observable<Booking[]> {
    return this.bookingsSubject.asObservable();
  }

  createBooking(data: CreateBookingData): Booking {
    const newBooking: Booking = {
      id: Date.now(),
      tourId: data.tourId,
      touristName: data.touristName,
      touristEmail: data.touristEmail,
      touristPhone: data.touristPhone,
      numberOfPeople: data.numberOfPeople,
      totalPrice: data.totalPrice,
      specialRequests: data.specialRequests,
      status: 'Confirmed' as BookingStatus,
      createdAt: new Date(),
    };

    this.bookingsSubject.next([newBooking, ...this.bookingsSubject.value]);
    return newBooking;
  }

  cancelBooking(id: number): void {
    const bookings = this.bookingsSubject.value;
    const booking = bookings.find(b => b.id === id);
    if (!booking || booking.status === 'Cancelled') return;

    this.tourService.increaseAvailableSpots(booking.tourId, booking.numberOfPeople);

    this.bookingsSubject.next(
      bookings.map(b => (b.id === id ? { ...b, status: 'Cancelled' as BookingStatus } : b)),
    );
  }

  getBookingsByTourId(tourId: number): Booking[] {
    return this.bookingsSubject.value.filter(b => b.tourId === tourId);
  }
}
