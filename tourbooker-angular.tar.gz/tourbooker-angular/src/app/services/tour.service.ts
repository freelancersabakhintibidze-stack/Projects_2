import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, map } from 'rxjs';
import { Tour, TourCategory } from '../models/tour.model';

const mockTours: Tour[] = [
  {
    id: 1,
    title: '3-Day Svaneti Adventure',
    destination: 'Mestia',
    country: 'Georgia',
    description:
      'Explore the wild heart of the Caucasus. See ancient defensive towers, glacier-covered peaks, and traditional Svan villages untouched by modern life.',
    category: 'Mountain',
    pricePerPerson: 350,
    durationDays: 3,
    startDate: new Date('2026-07-15'),
    endDate: new Date('2026-07-17'),
    totalSpots: 15,
    availableSpots: 15,
    imageUrl: 'https://images.unsplash.com/photo-1579705745114-1e03a985d8da?w=800&q=80',
    rating: 4.8,
  },
  {
    id: 2,
    title: 'Batumi Black Sea Escape',
    destination: 'Batumi',
    country: 'Georgia',
    description:
      'Relax on the pebble beaches of the Black Sea, stroll through the botanical garden, and marvel at striking modern architecture in this subtropical coastal city.',
    category: 'Sea',
    pricePerPerson: 280,
    durationDays: 4,
    startDate: new Date('2026-08-01'),
    endDate: new Date('2026-08-04'),
    totalSpots: 20,
    availableSpots: 20,
    imageUrl: 'https://images.unsplash.com/photo-1599321489679-b8830172e2dc?w=800&q=80',
    rating: 4.2,
  },
  {
    id: 3,
    title: 'Kakheti Wine & Culture Tour',
    destination: 'Telavi',
    country: 'Georgia',
    description:
      'Taste world-class amber wines made in ancient clay qvevris, visit breathtaking monasteries, and savour legendary Georgian hospitality in the wine country.',
    category: 'Cultural',
    pricePerPerson: 320,
    durationDays: 3,
    startDate: new Date('2026-09-10'),
    endDate: new Date('2026-09-12'),
    totalSpots: 12,
    availableSpots: 12,
    imageUrl: 'https://images.unsplash.com/photo-1585501869372-9a74421b539e?w=800&q=80',
    rating: 4.6,
  },
  {
    id: 4,
    title: 'Tbilisi City Explorer',
    destination: 'Tbilisi',
    country: 'Georgia',
    description:
      'Discover the vibrant capital — wander the old town, soak in famous sulfur baths, explore eclectic architecture, and dive into the spectacular dining scene.',
    category: 'City Tour',
    pricePerPerson: 200,
    durationDays: 2,
    startDate: new Date('2026-07-20'),
    endDate: new Date('2026-07-21'),
    totalSpots: 20,
    availableSpots: 20,
    imageUrl: 'https://images.unsplash.com/photo-1559981881-80aa06263884?w=800&q=80',
    rating: 4.4,
  },
  {
    id: 5,
    title: 'Gudauri Mountain Tour',
    destination: 'Gudauri',
    country: 'Georgia',
    description:
      'Experience incredible altitude, crisp mountain air, and panoramic Caucasus views. Perfect for adventure seekers who love wide open mountain landscapes.',
    category: 'Mountain',
    pricePerPerson: 420,
    durationDays: 5,
    startDate: new Date('2026-08-10'),
    endDate: new Date('2026-08-14'),
    totalSpots: 10,
    availableSpots: 10,
    imageUrl: 'https://images.unsplash.com/photo-1502422071720-33b669e46a78?w=800&q=80',
    rating: 4.7,
  },
  {
    id: 6,
    title: 'Kazbegi Epic Trek',
    destination: 'Stepantsminda',
    country: 'Georgia',
    description:
      "Hike to the iconic Gergeti Trinity Church perched above the clouds with the majestic 5,047m Mount Kazbek as your dramatic backdrop. Unforgettable.",
    category: 'Mountain',
    pricePerPerson: 380,
    durationDays: 4,
    startDate: new Date('2026-07-25'),
    endDate: new Date('2026-07-28'),
    totalSpots: 8,
    availableSpots: 8,
    imageUrl: 'https://images.unsplash.com/photo-1627993427958-30691e84df24?w=800&q=80',
    rating: 4.9,
  },
  {
    id: 7,
    title: 'Signagi Romantic Getaway',
    destination: 'Signagi',
    country: 'Georgia',
    description:
      "Stroll cobblestone streets of the 'City of Love', sip wine overlooking the lush Alazani valley, and explore hidden cave cellars tucked into hillsides.",
    category: 'Cultural',
    pricePerPerson: 260,
    durationDays: 2,
    startDate: new Date('2026-09-05'),
    endDate: new Date('2026-09-06'),
    totalSpots: 15,
    availableSpots: 15,
    imageUrl: 'https://images.unsplash.com/photo-1647413813953-f72be56a91d1?w=800&q=80',
    rating: 4.3,
  },
  {
    id: 8,
    title: 'Batumi Water Sports Adventure',
    destination: 'Batumi',
    country: 'Georgia',
    description:
      'Jet skiing, parasailing, banana boat rides, and diving in the warm Black Sea — the ultimate adrenaline-packed beach holiday.',
    category: 'Active Leisure',
    pricePerPerson: 300,
    durationDays: 3,
    startDate: new Date('2026-08-15'),
    endDate: new Date('2026-08-17'),
    totalSpots: 18,
    availableSpots: 18,
    imageUrl: 'https://images.unsplash.com/photo-1544551763-46a013bb70d5?w=800&q=80',
    rating: 4.1,
  },
  {
    id: 9,
    title: 'Mtskheta Ancient Trails',
    destination: 'Mtskheta',
    country: 'Georgia',
    description:
      "Walk through millennia of history in Georgia's ancient spiritual capital — visit the UNESCO-listed Svetitskhoveli Cathedral and clifftop Jvari Monastery.",
    category: 'Cultural',
    pricePerPerson: 230,
    durationDays: 2,
    startDate: new Date('2026-09-20'),
    endDate: new Date('2026-09-21'),
    totalSpots: 12,
    availableSpots: 12,
    imageUrl: 'https://images.unsplash.com/photo-1601662528567-526cd06f6582?w=800&q=80',
    rating: 4.5,
  },
  {
    id: 10,
    title: 'Borjomi Spa & Nature Retreat',
    destination: 'Borjomi',
    country: 'Georgia',
    description:
      'Soak in world-famous mineral springs, hike through lush national park forests, and rejuvenate body and mind in this tranquil highland resort town.',
    category: 'Active Leisure',
    pricePerPerson: 450,
    durationDays: 6,
    startDate: new Date('2026-07-05'),
    endDate: new Date('2026-07-10'),
    totalSpots: 8,
    availableSpots: 8,
    imageUrl: 'https://images.unsplash.com/photo-1563229615-181156ea36cc?w=800&q=80',
    rating: 4.8,
  },
];

@Injectable({ providedIn: 'root' })
export class TourService {
  private toursSubject = new BehaviorSubject<Tour[]>(mockTours);
  tours$ = this.toursSubject.asObservable();

  getTours(): Observable<Tour[]> {
    return this.tours$;
  }

  getTourById(id: number): Tour | undefined {
    return this.toursSubject.value.find(t => t.id === id);
  }

  getToursByCategory(category: TourCategory): Observable<Tour[]> {
    return this.tours$.pipe(map(tours => tours.filter(t => t.category === category)));
  }

  searchTours(query: string): Observable<Tour[]> {
    const q = query.toLowerCase();
    return this.tours$.pipe(
      map(tours =>
        tours.filter(
          t =>
            t.title.toLowerCase().includes(q) ||
            t.destination.toLowerCase().includes(q),
        ),
      ),
    );
  }

  reduceAvailableSpots(tourId: number, count: number): boolean {
    const tours = this.toursSubject.value;
    const tour = tours.find(t => t.id === tourId);
    if (!tour || tour.availableSpots < count) return false;

    tour.availableSpots -= count;
    this.toursSubject.next([...tours]);
    return true;
  }

  increaseAvailableSpots(tourId: number, count: number): void {
    const tours = this.toursSubject.value;
    const tour = tours.find(t => t.id === tourId);
    if (!tour) return;

    tour.availableSpots = Math.min(tour.totalSpots, tour.availableSpots + count);
    this.toursSubject.next([...tours]);
  }
}
