# TourBooker (Angular + RxJS)

A complete Georgian tour booking management app built with **Angular 17**, **RxJS BehaviorSubject** state, and **Angular Reactive Forms**. No backend — all state lives in-memory.

## Quick Start

```bash
npm install
npm start          # → http://localhost:4200
```

> Requires **Node 18+** and **Angular CLI 17+**.
> Install the CLI globally if you don't have it: `npm install -g @angular/cli`

## Stack

| Concern        | Technology                         |
|----------------|------------------------------------|
| Framework      | Angular 17 (standalone components) |
| Language       | TypeScript 5 (strict mode)         |
| State          | RxJS `BehaviorSubject`             |
| Forms          | Angular Reactive Forms             |
| Routing        | Angular Router (hash strategy)     |
| Styling        | SCSS (custom, no UI library)       |

## Project Structure

```
src/app/
  models/
    tour.model.ts          ← Tour interface + TourCategory union type
    booking.model.ts       ← Booking interface + BookingStatus union type
  services/
    tour.service.ts        ← BehaviorSubject<Tour[]>, reduceAvailableSpots, etc.
    booking.service.ts     ← BehaviorSubject<Booking[]>, create/cancel
  components/
    header/                ← Sticky nav, active booking count badge
    tour-list/             ← Grid, search (debounced), category filter, price sort
    tour-detail/           ← Full tour info, recent bookings, "Book Now" CTA
    booking-form/          ← Reactive form, live total price, custom validator
    my-bookings/           ← Table + mobile cards, status badges, cancel modal
  app.routes.ts            ← Lazy-loaded route definitions
  app.config.ts            ← bootstrapApplication providers
  app.component.ts         ← Root component (header + router-outlet)
```

## Features

- **Tour list** — grid of 10 Georgian tours, real-time search (300 ms debounce via `debounceTime`), category filter, price sorting; filters combined with `combineLatest`
- **Tour detail** — full info, stats, recent bookings for that tour
- **Booking form** — reactive form with live total-price, custom `maxAvailableSpotsValidator`, error messages only on touched/dirty fields
- **My Bookings** — responsive table/cards, color-coded status badges, cancellation with confirmation modal
- Booking decrements `availableSpots`; cancellation restores them via `TourService.increaseAvailableSpots`
- "Fully Booked" badge + disabled booking when `availableSpots === 0`

## Key RxJS Patterns

```typescript
// Combined filtering (tour-list.component.ts)
this.filteredTours$ = combineLatest([
  this.tourService.tours$,
  search$.pipe(debounceTime(300), distinctUntilChanged()),
  this.categorySubject.asObservable(),
  this.sortSubject.asObservable(),
]).pipe(map(([tours, query, category, sort]) => { /* filter + sort */ }));

// Atomic spot mutation (tour.service.ts)
reduceAvailableSpots(tourId: number, count: number): boolean {
  const tours = this.toursSubject.value;
  const tour = tours.find(t => t.id === tourId);
  if (!tour || tour.availableSpots < count) return false;
  tour.availableSpots -= count;
  this.toursSubject.next([...tours]);
  return true;
}
```

## Routes

| Path               | Component          |
|--------------------|--------------------|
| `/`                | → redirect `/tours`|
| `/tours`           | TourListComponent  |
| `/tours/:id`       | TourDetailComponent|
| `/booking/:tourId` | BookingFormComponent|
| `/my-bookings`     | MyBookingsComponent|
