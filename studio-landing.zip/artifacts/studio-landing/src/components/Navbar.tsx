import { useEffect, useState } from 'react';

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 80);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header className="fixed top-0 left-0 right-0 z-50 flex justify-center pt-5 px-4 pointer-events-none">
      <div 
        className={`pointer-events-auto inline-flex items-center rounded-full backdrop-blur-md border border-white/10 bg-surface/80 px-2 py-2 transition-shadow duration-300 ${
          scrolled ? 'shadow-[0_4px_24px_-8px_rgba(0,0,0,0.5)]' : ''
        }`}
      >
        <div className="group w-9 h-9 rounded-full accent-gradient p-[1px] cursor-pointer hover:scale-110 transition-transform flex-shrink-0">
          <div className="w-full h-full bg-bg rounded-full flex items-center justify-center">
            <span className="font-display italic text-[13px] text-text-primary">SN</span>
          </div>
        </div>

        <div className="w-px h-5 bg-stroke mx-1 sm:mx-2" />

        <nav className="flex items-center">
          {["Work", "About", "Services", "Contact"].map((item) => (
            <a
              key={item}
              href={`#${item.toLowerCase()}`}
              className="text-xs sm:text-sm rounded-full px-3 sm:px-4 py-1.5 sm:py-2 text-muted hover:text-text-primary transition-colors"
            >
              {item}
            </a>
          ))}
        </nav>

        <div className="w-px h-5 bg-stroke mx-1 sm:mx-2" />

        <a 
          href="#contact" 
          className="group relative inline-flex items-center gap-1.5 rounded-full px-4 sm:px-5 py-1.5 sm:py-2 text-xs sm:text-sm bg-bg text-text-primary border border-transparent hover:border-transparent transition-all overflow-hidden"
        >
          <div className="absolute inset-0 accent-gradient opacity-0 group-hover:opacity-100 transition-opacity p-[1px] rounded-full">
            <div className="w-full h-full bg-bg rounded-full" />
          </div>
          <span className="relative z-10">Let's talk</span>
          <span className="relative z-10 text-[10px]">↗</span>
        </a>
      </div>
    </header>
  );
}
