import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const testimonials = [
  {
    quote: "They understood our vision immediately. The final site feels significantly more premium than what we had before.",
    name: "Sarah Jenkins",
    role: "Founder, Architecture Studio"
  },
  {
    quote: "The attention to detail in the animations and layout is incredible. It's exactly the vibe we wanted.",
    name: "Marcus Thorne",
    role: "Creative Director"
  },
  {
    quote: "Fast, clear communication, and a stunning final product. We've seen a noticeable increase in premium inquiries.",
    name: "Elena Rostova",
    role: "Luxury Real Estate Agent"
  }
];

export default function SocialProof() {
  const statsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!statsRef.current) return;
    
    const numbers = statsRef.current.querySelectorAll('.stat-number');
    
    const ctx = gsap.context(() => {
      numbers.forEach((num) => {
        const targetValue = parseInt(num.getAttribute('data-target') || '0', 10);
        const suffix = num.getAttribute('data-suffix') || '';
        
        gsap.to(num, {
          scrollTrigger: {
            trigger: statsRef.current,
            start: "top 80%",
            once: true
          },
          innerHTML: targetValue,
          duration: 2,
          ease: "power2.out",
          snap: { innerHTML: 1 },
          onUpdate: function() {
            num.innerHTML = Math.round(Number(this.targets()[0].innerHTML)) + suffix;
          }
        });
      });
    }, statsRef);
    
    return () => ctx.revert();
  }, []);

  return (
    <section id="about" className="bg-bg py-16 md:py-24 relative z-20">
      <div className="max-w-[1200px] mx-auto px-6 md:px-10 lg:px-16">
        
        {/* Stats */}
        <div 
          ref={statsRef}
          className="flex flex-col md:flex-row justify-center items-center gap-12 md:gap-0 divide-y md:divide-y-0 md:divide-x divide-stroke mb-20 md:mb-32"
        >
          <div className="flex flex-col items-center w-full md:w-1/3 py-6 md:py-0">
            <div className="text-5xl md:text-7xl font-display italic text-text-primary mb-2 stat-number" data-target="40" data-suffix="+">0+</div>
            <div className="text-xs text-muted uppercase tracking-widest">Projects Delivered</div>
          </div>
          <div className="flex flex-col items-center w-full md:w-1/3 py-6 md:py-0">
            <div className="text-5xl md:text-7xl font-display italic text-text-primary mb-2 stat-number" data-target="7" data-suffix="+">0+</div>
            <div className="text-xs text-muted uppercase tracking-widest">Years Building</div>
          </div>
          <div className="flex flex-col items-center w-full md:w-1/3 py-6 md:py-0">
            <div className="text-5xl md:text-7xl font-display italic text-text-primary mb-2 stat-number" data-target="92" data-suffix="%">0%</div>
            <div className="text-xs text-muted uppercase tracking-widest">Client Retention</div>
          </div>
        </div>

        {/* Testimonials */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {testimonials.map((t, idx) => (
            <div key={idx} className="bg-surface border border-stroke rounded-2xl p-6 md:p-8 flex flex-col justify-between">
              <p className="text-sm text-muted italic leading-relaxed mb-8">"{t.quote}"</p>
              <div>
                <div className="text-sm text-text-primary font-medium">{t.name}</div>
                <div className="text-xs text-muted mt-1">{t.role}</div>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
}
