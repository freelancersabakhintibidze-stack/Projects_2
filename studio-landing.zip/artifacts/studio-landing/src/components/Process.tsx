import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const steps = [
  {
    num: "/01",
    title: "Discovery",
    desc: "We learn your brand, your clients, and what you need the site to do. 30 minutes and we know where to go."
  },
  {
    num: "/02",
    title: "Design & Build",
    desc: "We build your site with custom animations, mobile-perfect layout, and all content in place."
  },
  {
    num: "/03",
    title: "Review & Refine",
    desc: "Two rounds of revisions. You give feedback, we refine until it's exactly right."
  },
  {
    num: "/04",
    title: "Launch",
    desc: "Domain connected. Site live. You walk away with something you're genuinely excited to send people to."
  }
];

export default function Process() {
  const containerRef = useRef<HTMLDivElement>(null);
  const rightColRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!rightColRef.current) return;
    
    const cards = rightColRef.current.querySelectorAll('.process-card');
    
    const ctx = gsap.context(() => {
      cards.forEach((card) => {
        gsap.fromTo(card, 
          { opacity: 0, x: 50 },
          {
            opacity: 1, 
            x: 0,
            duration: 0.8,
            ease: "power3.out",
            scrollTrigger: {
              trigger: card,
              start: "top 80%",
              toggleActions: "play none none reverse"
            }
          }
        );
      });
    }, rightColRef);
    
    return () => ctx.revert();
  }, []);

  return (
    <section id="process" className="bg-bg py-20 md:py-32 relative z-20 min-h-[150vh]" ref={containerRef}>
      <div className="max-w-[1200px] mx-auto px-6 md:px-10 lg:px-16 flex flex-col lg:flex-row gap-16 lg:gap-24 relative">
        
        {/* Left Column (Sticky) */}
        <div className="lg:w-1/3 lg:sticky lg:top-32 lg:h-fit relative z-10 self-start">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-8 h-px bg-stroke" />
            <span className="text-xs text-muted uppercase tracking-[0.3em]">How we work</span>
          </div>
          <h2 className="text-4xl md:text-5xl lg:text-6xl text-text-primary tracking-tight mb-6">
            Simple process,<br/>
            <span className="font-display italic">premium result.</span>
          </h2>
          <p className="text-sm md:text-base text-muted max-w-sm">
            No endless revisions. No confusion. Just a clear path from brief to live.
          </p>
        </div>

        {/* Right Column (Scrolling) */}
        <div className="lg:w-2/3 flex flex-col gap-8 md:gap-12 pb-32" ref={rightColRef}>
          {steps.map((step, idx) => (
            <div 
              key={idx}
              className="process-card bg-surface border border-stroke rounded-2xl p-8 md:p-10 shadow-lg"
            >
              <div className="text-xl font-display text-text-primary/50 mb-4">{step.num}</div>
              <h3 className="text-2xl md:text-3xl font-display italic text-text-primary mb-4">{step.title}</h3>
              <p className="text-base text-muted leading-relaxed">{step.desc}</p>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
}
