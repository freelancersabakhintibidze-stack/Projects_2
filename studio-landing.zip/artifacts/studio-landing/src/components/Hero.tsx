import { useEffect, useState, useRef } from 'react';
import gsap from 'gsap';

const roles = ["luxury", "ambitious", "visual", "premium"];

export default function Hero() {
  const [roleIndex, setRoleIndex] = useState(0);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const interval = setInterval(() => {
      setRoleIndex(prev => (prev + 1) % roles.length);
    }, 2000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    if (!containerRef.current) return;
    
    const ctx = gsap.context(() => {
      const tl = gsap.timeline({ defaults: { ease: "power3.out" } });
      
      tl.fromTo(".name-reveal", 
        { opacity: 0, y: 60 },
        { opacity: 1, y: 0, duration: 1.2, delay: 0.1 }
      )
      .fromTo(".blur-in",
        { opacity: 0, filter: "blur(12px)", y: 20 },
        { opacity: 1, filter: "blur(0px)", y: 0, duration: 1, stagger: 0.12 },
        "-=0.9"
      );
    }, containerRef);
    
    return () => ctx.revert();
  }, []);

  return (
    <section className="relative min-h-screen w-full flex flex-col items-center justify-center overflow-hidden" ref={containerRef}>
      {/* Background */}
      <div className="absolute inset-0 z-0">
        <img 
          src="/images/hero-bg.jpg" 
          alt="Studio ambient"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-black/40" />
        <div className="absolute bottom-0 left-0 right-0 h-64 bg-gradient-to-t from-bg to-transparent" />
      </div>

      {/* Content */}
      <div className="relative z-10 flex flex-col items-center text-center px-6 mt-16">
        <div className="blur-in text-xs text-muted uppercase tracking-[0.3em] mb-8">
          PREMIUM WEB DESIGN
        </div>
        
        <h1 className="name-reveal text-6xl md:text-8xl lg:text-9xl font-display italic leading-[0.9] tracking-tight text-text-primary mb-6">
          We build websites<br />
          that close deals.
        </h1>
        
        <div className="blur-in text-xl md:text-3xl mb-8 text-text-primary/90">
          A studio built for{" "}
          <span 
            key={roleIndex} 
            className="inline-block font-display italic animate-word-fade-in text-accent"
          >
            {roles[roleIndex]}
          </span>
          {" "}brands.
        </div>
        
        <p className="blur-in text-sm md:text-base text-muted max-w-md mb-12">
          Premium websites built with AI and obsessive attention to detail. 
          For brands that take their image seriously.
        </p>
        
        <div className="blur-in flex flex-wrap justify-center gap-4">
          <a href="#work" className="group relative rounded-full text-sm px-7 py-3.5 bg-text-primary text-bg hover:bg-bg hover:text-text-primary transition-all hover:scale-105 overflow-hidden">
            <div className="absolute inset-0 accent-gradient opacity-0 group-hover:opacity-100 transition-opacity p-[1px] rounded-full">
              <div className="w-full h-full bg-bg rounded-full" />
            </div>
            <span className="relative z-10 group-hover:text-text-primary transition-colors">View Our Work</span>
          </a>
          
          <a href="#contact" className="group relative rounded-full text-sm px-7 py-3.5 border-2 border-stroke bg-bg hover:border-transparent transition-all hover:scale-105 overflow-hidden">
             <div className="absolute inset-0 accent-gradient opacity-0 group-hover:opacity-100 transition-opacity p-[2px] rounded-full">
              <div className="w-full h-full bg-bg rounded-full" />
            </div>
            <span className="relative z-10">Start a Project</span>
          </a>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-3 z-10">
        <span className="text-[10px] text-muted uppercase tracking-[0.2em]">SCROLL</span>
        <div className="w-px h-10 bg-stroke relative overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-1/2 bg-text-primary animate-scroll-down" />
        </div>
      </div>
    </section>
  );
}
