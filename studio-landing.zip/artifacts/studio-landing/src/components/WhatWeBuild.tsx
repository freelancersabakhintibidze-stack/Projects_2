import { motion } from 'framer-motion';

const services = [
  {
    num: "01",
    title: "Web Design",
    desc: "Premium websites built with obsessive attention to detail. Fast, responsive, and built to convert."
  },
  {
    num: "02",
    title: "Motion & Animation",
    desc: "Scroll animations, page transitions, and micro-interactions that make your site feel alive."
  },
  {
    num: "03",
    title: "Brand Identity",
    desc: "Logo, color system, and typography that makes you look like the obvious premium choice."
  },
  {
    num: "04",
    title: "Monthly Retainer",
    desc: "Ongoing updates, new pages, and priority support. Your site stays fresh without lifting a finger."
  }
];

export default function WhatWeBuild() {
  return (
    <section id="services" className="bg-bg py-16 md:py-24 relative z-20">
      <div className="max-w-[1200px] mx-auto px-6 md:px-10 lg:px-16">
        
        {/* Header */}
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 1 }}
          viewport={{ once: true, margin: "-100px" }}
          className="mb-12 md:mb-16"
        >
          <div className="flex items-center gap-3 mb-6">
            <div className="w-8 h-px bg-stroke" />
            <span className="text-xs text-muted uppercase tracking-[0.3em]">Services</span>
          </div>
          <h2 className="text-4xl md:text-5xl lg:text-6xl text-text-primary tracking-tight">
            What we <span className="font-display italic">build</span>
          </h2>
        </motion.div>

        {/* Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5 md:gap-6">
          {services.map((svc, idx) => (
            <div 
              key={idx}
              className="group relative bg-surface border border-stroke rounded-2xl p-8 transition-all duration-300 hover:-translate-y-1 overflow-hidden"
            >
              {/* Left animated border highlight */}
              <div className="absolute left-0 top-0 bottom-0 w-[2px] accent-gradient opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              
              <div className="text-xs text-muted tracking-widest mb-8">{svc.num}</div>
              <h3 className="text-xl font-display italic text-text-primary mb-3">{svc.title}</h3>
              <p className="text-sm text-muted leading-relaxed max-w-sm">{svc.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
