import { useEffect, useRef } from 'react';
import gsap from 'gsap';

export default function Footer() {
  const marqueeRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!marqueeRef.current) return;
    
    const ctx = gsap.context(() => {
      gsap.to(marqueeRef.current, {
        xPercent: -50,
        ease: "none",
        duration: 35,
        repeat: -1
      });
    });
    
    return () => ctx.revert();
  }, []);

  const marqueeText = "PREMIUM WEBSITES • BUILT WITH AI • ";
  const repeatedText = Array(16).fill(marqueeText).join("");

  return (
    <footer id="contact" className="bg-bg pt-20 pb-10 overflow-hidden relative z-20 border-t border-stroke">
      
      {/* Marquee */}
      <div className="w-full overflow-hidden flex whitespace-nowrap mb-24 md:mb-32">
        <div ref={marqueeRef} className="flex">
          <span className="text-7xl md:text-9xl font-display font-bold uppercase tracking-tight text-stroke whitespace-nowrap">
            {repeatedText}
          </span>
        </div>
      </div>

      <div className="max-w-[1200px] mx-auto px-6 md:px-10 lg:px-16 flex flex-col items-center text-center">
        {/* CTA Block */}
        <div className="flex items-center gap-3 mb-6">
          <div className="w-8 h-px bg-stroke" />
          <span className="text-xs text-muted uppercase tracking-[0.3em]">Ready to start?</span>
          <div className="w-8 h-px bg-stroke" />
        </div>
        
        <h2 className="text-5xl md:text-7xl font-display italic text-text-primary mb-12">
          Let's build something<br/>
          <span className="text-accent">worth showing.</span>
        </h2>
        
        <a 
          href="mailto:hello@studio.com" 
          className="group relative inline-flex items-center gap-3 rounded-full px-8 py-4 bg-surface border border-stroke hover:border-transparent transition-all overflow-hidden"
        >
          <div className="absolute inset-0 accent-gradient opacity-0 group-hover:opacity-100 transition-opacity p-[1px] rounded-full">
            <div className="w-full h-full bg-surface rounded-full" />
          </div>
          <span className="relative z-10 text-text-primary">hello@studio.com</span>
          <span className="relative z-10 text-muted group-hover:text-text-primary transition-colors">↗</span>
        </a>

        {/* Footer Bar */}
        <div className="w-full flex flex-col md:flex-row justify-between items-center gap-6 border-t border-stroke pt-8 mt-24 md:mt-32">
          <div className="text-xs text-muted">
            STUDIO NAME © {new Date().getFullYear()}
          </div>
          
          <div className="flex items-center gap-6">
            <a href="#" className="text-xs text-muted hover:text-text-primary transition-colors">Instagram</a>
            <a href="#" className="text-xs text-muted hover:text-text-primary transition-colors">LinkedIn</a>
          </div>
          
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
            <span className="text-xs text-muted">Available for projects</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
