import { motion } from 'framer-motion';

const projects = [
  {
    title: "Architecture Firm",
    image: "/images/project-architecture.jpg"
  },
  {
    title: "Interior Designer",
    image: "/images/project-interior.jpg"
  },
  {
    title: "Luxury Real Estate",
    image: "/images/project-realestate.jpg"
  },
  {
    title: "Creative Studio",
    image: "/images/project-studio.jpg"
  }
];

export default function SelectedWork() {
  return (
    <section id="work" className="bg-bg py-12 md:py-20 relative z-20">
      <div className="max-w-[1200px] mx-auto px-6 md:px-10 lg:px-16">
        
        {/* Header */}
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 1 }}
          viewport={{ once: true, margin: "-100px" }}
          className="mb-12 md:mb-16 flex flex-col md:flex-row md:items-end justify-between gap-6"
        >
          <div className="max-w-xl">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-8 h-px bg-stroke" />
              <span className="text-xs text-muted uppercase tracking-[0.3em]">Selected Work</span>
            </div>
            <h2 className="text-4xl md:text-5xl lg:text-6xl text-text-primary tracking-tight mb-4">
              Featured <span className="font-display italic">projects</span>
            </h2>
            <p className="text-sm md:text-base text-muted">
              A selection of premium websites built for visual creatives and ambitious brands.
            </p>
          </div>
          
          <a href="#work" className="hidden md:inline-flex group relative rounded-full items-center gap-2 px-6 py-3 border border-stroke bg-bg hover:border-transparent transition-all overflow-hidden shrink-0">
            <div className="absolute inset-0 accent-gradient opacity-0 group-hover:opacity-100 transition-opacity p-[1px] rounded-full">
              <div className="w-full h-full bg-bg rounded-full" />
            </div>
            <span className="relative z-10 text-sm">View all work</span>
            <span className="relative z-10 text-xs">↗</span>
          </a>
        </motion.div>

        {/* Bento Grid */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-5 md:gap-6">
          {projects.map((project, idx) => {
            const spans = [
              "md:col-span-7", 
              "md:col-span-5", 
              "md:col-span-5", 
              "md:col-span-7"
            ];
            
            return (
              <div 
                key={idx} 
                className={`group relative h-[400px] md:h-[500px] bg-surface border border-stroke rounded-3xl overflow-hidden ${spans[idx]}`}
              >
                <img 
                  src={project.image} 
                  alt={project.title}
                  className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                />
                
                {/* Halftone Overlay */}
                <div 
                  className="absolute inset-0 opacity-20 mix-blend-multiply pointer-events-none"
                  style={{
                    backgroundImage: 'radial-gradient(circle, #000 1px, transparent 1px)',
                    backgroundSize: '4px 4px'
                  }}
                />

                {/* Hover Overlay */}
                <div className="absolute inset-0 bg-bg/70 opacity-0 group-hover:opacity-100 backdrop-blur-lg transition-all duration-500 flex items-center justify-center">
                  <div className="relative rounded-full px-6 py-3 border border-transparent overflow-hidden translate-y-4 group-hover:translate-y-0 transition-transform duration-500 delay-100">
                    <div className="absolute inset-0 accent-gradient p-[1px] rounded-full">
                      <div className="w-full h-full bg-bg rounded-full" />
                    </div>
                    <span className="relative z-10 text-sm text-text-primary">
                      View — <span className="font-display italic">{project.title}</span>
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
}
