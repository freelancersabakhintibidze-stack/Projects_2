import { useState } from 'react';
import LoadingScreen from '@/components/LoadingScreen';
import Navbar from '@/components/Navbar';
import Hero from '@/components/Hero';
import SelectedWork from '@/components/SelectedWork';
import WhatWeBuild from '@/components/WhatWeBuild';
import Process from '@/components/Process';
import SocialProof from '@/components/SocialProof';
import Footer from '@/components/Footer';

export default function Home() {
  const [isLoading, setIsLoading] = useState(true);

  return (
    <main className="relative bg-bg min-h-screen text-text-primary overflow-x-hidden selection:bg-accent/20 selection:text-text-primary">
      {isLoading && <LoadingScreen onComplete={() => setIsLoading(false)} />}
      <Navbar />
      <Hero />
      <SelectedWork />
      <WhatWeBuild />
      <Process />
      <SocialProof />
      <Footer />
    </main>
  );
}
