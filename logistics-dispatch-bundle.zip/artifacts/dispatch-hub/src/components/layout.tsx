import React from "react";
import { Link, useLocation } from "wouter";
import { useStore } from "@/lib/store";
import { LayoutDashboard, Package, Users, Truck, FileText, Settings, Info } from "lucide-react";

export function AppLayout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const { role, companyName, setRole } = useStore();

  const navItems = [
    { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
    { href: "/orders", label: "Orders", icon: Package },
    { href: "/drivers", label: "Drivers", icon: Users },
    { href: "/vehicles", label: "Vehicles", icon: Truck },
    { href: "/reports", label: "Reports", icon: FileText },
  ];

  return (
    <div className="flex h-screen w-full bg-background overflow-hidden">
      {/* Sidebar */}
      <aside className="w-64 border-r border-border bg-card flex flex-col">
        <div className="p-4 border-b border-border">
          <h1 className="text-xl font-bold tracking-tight text-primary uppercase font-mono">{companyName}</h1>
          <p className="text-xs text-muted-foreground mt-1 uppercase">Dispatch Console</p>
        </div>
        
        <div className="p-4 border-b border-border">
          <div className="text-xs font-semibold text-muted-foreground mb-2 uppercase tracking-wider">Current Role</div>
          <select 
            className="w-full bg-background border border-border text-foreground text-sm rounded p-2 focus:ring-1 focus:ring-primary outline-none"
            value={role}
            onChange={(e) => setRole(e.target.value as any)}
          >
            <option value="Dispatcher">Dispatcher (Full Access)</option>
            <option value="Viewer">Viewer (Read-only)</option>
          </select>
        </div>

        <nav className="flex-1 overflow-y-auto py-4">
          <ul className="space-y-1 px-2">
            {navItems.map((item) => {
              const active = location.startsWith(item.href);
              return (
                <li key={item.href}>
                  <Link 
                    href={item.href}
                    className={`flex items-center gap-3 px-3 py-2 rounded-md text-sm transition-colors ${
                      active ? "bg-primary/10 text-primary font-medium" : "text-muted-foreground hover:text-foreground hover:bg-secondary"
                    }`}
                  >
                    <item.icon className="w-4 h-4" />
                    {item.label}
                  </Link>
                </li>
              );
            })}
          </ul>
        </nav>

        <div className="p-4 border-t border-border space-y-1">
          <Link href="/settings" className={`flex items-center gap-3 px-3 py-2 rounded-md text-sm transition-colors ${location === '/settings' ? 'text-primary' : 'text-muted-foreground hover:text-foreground'}`}>
            <Settings className="w-4 h-4" /> Settings
          </Link>
          <Link href="/about" className={`flex items-center gap-3 px-3 py-2 rounded-md text-sm transition-colors ${location === '/about' ? 'text-primary' : 'text-muted-foreground hover:text-foreground'}`}>
            <Info className="w-4 h-4" /> About
          </Link>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col overflow-hidden relative">
        <header className="h-14 border-b border-border flex items-center px-6 bg-card/50 backdrop-blur">
          <div className="flex-1">
            {/* Breadcrumbs or Context info could go here */}
          </div>
          <div className="flex items-center gap-4 text-sm font-mono text-muted-foreground">
            <span className="flex items-center gap-2">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-primary"></span>
              </span>
              SYSTEM ONLINE
            </span>
          </div>
        </header>
        <div className="flex-1 overflow-auto p-6">
          {children}
        </div>
      </main>
    </div>
  );
}
