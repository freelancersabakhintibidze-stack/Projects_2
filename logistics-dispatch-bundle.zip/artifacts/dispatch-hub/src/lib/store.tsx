import React, { createContext, useContext, useState, useEffect } from 'react';

export type Role = "Dispatcher" | "Viewer";
export type Priority = "Low" | "Medium" | "High" | "Urgent";
export type OrderStatus = "Pending" | "Assigned" | "In Transit" | "Completed" | "Cancelled";
export type DriverStatus = "Available" | "On Delivery" | "Off Duty";
export type VehicleStatus = "Available" | "In Use" | "Maintenance";

export interface Order {
  id: string;
  customerName: string;
  phone: string;
  pickupAddress: string;
  destinationAddress: string;
  cargoDescription: string;
  weight: number;
  vehicleId?: string;
  driverId?: string;
  plannedDate: string;
  plannedTime: string;
  priority: Priority;
  status: OrderStatus;
  notes: string;
  createdAt: string;
}

export interface Driver {
  id: string;
  name: string;
  phone: string;
  licenseNumber: string;
  status: DriverStatus;
}

export interface Vehicle {
  id: string;
  plateNumber: string;
  type: string;
  capacity: number;
  status: VehicleStatus;
}

export interface AppState {
  role: Role;
  companyName: string;
  orders: Order[];
  drivers: Driver[];
  vehicles: Vehicle[];
}

const SEED_DATA: AppState = {
  role: "Dispatcher",
  companyName: "Apex Logistics",
  orders: [
    {
      id: "ORD-1001",
      customerName: "Acme Corp",
      phone: "555-0100",
      pickupAddress: "100 Industry Way, Sector 4",
      destinationAddress: "Warehouse 12, Port City",
      cargoDescription: "Industrial Parts",
      weight: 1500,
      plannedDate: new Date().toISOString().split('T')[0],
      plannedTime: "08:00",
      priority: "High",
      status: "In Transit",
      notes: "Fragile items, handle with care.",
      createdAt: new Date().toISOString(),
      driverId: "DRV-1",
      vehicleId: "VEH-1",
    },
    {
      id: "ORD-1002",
      customerName: "Global Imports",
      phone: "555-0200",
      pickupAddress: "Dock 4, East Terminal",
      destinationAddress: "Distribution Center Alpha",
      cargoDescription: "Consumer Electronics",
      weight: 800,
      plannedDate: new Date().toISOString().split('T')[0],
      plannedTime: "14:00",
      priority: "Medium",
      status: "Pending",
      notes: "",
      createdAt: new Date().toISOString(),
    }
  ],
  drivers: [
    { id: "DRV-1", name: "John Smith", phone: "555-1001", licenseNumber: "CDL-998811", status: "On Delivery" },
    { id: "DRV-2", name: "Sarah Connor", phone: "555-1002", licenseNumber: "CDL-887722", status: "Available" },
  ],
  vehicles: [
    { id: "VEH-1", plateNumber: "XYZ-1234", type: "Heavy Truck", capacity: 5000, status: "In Use" },
    { id: "VEH-2", plateNumber: "ABC-9876", type: "Medium Van", capacity: 2000, status: "Available" },
  ]
};

function getInitialState(): AppState {
  const saved = localStorage.getItem("dispatch_hub_data");
  if (saved) {
    try {
      return JSON.parse(saved);
    } catch (e) {
      console.error("Failed to parse local storage data", e);
    }
  }
  return SEED_DATA;
}

interface StoreContextType extends AppState {
  setRole: (role: Role) => void;
  setCompanyName: (name: string) => void;
  addOrder: (order: Order) => void;
  updateOrder: (id: string, order: Partial<Order>) => void;
  deleteOrder: (id: string) => void;
  resetData: () => void;
}

const StoreContext = createContext<StoreContextType | null>(null);

export function StoreProvider({ children }: { children: React.ReactNode }) {
  const [state, setState] = useState<AppState>(getInitialState);

  useEffect(() => {
    localStorage.setItem("dispatch_hub_data", JSON.stringify(state));
  }, [state]);

  const updateState = (updates: Partial<AppState>) => {
    setState(prev => ({ ...prev, ...updates }));
  };

  const store: StoreContextType = {
    ...state,
    setRole: (role) => updateState({ role }),
    setCompanyName: (companyName) => updateState({ companyName }),
    addOrder: (order) => updateState({ orders: [...state.orders, order] }),
    updateOrder: (id, updates) => updateState({ 
      orders: state.orders.map(o => o.id === id ? { ...o, ...updates } : o) 
    }),
    deleteOrder: (id) => updateState({
      orders: state.orders.filter(o => o.id !== id)
    }),
    resetData: () => {
      setState(SEED_DATA);
      localStorage.setItem("dispatch_hub_data", JSON.stringify(SEED_DATA));
    }
  };

  return (
    <StoreContext.Provider value={store}>
      {children}
    </StoreContext.Provider>
  );
}

export function useStore() {
  const context = useContext(StoreContext);
  if (!context) throw new Error("useStore must be used within StoreProvider");
  return context;
}
