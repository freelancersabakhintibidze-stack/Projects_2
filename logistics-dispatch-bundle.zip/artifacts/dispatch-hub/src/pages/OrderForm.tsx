import React, { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useStore, Order, Priority, OrderStatus } from "@/lib/store";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";

export default function OrderForm() {
  const [, setLocation] = useLocation();
  const searchParams = new URLSearchParams(window.location.search);
  const editId = searchParams.get("edit");
  
  const { orders, drivers, vehicles, addOrder, updateOrder } = useStore();
  
  const [formData, setFormData] = useState<Partial<Order>>({
    customerName: "",
    phone: "",
    pickupAddress: "",
    destinationAddress: "",
    cargoDescription: "",
    weight: 0,
    plannedDate: new Date().toISOString().split('T')[0],
    plannedTime: "12:00",
    priority: "Medium" as Priority,
    status: "Pending" as OrderStatus,
    notes: "",
    driverId: "",
    vehicleId: "",
  });

  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    if (editId) {
      const order = orders.find(o => o.id === editId);
      if (order) {
        setFormData(order);
      }
    }
  }, [editId, orders]);

  const validate = () => {
    const newErrors: Record<string, string> = {};
    if (!formData.customerName?.trim()) newErrors.customerName = "Required";
    if (!formData.phone?.trim() || !/^[0-9+\-\s()]+$/.test(formData.phone)) newErrors.phone = "Valid phone required";
    if (!formData.pickupAddress?.trim()) newErrors.pickupAddress = "Required";
    if (!formData.destinationAddress?.trim()) newErrors.destinationAddress = "Required";
    if (!formData.cargoDescription?.trim()) newErrors.cargoDescription = "Required";
    if (!formData.weight || formData.weight <= 0) newErrors.weight = "Must be positive number";
    
    if (formData.plannedDate) {
      const today = new Date().toISOString().split('T')[0];
      if (formData.plannedDate < today) newErrors.plannedDate = "Cannot be in the past";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    const finalData = {
      ...formData,
      customerName: formData.customerName?.trim(),
      phone: formData.phone?.trim(),
      pickupAddress: formData.pickupAddress?.trim(),
      destinationAddress: formData.destinationAddress?.trim(),
      cargoDescription: formData.cargoDescription?.trim(),
      notes: formData.notes?.trim()
    };

    if (editId) {
      updateOrder(editId, finalData as Partial<Order>);
      setLocation(`/orders/${editId}`);
    } else {
      const newOrder: Order = {
        ...(finalData as Order),
        id: `ORD-${Math.floor(1000 + Math.random() * 9000)}`,
        createdAt: new Date().toISOString()
      };
      addOrder(newOrder);
      setLocation(`/orders/${newOrder.id}`);
    }
  };

  return (
    <div className="max-w-3xl mx-auto space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-300">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold tracking-tight">{editId ? "Edit Order" : "New Order"}</h2>
      </div>

      <Card className="border-border">
        <CardContent className="pt-6">
          <form onSubmit={handleSubmit} className="space-y-6">
            
            <div className="grid grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-sm font-medium text-muted-foreground">Customer Name</label>
                <input 
                  type="text" 
                  value={formData.customerName || ""}
                  onChange={e => setFormData({ ...formData, customerName: e.target.value })}
                  className={`w-full bg-background border ${errors.customerName ? 'border-destructive' : 'border-border'} rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-primary`}
                />
                {errors.customerName && <p className="text-xs text-destructive">{errors.customerName}</p>}
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium text-muted-foreground">Phone</label>
                <input 
                  type="text" 
                  value={formData.phone || ""}
                  onChange={e => setFormData({ ...formData, phone: e.target.value })}
                  className={`w-full bg-background border ${errors.phone ? 'border-destructive' : 'border-border'} rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-primary`}
                />
                {errors.phone && <p className="text-xs text-destructive">{errors.phone}</p>}
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-muted-foreground">Pickup Address</label>
              <input 
                type="text" 
                value={formData.pickupAddress || ""}
                onChange={e => setFormData({ ...formData, pickupAddress: e.target.value })}
                className={`w-full bg-background border ${errors.pickupAddress ? 'border-destructive' : 'border-border'} rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-primary`}
              />
              {errors.pickupAddress && <p className="text-xs text-destructive">{errors.pickupAddress}</p>}
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-muted-foreground">Destination Address</label>
              <input 
                type="text" 
                value={formData.destinationAddress || ""}
                onChange={e => setFormData({ ...formData, destinationAddress: e.target.value })}
                className={`w-full bg-background border ${errors.destinationAddress ? 'border-destructive' : 'border-border'} rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-primary`}
              />
              {errors.destinationAddress && <p className="text-xs text-destructive">{errors.destinationAddress}</p>}
            </div>

            <div className="grid grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-sm font-medium text-muted-foreground">Cargo Description</label>
                <input 
                  type="text" 
                  value={formData.cargoDescription || ""}
                  onChange={e => setFormData({ ...formData, cargoDescription: e.target.value })}
                  className={`w-full bg-background border ${errors.cargoDescription ? 'border-destructive' : 'border-border'} rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-primary`}
                />
                {errors.cargoDescription && <p className="text-xs text-destructive">{errors.cargoDescription}</p>}
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium text-muted-foreground">Weight (kg)</label>
                <input 
                  type="number" 
                  value={formData.weight || ""}
                  onChange={e => setFormData({ ...formData, weight: parseFloat(e.target.value) })}
                  className={`w-full bg-background border ${errors.weight ? 'border-destructive' : 'border-border'} rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-primary`}
                />
                {errors.weight && <p className="text-xs text-destructive">{errors.weight}</p>}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-sm font-medium text-muted-foreground">Planned Date</label>
                <input 
                  type="date" 
                  value={formData.plannedDate || ""}
                  onChange={e => setFormData({ ...formData, plannedDate: e.target.value })}
                  className={`w-full bg-background border ${errors.plannedDate ? 'border-destructive' : 'border-border'} rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-primary`}
                />
                {errors.plannedDate && <p className="text-xs text-destructive">{errors.plannedDate}</p>}
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium text-muted-foreground">Planned Time</label>
                <input 
                  type="time" 
                  value={formData.plannedTime || ""}
                  onChange={e => setFormData({ ...formData, plannedTime: e.target.value })}
                  className={`w-full bg-background border border-border rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-primary`}
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-sm font-medium text-muted-foreground">Priority</label>
                <select 
                  value={formData.priority || "Medium"}
                  onChange={e => setFormData({ ...formData, priority: e.target.value as Priority })}
                  className="w-full bg-background border border-border rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-primary"
                >
                  <option value="Low">Low</option>
                  <option value="Medium">Medium</option>
                  <option value="High">High</option>
                  <option value="Urgent">Urgent</option>
                </select>
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium text-muted-foreground">Status</label>
                <select 
                  value={formData.status || "Pending"}
                  onChange={e => setFormData({ ...formData, status: e.target.value as OrderStatus })}
                  className="w-full bg-background border border-border rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-primary"
                >
                  <option value="Pending">Pending</option>
                  <option value="Assigned">Assigned</option>
                  <option value="In Transit">In Transit</option>
                  <option value="Completed">Completed</option>
                  <option value="Cancelled">Cancelled</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-6 pt-4 border-t border-border">
              <div className="space-y-2">
                <label className="text-sm font-medium text-muted-foreground">Assign Driver</label>
                <select 
                  value={formData.driverId || ""}
                  onChange={e => setFormData({ ...formData, driverId: e.target.value })}
                  className="w-full bg-background border border-border rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-primary"
                >
                  <option value="">Unassigned</option>
                  {drivers.map(d => (
                    <option key={d.id} value={d.id}>{d.name} ({d.status})</option>
                  ))}
                </select>
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium text-muted-foreground">Assign Vehicle</label>
                <select 
                  value={formData.vehicleId || ""}
                  onChange={e => setFormData({ ...formData, vehicleId: e.target.value })}
                  className="w-full bg-background border border-border rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-primary"
                >
                  <option value="">Unassigned</option>
                  {vehicles.map(v => (
                    <option key={v.id} value={v.id}>{v.plateNumber} ({v.type})</option>
                  ))}
                </select>
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-muted-foreground">Notes</label>
              <textarea 
                rows={3}
                value={formData.notes || ""}
                onChange={e => setFormData({ ...formData, notes: e.target.value })}
                className="w-full bg-background border border-border rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-primary"
              />
            </div>

            <div className="flex justify-end gap-4 pt-4">
              <button 
                type="button"
                onClick={() => setLocation("/orders")}
                className="px-4 py-2 text-sm font-medium text-muted-foreground hover:text-foreground transition-colors"
              >
                Cancel
              </button>
              <button 
                type="submit"
                className="px-6 py-2 bg-primary text-primary-foreground rounded-md text-sm font-medium hover:opacity-90 transition-opacity"
              >
                {editId ? "Save Changes" : "Create Order"}
              </button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
