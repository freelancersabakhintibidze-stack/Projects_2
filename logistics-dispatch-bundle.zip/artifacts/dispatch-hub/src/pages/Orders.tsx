import React from "react";
import { useStore } from "@/lib/store";
import { Card } from "@/components/ui/card";
import { Link } from "wouter";

export default function Orders() {
  const { orders, role } = useStore();

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold tracking-tight">Orders Registry</h2>
        {role === "Dispatcher" && (
          <Link href="/orders/new" className="bg-primary text-primary-foreground px-4 py-2 rounded-md font-medium text-sm hover:opacity-90 transition-opacity">
            + New Order
          </Link>
        )}
      </div>

      <Card className="border-border p-0 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm text-left">
            <thead className="text-xs text-muted-foreground uppercase bg-secondary/50 border-b border-border">
              <tr>
                <th className="px-4 py-3 font-medium">Order ID</th>
                <th className="px-4 py-3 font-medium">Customer</th>
                <th className="px-4 py-3 font-medium">Destination</th>
                <th className="px-4 py-3 font-medium">Priority</th>
                <th className="px-4 py-3 font-medium">Status</th>
                <th className="px-4 py-3 font-medium text-right">Weight (kg)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {orders.map((order) => (
                <tr key={order.id} className="hover:bg-secondary/20 transition-colors">
                  <td className="px-4 py-3 font-mono">
                    <Link href={`/orders/${order.id}`} className="text-primary hover:underline">
                      {order.id}
                    </Link>
                  </td>
                  <td className="px-4 py-3">{order.customerName}</td>
                  <td className="px-4 py-3 truncate max-w-[200px]">{order.destinationAddress}</td>
                  <td className="px-4 py-3">
                    <span className={`px-2 py-1 rounded text-xs font-medium ${
                      order.priority === 'Urgent' ? 'bg-red-500/20 text-red-500' :
                      order.priority === 'High' ? 'bg-orange-500/20 text-orange-500' :
                      order.priority === 'Medium' ? 'bg-blue-500/20 text-blue-500' :
                      'bg-gray-500/20 text-gray-400'
                    }`}>
                      {order.priority}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    {order.status}
                  </td>
                  <td className="px-4 py-3 text-right font-mono">{order.weight}</td>
                </tr>
              ))}
              {orders.length === 0 && (
                <tr>
                  <td colSpan={6} className="px-4 py-8 text-center text-muted-foreground">
                    No orders found.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}
