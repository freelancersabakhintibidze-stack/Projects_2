import React, { useState } from "react";
import { useStore } from "@/lib/store";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";

export default function Settings() {
  const { companyName, setCompanyName, role, setRole, resetData } = useStore();
  const [name, setName] = useState(companyName);

  const handleSave = () => {
    setCompanyName(name);
  };

  const handleReset = () => {
    if (window.confirm("WARNING: This will delete all local data and restore the initial seed data. Are you sure?")) {
      resetData();
    }
  };

  return (
    <div className="max-w-2xl space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold tracking-tight">Settings</h2>
      </div>

      <Card className="border-border">
        <CardHeader>
          <CardTitle>System Configuration</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-2">
            <label className="text-sm font-medium text-muted-foreground">Company Name</label>
            <div className="flex gap-2">
              <input 
                type="text" 
                value={name}
                onChange={e => setName(e.target.value)}
                className="flex-1 bg-background border border-border rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-primary"
              />
              <button 
                onClick={handleSave}
                className="px-4 py-2 bg-secondary hover:bg-secondary/80 text-secondary-foreground rounded-md text-sm font-medium transition-colors"
              >
                Save
              </button>
            </div>
          </div>

          <div className="pt-6 border-t border-border/50 space-y-2">
            <label className="text-sm font-medium text-muted-foreground">Access Role Override</label>
            <p className="text-xs text-muted-foreground mb-2">Instantly switch between roles to verify permissions.</p>
            <select 
              value={role}
              onChange={e => setRole(e.target.value as any)}
              className="w-full bg-background border border-border rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-primary"
            >
              <option value="Dispatcher">Dispatcher (Full Access)</option>
              <option value="Viewer">Viewer (Read-only)</option>
            </select>
          </div>

          <div className="pt-6 border-t border-border/50">
            <div className="bg-destructive/10 border border-destructive/20 rounded-md p-4 flex flex-col sm:flex-row gap-4 items-center justify-between">
              <div>
                <h4 className="font-bold text-destructive">Factory Reset</h4>
                <p className="text-xs text-destructive/80 mt-1">Clear all local storage data and re-seed the database.</p>
              </div>
              <button 
                onClick={handleReset}
                className="px-4 py-2 bg-destructive text-destructive-foreground rounded-md text-sm font-medium hover:bg-destructive/90 transition-colors whitespace-nowrap"
              >
                Reset Data
              </button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
