import React from "react";
import { useStore } from "@/lib/store";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Package, CheckCircle2, Clock, XCircle, AlertTriangle } from "lucide-react";

export default function Dashboard() {
  const { orders } = useStore();

  const totalOrders = orders.length;
  const completedOrders = orders.filter(o => o.status === "Completed").length;
  const pendingOrders = orders.filter(o => o.status === "Pending").length;
  const cancelledOrders = orders.filter(o => o.status === "Cancelled").length;
  
  const totalWeight = orders.reduce((sum, o) => sum + (o.status !== "Cancelled" ? o.weight : 0), 0);

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold tracking-tight">Overview</h2>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card className="bg-card border-border">
          <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
            <CardTitle className="text-sm font-medium text-muted-foreground">Total Orders</CardTitle>
            <Package className="w-4 h-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold font-mono">{totalOrders}</div>
          </CardContent>
        </Card>
        <Card className="bg-card border-border">
          <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
            <CardTitle className="text-sm font-medium text-muted-foreground">Completed</CardTitle>
            <CheckCircle2 className="w-4 h-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold font-mono text-green-500">{completedOrders}</div>
          </CardContent>
        </Card>
        <Card className="bg-card border-border">
          <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
            <CardTitle className="text-sm font-medium text-muted-foreground">Pending</CardTitle>
            <Clock className="w-4 h-4 text-yellow-500" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold font-mono text-yellow-500">{pendingOrders}</div>
          </CardContent>
        </Card>
        <Card className="bg-card border-border">
          <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
            <CardTitle className="text-sm font-medium text-muted-foreground">Active Cargo Weight</CardTitle>
            <AlertTriangle className="w-4 h-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold font-mono">{totalWeight.toLocaleString()} <span className="text-sm text-muted-foreground">kg</span></div>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
        <Card className="col-span-4 border-border">
          <CardHeader>
            <CardTitle>Recent Activity Feed</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {orders.slice(0, 5).map(order => (
                <div key={order.id} className="flex items-center gap-4 border-b border-border/50 pb-4 last:border-0">
                  <div className={`w-2 h-2 rounded-full ${order.status === 'Completed' ? 'bg-green-500' : order.status === 'Cancelled' ? 'bg-red-500' : 'bg-primary'}`} />
                  <div className="flex-1 space-y-1">
                    <p className="text-sm font-medium leading-none">Order {order.id} - {order.status}</p>
                    <p className="text-sm text-muted-foreground">
                      {order.customerName} • {order.cargoDescription}
                    </p>
                  </div>
                  <div className="text-sm font-mono text-muted-foreground text-right">
                    {order.plannedTime}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
        
        <Card className="col-span-3 border-border">
          <CardHeader>
            <CardTitle>Deliveries by Priority</CardTitle>
          </CardHeader>
          <CardContent>
             {/* A simple visualization could go here */}
             <div className="space-y-4">
               {['Urgent', 'High', 'Medium', 'Low'].map(priority => {
                 const count = orders.filter(o => o.priority === priority).length;
                 const percent = totalOrders > 0 ? (count / totalOrders) * 100 : 0;
                 return (
                   <div key={priority} className="flex items-center gap-4">
                     <div className="w-16 text-sm font-medium">{priority}</div>
                     <div className="flex-1 h-2 bg-secondary rounded-full overflow-hidden">
                       <div className="h-full bg-primary" style={{ width: `${percent}%` }} />
                     </div>
                     <div className="w-8 text-right text-sm font-mono">{count}</div>
                   </div>
                 );
               })}
             </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
