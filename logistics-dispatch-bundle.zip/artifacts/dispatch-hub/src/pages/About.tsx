import React from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";

export default function About() {
  return (
    <div className="max-w-2xl space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <h2 className="text-3xl font-bold tracking-tight">About Dispatch Hub</h2>

      <Card className="border-border">
        <CardHeader>
          <CardTitle>System Information</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4 text-muted-foreground text-sm leading-relaxed">
          <p>
            Dispatch Hub is a frontend-only logistics management console designed for speed and high information density. 
            All data is securely persisted within your browser's local storage.
          </p>
          <p>
            <strong>Version:</strong> 1.0.0-rc1<br/>
            <strong>Environment:</strong> Local / In-Browser<br/>
            <strong>Theme:</strong> Industrial Dark
          </p>
          <div className="pt-4 mt-4 border-t border-border/50">
            <h4 className="font-medium text-foreground mb-2">Key Features:</h4>
            <ul className="list-disc list-inside space-y-1 ml-4">
              <li>Real-time order tracking and status management</li>
              <li>Fleet and driver assignment</li>
              <li>Role-based access control (Dispatcher vs Viewer)</li>
              <li>Daily operations reporting</li>
            </ul>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
