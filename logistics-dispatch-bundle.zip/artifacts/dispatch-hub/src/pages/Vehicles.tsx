import React from "react";
import { useStore } from "@/lib/store";
import { Card } from "@/components/ui/card";

export default function Vehicles() {
  const { vehicles, role } = useStore();

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold tracking-tight">Vehicle Registry</h2>
        {role === "Dispatcher" && (
          <button className="bg-primary text-primary-foreground px-4 py-2 rounded-md font-medium text-sm hover:opacity-90 transition-opacity">
            + Add Vehicle
          </button>
        )}
      </div>

      <Card className="border-border p-0 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm text-left">
            <thead className="text-xs text-muted-foreground uppercase bg-secondary/50 border-b border-border">
              <tr>
                <th className="px-4 py-3 font-medium">Plate Number</th>
                <th className="px-4 py-3 font-medium">Type</th>
                <th className="px-4 py-3 font-medium">Capacity (kg)</th>
                <th className="px-4 py-3 font-medium">Status</th>
                {role === "Dispatcher" && <th className="px-4 py-3 font-medium text-right">Actions</th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {vehicles.map((vehicle) => (
                <tr key={vehicle.id} className="hover:bg-secondary/20 transition-colors">
                  <td className="px-4 py-3 font-mono font-bold text-primary">{vehicle.plateNumber}</td>
                  <td className="px-4 py-3">{vehicle.type}</td>
                  <td className="px-4 py-3">{vehicle.capacity.toLocaleString()}</td>
                  <td className="px-4 py-3">
                    <span className={`px-2 py-1 rounded text-xs font-medium ${
                      vehicle.status === 'Available' ? 'bg-green-500/20 text-green-500' :
                      vehicle.status === 'In Use' ? 'bg-blue-500/20 text-blue-500' :
                      'bg-orange-500/20 text-orange-500'
                    }`}>
                      {vehicle.status}
                    </span>
                  </td>
                  {role === "Dispatcher" && (
                    <td className="px-4 py-3 text-right space-x-2">
                      <button className="text-xs px-2 py-1 bg-secondary hover:bg-secondary/80 rounded transition-colors">Edit</button>
                      <button className="text-xs px-2 py-1 text-destructive hover:bg-destructive/10 rounded transition-colors">Delete</button>
                    </td>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}
