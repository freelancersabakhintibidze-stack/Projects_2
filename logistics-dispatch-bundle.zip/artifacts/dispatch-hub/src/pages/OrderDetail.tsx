import React, { useState } from "react";
import { useLocation, useParams } from "wouter";
import { useStore, Order, OrderStatus } from "@/lib/store";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { ArrowLeft, Edit, Trash2, CheckCircle, XCircle } from "lucide-react";

export default function OrderDetail() {
  const { id } = useParams();
  const [, setLocation] = useLocation();
  const { orders, drivers, vehicles, role, updateOrder, deleteOrder } = useStore();

  const order = orders.find(o => o.id === id);

  if (!order) {
    return <div className="p-8 text-center text-muted-foreground">Order not found.</div>;
  }

  const driver = drivers.find(d => d.id === order.driverId);
  const vehicle = vehicles.find(v => v.id === order.vehicleId);

  const handleDelete = () => {
    if (window.confirm("Are you sure you want to delete this order?")) {
      deleteOrder(order.id);
      setLocation("/orders");
    }
  };

  const handleStatusChange = (status: OrderStatus) => {
    updateOrder(order.id, { status });
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <button 
            onClick={() => setLocation("/orders")}
            className="p-2 hover:bg-secondary rounded-full transition-colors"
          >
            <ArrowLeft className="w-5 h-5 text-muted-foreground" />
          </button>
          <h2 className="text-3xl font-bold tracking-tight font-mono">{order.id}</h2>
          <span className={`px-3 py-1 rounded-full text-sm font-medium border ${
            order.status === 'Completed' ? 'border-green-500 text-green-500' :
            order.status === 'Cancelled' ? 'border-red-500 text-red-500' :
            order.status === 'In Transit' ? 'border-blue-500 text-blue-500' :
            'border-primary text-primary'
          }`}>
            {order.status}
          </span>
        </div>
        
        {role === "Dispatcher" && (
          <div className="flex gap-2">
            {order.status !== 'Completed' && order.status !== 'Cancelled' && (
              <>
                <button onClick={() => handleStatusChange("Completed")} className="flex items-center gap-2 px-3 py-2 bg-green-500/10 text-green-500 hover:bg-green-500/20 rounded-md text-sm font-medium transition-colors">
                  <CheckCircle className="w-4 h-4" /> Complete
                </button>
                <button onClick={() => handleStatusChange("Cancelled")} className="flex items-center gap-2 px-3 py-2 bg-red-500/10 text-red-500 hover:bg-red-500/20 rounded-md text-sm font-medium transition-colors">
                  <XCircle className="w-4 h-4" /> Cancel
                </button>
              </>
            )}
            <button onClick={() => setLocation(`/orders/new?edit=${order.id}`)} className="flex items-center gap-2 px-3 py-2 bg-secondary text-secondary-foreground hover:bg-secondary/80 rounded-md text-sm font-medium transition-colors">
              <Edit className="w-4 h-4" /> Edit
            </button>
            <button onClick={handleDelete} className="flex items-center gap-2 px-3 py-2 bg-destructive/10 text-destructive hover:bg-destructive/20 rounded-md text-sm font-medium transition-colors">
              <Trash2 className="w-4 h-4" /> Delete
            </button>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="col-span-2 border-border">
          <CardHeader>
            <CardTitle>Delivery Details</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-2 gap-6">
              <div>
                <div className="text-sm text-muted-foreground mb-1">Customer</div>
                <div className="font-medium">{order.customerName}</div>
                <div className="text-sm mt-1">{order.phone}</div>
              </div>
              <div>
                <div className="text-sm text-muted-foreground mb-1">Cargo</div>
                <div className="font-medium">{order.cargoDescription}</div>
                <div className="text-sm mt-1">{order.weight} kg</div>
              </div>
            </div>

            <div className="pt-4 border-t border-border/50">
              <div className="relative pl-6 pb-6 border-l-2 border-border ml-2">
                <div className="absolute w-3 h-3 bg-secondary border-2 border-border rounded-full -left-[7px] top-1"></div>
                <div className="text-sm text-muted-foreground mb-1 font-mono">{order.plannedDate} {order.plannedTime}</div>
                <div className="font-medium">Pickup</div>
                <div className="text-sm text-muted-foreground mt-1">{order.pickupAddress}</div>
              </div>
              <div className="relative pl-6 ml-2">
                <div className="absolute w-3 h-3 bg-primary border-2 border-primary rounded-full -left-[7px] top-1 shadow-[0_0_10px_rgba(var(--primary),0.5)]"></div>
                <div className="font-medium">Destination</div>
                <div className="text-sm text-muted-foreground mt-1">{order.destinationAddress}</div>
              </div>
            </div>

            {order.notes && (
              <div className="pt-4 border-t border-border/50">
                <div className="text-sm text-muted-foreground mb-2">Notes</div>
                <div className="bg-secondary/30 p-3 rounded-md text-sm text-muted-foreground">
                  {order.notes}
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="col-span-1 border-border">
          <CardHeader>
            <CardTitle>Assignment</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <div className="text-sm text-muted-foreground mb-2">Priority</div>
              <div className={`inline-flex px-3 py-1 rounded text-sm font-medium ${
                order.priority === 'Urgent' ? 'bg-red-500/20 text-red-500' :
                order.priority === 'High' ? 'bg-orange-500/20 text-orange-500' :
                order.priority === 'Medium' ? 'bg-blue-500/20 text-blue-500' :
                'bg-gray-500/20 text-gray-400'
              }`}>
                {order.priority} Priority
              </div>
            </div>

            <div className="pt-4 border-t border-border/50">
              <div className="text-sm text-muted-foreground mb-2">Driver</div>
              {driver ? (
                <div>
                  <div className="font-medium">{driver.name}</div>
                  <div className="text-sm text-muted-foreground">{driver.phone}</div>
                </div>
              ) : (
                <div className="text-sm text-muted-foreground italic">Unassigned</div>
              )}
            </div>

            <div className="pt-4 border-t border-border/50">
              <div className="text-sm text-muted-foreground mb-2">Vehicle</div>
              {vehicle ? (
                <div>
                  <div className="font-medium">{vehicle.plateNumber}</div>
                  <div className="text-sm text-muted-foreground">{vehicle.type} ({vehicle.capacity}kg max)</div>
                </div>
              ) : (
                <div className="text-sm text-muted-foreground italic">Unassigned</div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
