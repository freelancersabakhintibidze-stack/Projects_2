import React from "react";
import { useStore } from "@/lib/store";
import { Card } from "@/components/ui/card";

export default function Drivers() {
  const { drivers, role } = useStore();

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold tracking-tight">Fleet Drivers</h2>
        {role === "Dispatcher" && (
          <button className="bg-primary text-primary-foreground px-4 py-2 rounded-md font-medium text-sm hover:opacity-90 transition-opacity">
            + Add Driver
          </button>
        )}
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {drivers.map(driver => (
          <Card key={driver.id} className="border-border p-6 flex flex-col gap-4">
            <div className="flex justify-between items-start">
              <div>
                <h3 className="font-bold text-lg">{driver.name}</h3>
                <p className="text-sm text-muted-foreground font-mono mt-1">{driver.id}</p>
              </div>
              <span className={`px-2 py-1 rounded text-xs font-medium ${
                driver.status === 'Available' ? 'bg-green-500/20 text-green-500' :
                driver.status === 'On Delivery' ? 'bg-blue-500/20 text-blue-500' :
                'bg-gray-500/20 text-gray-400'
              }`}>
                {driver.status}
              </span>
            </div>
            
            <div className="space-y-2 text-sm mt-auto pt-4 border-t border-border/50">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Phone</span>
                <span className="font-medium">{driver.phone}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">License</span>
                <span className="font-mono">{driver.licenseNumber}</span>
              </div>
            </div>

            {role === "Dispatcher" && (
              <div className="flex gap-2 mt-4">
                <button className="flex-1 py-1.5 bg-secondary text-secondary-foreground text-xs rounded font-medium hover:bg-secondary/80 transition-colors">Edit</button>
                <button className="flex-1 py-1.5 bg-destructive/10 text-destructive text-xs rounded font-medium hover:bg-destructive/20 transition-colors">Remove</button>
              </div>
            )}
          </Card>
        ))}
      </div>
    </div>
  );
}
