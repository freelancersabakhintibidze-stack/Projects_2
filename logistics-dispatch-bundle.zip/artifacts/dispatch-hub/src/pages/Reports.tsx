import React from "react";
import { useStore } from "@/lib/store";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";

export default function Reports() {
  const { orders } = useStore();

  const today = new Date().toISOString().split('T')[0];
  const todaysOrders = orders.filter(o => o.plannedDate === today);
  
  const completed = todaysOrders.filter(o => o.status === "Completed").length;
  const pending = todaysOrders.filter(o => o.status === "Pending" || o.status === "Assigned" || o.status === "In Transit").length;
  const cancelled = todaysOrders.filter(o => o.status === "Cancelled").length;
  
  const totalWeight = todaysOrders.reduce((sum, o) => sum + (o.status !== "Cancelled" ? o.weight : 0), 0);

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold tracking-tight">Daily Report</h2>
        <div className="text-sm font-mono text-muted-foreground bg-secondary px-3 py-1 rounded">
          {today}
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card className="border-border">
          <CardHeader>
            <CardTitle>Today's Summary</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex justify-between items-center py-2 border-b border-border/50">
              <span className="text-muted-foreground">Total Scheduled Orders</span>
              <span className="font-bold font-mono">{todaysOrders.length}</span>
            </div>
            <div className="flex justify-between items-center py-2 border-b border-border/50">
              <span className="text-muted-foreground">Completed</span>
              <span className="font-bold font-mono text-green-500">{completed}</span>
            </div>
            <div className="flex justify-between items-center py-2 border-b border-border/50">
              <span className="text-muted-foreground">Active / Pending</span>
              <span className="font-bold font-mono text-yellow-500">{pending}</span>
            </div>
            <div className="flex justify-between items-center py-2 border-b border-border/50">
              <span className="text-muted-foreground">Cancelled</span>
              <span className="font-bold font-mono text-red-500">{cancelled}</span>
            </div>
            <div className="flex justify-between items-center py-2">
              <span className="text-muted-foreground">Total Cargo Moved</span>
              <span className="font-bold font-mono">{totalWeight.toLocaleString()} kg</span>
            </div>
          </CardContent>
        </Card>

        <Card className="border-border bg-primary/5 border-primary/20">
          <CardHeader>
            <CardTitle className="text-primary">System Insights</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Operations are running at {(completed / (todaysOrders.length || 1) * 100).toFixed(1)}% completion rate for today. 
              {pending > 5 ? " High volume of pending orders detected. Consider reassigning available drivers." : " Load is balanced."}
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
