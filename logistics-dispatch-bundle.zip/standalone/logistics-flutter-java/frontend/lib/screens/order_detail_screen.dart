import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/order.dart';
import '../state/order_provider.dart';
import '../state/role_provider.dart';
import '../theme/app_theme.dart';
import '../widgets/app_scaffold.dart';
import '../widgets/status_badge.dart';
import 'order_form_screen.dart';

class OrderDetailScreen extends StatelessWidget {
  final String orderId;

  const OrderDetailScreen({super.key, required this.orderId});

  @override
  Widget build(BuildContext context) {
    final orders = context.watch<OrderProvider>();
    final role = context.watch<RoleProvider>();
    final order = orders.findById(orderId);

    if (order == null) {
      return AppScaffold(
        currentRoute: '/orders',
        title: 'Order not found',
        body: const EmptyState(
          icon: Icons.error_outline,
          title: 'Order not found',
          message: 'This order may have been deleted.',
        ),
      );
    }

    return AppScaffold(
      currentRoute: '/orders',
      title: 'Order ${order.id}',
      actions: role.isDispatcher
          ? [
              IconButton(
                icon: const Icon(Icons.edit_outlined),
                onPressed: () => Navigator.of(context).push(MaterialPageRoute(
                    builder: (_) => OrderFormScreen(existingOrder: order))),
              ),
              IconButton(
                icon: const Icon(Icons.delete_outline, color: AppTheme.danger),
                onPressed: () async {
                  final confirmed = await showConfirmDialog(
                    context,
                    title: 'Delete Order',
                    message: 'Are you sure you want to delete order ${order.id}? This action cannot be undone.',
                  );
                  if (confirmed) {
                    final error = await context.read<OrderProvider>().deleteOrder(order.id);
                    if (context.mounted) {
                      if (error == null) {
                        Navigator.of(context).pop();
                      } else {
                        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(error)));
                      }
                    }
                  }
                },
              ),
            ]
          : null,
      body: SingleChildScrollView(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 720),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SectionCard(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        StatusBadge(label: statusLabel(order.status), color: AppTheme.statusColor(statusToApi(order.status))),
                        const SizedBox(width: 8),
                        StatusBadge(label: priorityLabel(order.priority), color: AppTheme.priorityColor(priorityToApi(order.priority))),
                      ],
                    ),
                    const SizedBox(height: 16),
                    _row('Customer', order.customerName),
                    _row('Phone', order.phone),
                    _row('Pickup', order.pickupAddress),
                    _row('Destination', order.destinationAddress),
                    _row('Cargo', order.cargoDescription),
                    _row('Weight', '${order.weightKg} kg'),
                    _row('Vehicle', order.vehicleId ?? 'Unassigned'),
                    _row('Driver', order.driverId ?? 'Unassigned'),
                    _row('Planned Date', order.plannedDate.toIso8601String().split('T').first),
                    _row('Planned Time', order.plannedTime),
                    if ((order.notes ?? '').isNotEmpty) _row('Notes', order.notes!),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              if (role.isDispatcher && order.status != OrderStatus.completed && order.status != OrderStatus.cancelled)
                SectionCard(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('Update Status', style: TextStyle(fontWeight: FontWeight.bold)),
                      const SizedBox(height: 12),
                      Wrap(
                        spacing: 10,
                        children: OrderStatus.values
                            .where((s) => s != order.status)
                            .map((s) => OutlinedButton(
                                  onPressed: () => context.read<OrderProvider>().updateStatus(order.id, s),
                                  child: Text(statusLabel(s)),
                                ))
                            .toList(),
                      ),
                    ],
                  ),
                ),
              const SizedBox(height: 16),
              SectionCard(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Status Timeline', style: TextStyle(fontWeight: FontWeight.bold)),
                    const SizedBox(height: 12),
                    ...order.statusHistory.map((entry) => Padding(
                          padding: const EdgeInsets.symmetric(vertical: 6),
                          child: Row(
                            children: [
                              StatusBadge(label: statusLabel(entry.status), color: AppTheme.statusColor(statusToApi(entry.status))),
                              const SizedBox(width: 10),
                              Text(entry.timestamp, style: const TextStyle(color: AppTheme.textSecondary, fontSize: 12)),
                            ],
                          ),
                        )),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _row(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(width: 140, child: Text(label, style: const TextStyle(color: AppTheme.textSecondary))),
          Expanded(child: Text(value)),
        ],
      ),
    );
  }
}
