import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../state/dashboard_provider.dart';
import '../theme/app_theme.dart';
import '../widgets/app_scaffold.dart';

class ReportsScreen extends StatefulWidget {
  const ReportsScreen({super.key});

  @override
  State<ReportsScreen> createState() => _ReportsScreenState();
}

class _ReportsScreenState extends State<ReportsScreen> {
  DateTime _selectedDate = DateTime.now();
  Map<String, dynamic>? _report;
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _loadReport());
  }

  Future<void> _loadReport() async {
    setState(() => _isLoading = true);
    final report = await context.read<DashboardProvider>().fetchDailyReport(_selectedDate);
    setState(() {
      _report = report;
      _isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return AppScaffold(
      currentRoute: '/reports',
      title: 'Daily Report',
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              OutlinedButton.icon(
                icon: const Icon(Icons.calendar_today, size: 16),
                label: Text(
                    '${_selectedDate.year}-${_selectedDate.month.toString().padLeft(2, '0')}-${_selectedDate.day.toString().padLeft(2, '0')}'),
                onPressed: () async {
                  final picked = await showDatePicker(
                    context: context,
                    initialDate: _selectedDate,
                    firstDate: DateTime.now().subtract(const Duration(days: 365)),
                    lastDate: DateTime.now().add(const Duration(days: 365)),
                  );
                  if (picked != null) {
                    setState(() => _selectedDate = picked);
                    _loadReport();
                  }
                },
              ),
              const SizedBox(width: 12),
              IconButton(onPressed: _loadReport, icon: const Icon(Icons.refresh)),
            ],
          ),
          const SizedBox(height: 20),
          if (_isLoading)
            const Expanded(child: Center(child: CircularProgressIndicator()))
          else if (_report == null)
            const Expanded(child: Center(child: Text('No report data available.', style: TextStyle(color: AppTheme.textSecondary))))
          else
            Expanded(child: _buildReport(_report!)),
        ],
      ),
    );
  }

  Widget _buildReport(Map<String, dynamic> report) {
    final orders = List<dynamic>.from(report['orders'] ?? []);
    return ListView(
      children: [
        LayoutBuilder(builder: (context, constraints) {
          final crossAxisCount = constraints.maxWidth > 700 ? 4 : 2;
          final metrics = [
            ('Total Orders', '${report['totalOrders'] ?? 0}', AppTheme.textPrimary),
            ('Completed', '${report['completed'] ?? 0}', AppTheme.success),
            ('Pending', '${report['pending'] ?? 0}', AppTheme.accent),
            ('Cancelled', '${report['cancelled'] ?? 0}', AppTheme.danger),
          ];
          return GridView.count(
            crossAxisCount: crossAxisCount,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            mainAxisSpacing: 12,
            crossAxisSpacing: 12,
            childAspectRatio: 1.8,
            children: metrics
                .map((m) => Card(
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(m.$1, style: const TextStyle(color: AppTheme.textSecondary, fontSize: 13)),
                            const Spacer(),
                            Text(m.$2, style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold, color: m.$3)),
                          ],
                        ),
                      ),
                    ))
                .toList(),
          );
        }),
        const SizedBox(height: 16),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('Total Cargo Weight'),
                Text('${report['totalCargoWeightKg'] ?? 0} kg', style: const TextStyle(fontWeight: FontWeight.bold)),
              ],
            ),
          ),
        ),
        const SizedBox(height: 16),
        const Text('Orders Planned This Day', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
        const SizedBox(height: 8),
        if (orders.isEmpty)
          const Padding(
            padding: EdgeInsets.symmetric(vertical: 24),
            child: Text('No orders planned for this day.', style: TextStyle(color: AppTheme.textSecondary)),
          )
        else
          ...orders.map((o) {
            final order = Map<String, dynamic>.from(o);
            return Card(
              margin: const EdgeInsets.only(bottom: 8),
              child: ListTile(
                title: Text('${order['id']} - ${order['customerName']}'),
                subtitle: Text('${order['cargoDescription']} • ${order['weightKg']} kg'),
                trailing: Text(order['status'] ?? ''),
              ),
            );
          }),
      ],
    );
  }
}
