import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../state/dashboard_provider.dart';
import '../theme/app_theme.dart';
import '../widgets/app_scaffold.dart';
import '../widgets/status_badge.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<DashboardProvider>().fetchOverview();
    });
  }

  @override
  Widget build(BuildContext context) {
    final dashboard = context.watch<DashboardProvider>();

    return AppScaffold(
      currentRoute: '/dashboard',
      title: 'Overview',
      body: RefreshIndicator(
        onRefresh: () => context.read<DashboardProvider>().fetchOverview(),
        child: dashboard.isLoading && dashboard.overview == null
            ? const Center(child: CircularProgressIndicator())
            : dashboard.error != null
                ? Center(child: Text(dashboard.error!, style: const TextStyle(color: AppTheme.danger)))
                : _buildContent(dashboard.overview ?? {}),
      ),
    );
  }

  Widget _buildContent(Map<String, dynamic> data) {
    final metrics = [
      ('Total Orders', '${data['totalOrders'] ?? 0}', Icons.inventory_2_outlined, AppTheme.textPrimary),
      ('Completed', '${data['completed'] ?? 0}', Icons.check_circle_outline, AppTheme.success),
      ('Pending', '${data['pending'] ?? 0}', Icons.schedule_outlined, AppTheme.accent),
      ('Cancelled', '${data['cancelled'] ?? 0}', Icons.cancel_outlined, AppTheme.danger),
    ];

    final byPriority = Map<String, dynamic>.from(data['deliveriesByPriority'] ?? {});
    final byCity = Map<String, dynamic>.from(data['deliveriesByCity'] ?? {});
    final activity = List<dynamic>.from(data['recentActivity'] ?? []);

    return ListView(
      children: [
        LayoutBuilder(builder: (context, constraints) {
          final crossAxisCount = constraints.maxWidth > 700 ? 4 : 2;
          return GridView.count(
            crossAxisCount: crossAxisCount,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            mainAxisSpacing: 12,
            crossAxisSpacing: 12,
            childAspectRatio: 1.6,
            children: metrics
                .map((m) => SectionCard(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(m.$1, style: const TextStyle(color: AppTheme.textSecondary, fontSize: 13)),
                              Icon(m.$3, size: 18, color: m.$4),
                            ],
                          ),
                          const Spacer(),
                          Text(m.$2, style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold, color: m.$4)),
                        ],
                      ),
                    ))
                .toList(),
          );
        }),
        const SizedBox(height: 16),
        Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              flex: 3,
              child: SectionCard(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Recent Activity', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                    const SizedBox(height: 12),
                    if (activity.isEmpty)
                      const Text('No recent activity yet.', style: TextStyle(color: AppTheme.textSecondary))
                    else
                      ...activity.map((order) {
                        final o = Map<String, dynamic>.from(order);
                        return Padding(
                          padding: const EdgeInsets.symmetric(vertical: 8),
                          child: Row(
                            children: [
                              Container(width: 6, height: 6, decoration: const BoxDecoration(color: AppTheme.accent, shape: BoxShape.circle)),
                              const SizedBox(width: 10),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text('Order ${o['id']} - ${o['status']}', style: const TextStyle(fontWeight: FontWeight.w600)),
                                    Text('${o['customerName'] ?? ''} • ${o['cargoDescription'] ?? ''}',
                                        style: const TextStyle(color: AppTheme.textSecondary, fontSize: 12)),
                                  ],
                                ),
                              ),
                              StatusBadge(label: o['status'] ?? '', color: AppTheme.statusColor(o['status'] ?? '')),
                            ],
                          ),
                        );
                      }),
                  ],
                ),
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              flex: 2,
              child: SectionCard(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Deliveries by Priority', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                    const SizedBox(height: 12),
                    ...['URGENT', 'HIGH', 'MEDIUM', 'LOW'].map((p) {
                      final count = byPriority[p] ?? 0;
                      return Padding(
                        padding: const EdgeInsets.symmetric(vertical: 6),
                        child: Row(
                          children: [
                            SizedBox(width: 60, child: Text(p, style: const TextStyle(fontSize: 12))),
                            Expanded(
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(4),
                                child: LinearProgressIndicator(
                                  value: count == 0 ? 0 : (count / (data['totalOrders'] ?? 1)).clamp(0.0, 1.0),
                                  backgroundColor: AppTheme.surfaceAlt,
                                  color: AppTheme.priorityColor(p),
                                  minHeight: 8,
                                ),
                              ),
                            ),
                            const SizedBox(width: 8),
                            Text('$count'),
                          ],
                        ),
                      );
                    }),
                    const SizedBox(height: 16),
                    const Text('Deliveries by City', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                    const SizedBox(height: 8),
                    if (byCity.isEmpty)
                      const Text('No city data yet.', style: TextStyle(color: AppTheme.textSecondary))
                    else
                      ...byCity.entries.map((e) => Padding(
                            padding: const EdgeInsets.symmetric(vertical: 4),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [Text(e.key), Text('${e.value}')],
                            ),
                          )),
                  ],
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }
}
