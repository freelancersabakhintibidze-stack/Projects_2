import 'package:flutter/material.dart';

import '../theme/app_theme.dart';
import '../widgets/app_scaffold.dart';
import '../widgets/status_badge.dart';

class AboutScreen extends StatelessWidget {
  const AboutScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return AppScaffold(
      currentRoute: '/about',
      title: 'About',
      body: SingleChildScrollView(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 640),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SectionCard(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Apex Logistics Dispatch Console', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20)),
                    const SizedBox(height: 8),
                    const Text(
                      'A database-less logistics dispatch system for coordinating transport orders, drivers, and vehicles across a busy day.',
                      style: TextStyle(color: AppTheme.textSecondary),
                    ),
                    const SizedBox(height: 16),
                    _row('Frontend', 'Flutter (Material 3, Provider, dio, shared_preferences)'),
                    _row('Backend', 'Java 17 + Spring Boot REST API'),
                    _row('Persistence', 'JSON files on disk (orders.json, drivers.json, vehicles.json) — no database'),
                    _row('Concurrency', 'ConcurrentHashMap in-memory cache + ReentrantReadWriteLock guarded file writes'),
                    _row('Version', '1.0.0'),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              SectionCard(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Roles', style: TextStyle(fontWeight: FontWeight.bold)),
                    const SizedBox(height: 12),
                    const Text('Dispatcher — full access: create, edit, delete, and complete orders; manage drivers and vehicles.'),
                    const SizedBox(height: 6),
                    const Text('Viewer — read-only: can search, filter, and view orders, drivers, vehicles, and reports.'),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _row(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(width: 120, child: Text(label, style: const TextStyle(color: AppTheme.textSecondary))),
          Expanded(child: Text(value)),
        ],
      ),
    );
  }
}
