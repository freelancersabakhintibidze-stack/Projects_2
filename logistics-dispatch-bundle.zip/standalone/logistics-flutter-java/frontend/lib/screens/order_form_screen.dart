import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/order.dart';
import '../state/driver_provider.dart';
import '../state/order_provider.dart';
import '../state/vehicle_provider.dart';
import '../theme/app_theme.dart';
import '../widgets/app_scaffold.dart';

/// Handles both create (existingOrder == null) and edit (existingOrder set).
class OrderFormScreen extends StatefulWidget {
  final DispatchOrder? existingOrder;

  const OrderFormScreen({super.key, this.existingOrder});

  @override
  State<OrderFormScreen> createState() => _OrderFormScreenState();
}

class _OrderFormScreenState extends State<OrderFormScreen> {
  final _formKey = GlobalKey<FormState>();

  late TextEditingController _idController;
  late TextEditingController _customerController;
  late TextEditingController _phoneController;
  late TextEditingController _pickupController;
  late TextEditingController _destinationController;
  late TextEditingController _cargoController;
  late TextEditingController _weightController;
  late TextEditingController _notesController;

  DateTime? _plannedDate;
  TimeOfDay? _plannedTime;
  OrderPriority _priority = OrderPriority.medium;
  String? _vehicleId;
  String? _driverId;

  bool _isSubmitting = false;
  String? _submitError;

  bool get isEdit => widget.existingOrder != null;

  @override
  void initState() {
    super.initState();
    final o = widget.existingOrder;
    _idController = TextEditingController(text: o?.id ?? '');
    _customerController = TextEditingController(text: o?.customerName ?? '');
    _phoneController = TextEditingController(text: o?.phone ?? '');
    _pickupController = TextEditingController(text: o?.pickupAddress ?? '');
    _destinationController = TextEditingController(text: o?.destinationAddress ?? '');
    _cargoController = TextEditingController(text: o?.cargoDescription ?? '');
    _weightController = TextEditingController(text: o?.weightKg.toString() ?? '');
    _notesController = TextEditingController(text: o?.notes ?? '');
    _plannedDate = o?.plannedDate;
    if (o != null) {
      final parts = o.plannedTime.split(':');
      _plannedTime = TimeOfDay(hour: int.parse(parts[0]), minute: int.parse(parts[1]));
    }
    _priority = o?.priority ?? OrderPriority.medium;
    _vehicleId = o?.vehicleId;
    _driverId = o?.driverId;

    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<DriverProvider>().fetchDrivers();
      context.read<VehicleProvider>().fetchVehicles();
    });
  }

  @override
  void dispose() {
    _idController.dispose();
    _customerController.dispose();
    _phoneController.dispose();
    _pickupController.dispose();
    _destinationController.dispose();
    _cargoController.dispose();
    _weightController.dispose();
    _notesController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final drivers = context.watch<DriverProvider>().drivers;
    final vehicles = context.watch<VehicleProvider>().vehicles;

    return AppScaffold(
      currentRoute: '/orders',
      title: isEdit ? 'Edit Order' : 'New Order',
      body: SingleChildScrollView(
        child: Form(
          key: _formKey,
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 640),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (_submitError != null)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 16),
                    child: Text(_submitError!, style: const TextStyle(color: AppTheme.danger)),
                  ),
                TextFormField(
                  controller: _idController,
                  enabled: !isEdit,
                  decoration: const InputDecoration(labelText: 'Order ID *'),
                  validator: (v) {
                    final trimmed = v?.trim() ?? '';
                    if (trimmed.isEmpty) return 'Order ID is required';
                    if (!isEdit && context.read<OrderProvider>().idExists(trimmed)) {
                      return 'This Order ID already exists';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 16),
                TextFormField(
                  controller: _customerController,
                  decoration: const InputDecoration(labelText: 'Customer Name *'),
                  validator: _requiredValidator,
                ),
                const SizedBox(height: 16),
                TextFormField(
                  controller: _phoneController,
                  decoration: const InputDecoration(labelText: 'Phone *'),
                  validator: (v) {
                    final trimmed = v?.trim() ?? '';
                    if (trimmed.isEmpty) return 'Phone is required';
                    final regex = RegExp(r'^\+?[0-9()\-\s]{7,20}$');
                    if (!regex.hasMatch(trimmed)) return 'Enter a valid phone number';
                    return null;
                  },
                ),
                const SizedBox(height: 16),
                TextFormField(
                  controller: _pickupController,
                  decoration: const InputDecoration(labelText: 'Pickup Address *'),
                  validator: _requiredValidator,
                ),
                const SizedBox(height: 16),
                TextFormField(
                  controller: _destinationController,
                  decoration: const InputDecoration(labelText: 'Destination Address *'),
                  validator: _requiredValidator,
                ),
                const SizedBox(height: 16),
                TextFormField(
                  controller: _cargoController,
                  decoration: const InputDecoration(labelText: 'Cargo Description *'),
                  validator: _requiredValidator,
                ),
                const SizedBox(height: 16),
                TextFormField(
                  controller: _weightController,
                  keyboardType: const TextInputType.numberWithOptions(decimal: true),
                  decoration: const InputDecoration(labelText: 'Weight (kg) *'),
                  validator: (v) {
                    final trimmed = v?.trim() ?? '';
                    if (trimmed.isEmpty) return 'Weight is required';
                    final parsed = double.tryParse(trimmed);
                    if (parsed == null || parsed <= 0) return 'Weight must be a positive number';
                    return null;
                  },
                ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton.icon(
                        icon: const Icon(Icons.calendar_today, size: 16),
                        label: Text(_plannedDate == null
                            ? 'Planned Date *'
                            : '${_plannedDate!.year}-${_plannedDate!.month.toString().padLeft(2, '0')}-${_plannedDate!.day.toString().padLeft(2, '0')}'),
                        onPressed: () async {
                          final picked = await showDatePicker(
                            context: context,
                            initialDate: _plannedDate ?? DateTime.now(),
                            firstDate: DateTime.now(),
                            lastDate: DateTime.now().add(const Duration(days: 365)),
                          );
                          if (picked != null) setState(() => _plannedDate = picked);
                        },
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: OutlinedButton.icon(
                        icon: const Icon(Icons.access_time, size: 16),
                        label: Text(_plannedTime == null ? 'Planned Time *' : _plannedTime!.format(context)),
                        onPressed: () async {
                          final picked = await showTimePicker(context: context, initialTime: TimeOfDay.now());
                          if (picked != null) setState(() => _plannedTime = picked);
                        },
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                DropdownButtonFormField<OrderPriority>(
                  value: _priority,
                  decoration: const InputDecoration(labelText: 'Priority *'),
                  items: OrderPriority.values
                      .map((p) => DropdownMenuItem(value: p, child: Text(priorityLabel(p))))
                      .toList(),
                  onChanged: (v) => setState(() => _priority = v ?? OrderPriority.medium),
                ),
                const SizedBox(height: 16),
                DropdownButtonFormField<String>(
                  value: _vehicleId,
                  decoration: const InputDecoration(labelText: 'Assigned Vehicle'),
                  items: [
                    const DropdownMenuItem<String>(value: null, child: Text('Unassigned')),
                    ...vehicles.map((v) => DropdownMenuItem(value: v.id, child: Text('${v.plateNumber} (${v.type})'))),
                  ],
                  onChanged: (v) => setState(() => _vehicleId = v),
                ),
                const SizedBox(height: 16),
                DropdownButtonFormField<String>(
                  value: _driverId,
                  decoration: const InputDecoration(labelText: 'Assigned Driver'),
                  items: [
                    const DropdownMenuItem<String>(value: null, child: Text('Unassigned')),
                    ...drivers.map((d) => DropdownMenuItem(value: d.id, child: Text(d.name))),
                  ],
                  onChanged: (v) => setState(() => _driverId = v),
                ),
                const SizedBox(height: 16),
                TextFormField(
                  controller: _notesController,
                  maxLines: 3,
                  decoration: const InputDecoration(labelText: 'Notes'),
                ),
                const SizedBox(height: 24),
                Row(
                  children: [
                    ElevatedButton(
                      onPressed: _isSubmitting ? null : _submit,
                      child: _isSubmitting
                          ? const SizedBox(
                              width: 18,
                              height: 18,
                              child: CircularProgressIndicator(strokeWidth: 2, color: Colors.black),
                            )
                          : Text(isEdit ? 'Save Changes' : 'Create Order'),
                    ),
                    const SizedBox(width: 12),
                    TextButton(onPressed: () => Navigator.of(context).pop(), child: const Text('Cancel')),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  String? _requiredValidator(String? v) {
    if (v == null || v.trim().isEmpty) return 'This field is required';
    return null;
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    if (_plannedDate == null) {
      setState(() => _submitError = 'Planned date is required');
      return;
    }
    if (_plannedTime == null) {
      setState(() => _submitError = 'Planned time is required');
      return;
    }
    if (_plannedDate!.isBefore(DateTime(DateTime.now().year, DateTime.now().month, DateTime.now().day))) {
      setState(() => _submitError = 'Planned date cannot be in the past');
      return;
    }

    setState(() {
      _isSubmitting = true;
      _submitError = null;
    });

    final timeStr =
        '${_plannedTime!.hour.toString().padLeft(2, '0')}:${_plannedTime!.minute.toString().padLeft(2, '0')}:00';

    final order = DispatchOrder(
      id: _idController.text.trim(),
      customerName: _customerController.text.trim(),
      phone: _phoneController.text.trim(),
      pickupAddress: _pickupController.text.trim(),
      destinationAddress: _destinationController.text.trim(),
      cargoDescription: _cargoController.text.trim(),
      weightKg: double.parse(_weightController.text.trim()),
      vehicleId: _vehicleId,
      driverId: _driverId,
      plannedDate: _plannedDate!,
      plannedTime: timeStr,
      priority: _priority,
      status: widget.existingOrder?.status ?? OrderStatus.pending,
      notes: _notesController.text.trim(),
    );

    final provider = context.read<OrderProvider>();
    final error = isEdit
        ? await provider.updateOrder(widget.existingOrder!.id, order)
        : await provider.createOrder(order);

    if (!mounted) return;
    setState(() => _isSubmitting = false);

    if (error != null) {
      setState(() => _submitError = error);
      return;
    }

    Navigator.of(context).pop();
  }
}
