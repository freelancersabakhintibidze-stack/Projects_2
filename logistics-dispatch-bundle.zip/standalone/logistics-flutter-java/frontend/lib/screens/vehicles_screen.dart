import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/vehicle.dart';
import '../state/role_provider.dart';
import '../state/vehicle_provider.dart';
import '../theme/app_theme.dart';
import '../widgets/app_scaffold.dart';
import '../widgets/status_badge.dart';

class VehiclesScreen extends StatefulWidget {
  const VehiclesScreen({super.key});

  @override
  State<VehiclesScreen> createState() => _VehiclesScreenState();
}

class _VehiclesScreenState extends State<VehiclesScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<VehicleProvider>().fetchVehicles();
    });
  }

  @override
  Widget build(BuildContext context) {
    final vehicles = context.watch<VehicleProvider>();
    final role = context.watch<RoleProvider>();

    return AppScaffold(
      currentRoute: '/vehicles',
      title: 'Vehicles',
      floatingActionButton: role.isDispatcher
          ? FloatingActionButton.extended(
              onPressed: () => _showVehicleDialog(context, null),
              icon: const Icon(Icons.add),
              label: const Text('Add Vehicle'),
            )
          : null,
      body: vehicles.isLoading
          ? const Center(child: CircularProgressIndicator())
          : vehicles.error != null
              ? Center(child: Text(vehicles.error!, style: const TextStyle(color: AppTheme.danger)))
              : vehicles.vehicles.isEmpty
                  ? const EmptyState(icon: Icons.fire_truck_outlined, title: 'No vehicles yet', message: 'Add your first vehicle to get started.')
                  : ListView.separated(
                      itemCount: vehicles.vehicles.length,
                      separatorBuilder: (_, __) => const SizedBox(height: 8),
                      itemBuilder: (context, index) {
                        final vehicle = vehicles.vehicles[index];
                        return Card(
                          child: ListTile(
                            leading: const CircleAvatar(backgroundColor: AppTheme.surfaceAlt, child: Icon(Icons.local_shipping_outlined)),
                            title: Text(vehicle.plateNumber, style: const TextStyle(fontWeight: FontWeight.bold)),
                            subtitle: Text('${vehicle.type} • Capacity ${vehicle.capacityKg.toStringAsFixed(0)} kg'),
                            trailing: role.isDispatcher
                                ? Row(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      StatusBadge(label: vehicleStatusLabel(vehicle.status), color: _statusColor(vehicle.status)),
                                      IconButton(icon: const Icon(Icons.edit_outlined, size: 18), onPressed: () => _showVehicleDialog(context, vehicle)),
                                      IconButton(
                                        icon: const Icon(Icons.delete_outline, size: 18, color: AppTheme.danger),
                                        onPressed: () async {
                                          final confirmed = await showConfirmDialog(context,
                                              title: 'Delete Vehicle', message: 'Delete ${vehicle.plateNumber}? This cannot be undone.');
                                          if (confirmed) {
                                            await context.read<VehicleProvider>().deleteVehicle(vehicle.id);
                                          }
                                        },
                                      ),
                                    ],
                                  )
                                : StatusBadge(label: vehicleStatusLabel(vehicle.status), color: _statusColor(vehicle.status)),
                          ),
                        );
                      },
                    ),
    );
  }

  Color _statusColor(VehicleStatus status) {
    switch (status) {
      case VehicleStatus.available:
        return AppTheme.success;
      case VehicleStatus.inUse:
        return AppTheme.accent;
      case VehicleStatus.maintenance:
        return AppTheme.danger;
    }
  }

  Future<void> _showVehicleDialog(BuildContext context, Vehicle? existing) async {
    final plateController = TextEditingController(text: existing?.plateNumber ?? '');
    final typeController = TextEditingController(text: existing?.type ?? '');
    final capacityController = TextEditingController(text: existing?.capacityKg.toString() ?? '');
    VehicleStatus status = existing?.status ?? VehicleStatus.available;
    final formKey = GlobalKey<FormState>();
    String? error;

    await showDialog(
      context: context,
      builder: (dialogContext) => StatefulBuilder(builder: (dialogContext, setState) {
        return AlertDialog(
          title: Text(existing == null ? 'Add Vehicle' : 'Edit Vehicle'),
          content: Form(
            key: formKey,
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  if (error != null) Padding(padding: const EdgeInsets.only(bottom: 12), child: Text(error!, style: const TextStyle(color: AppTheme.danger))),
                  TextFormField(
                    controller: plateController,
                    decoration: const InputDecoration(labelText: 'Plate Number *'),
                    validator: (v) => (v == null || v.trim().isEmpty) ? 'Plate number is required' : null,
                  ),
                  const SizedBox(height: 12),
                  TextFormField(
                    controller: typeController,
                    decoration: const InputDecoration(labelText: 'Type *'),
                    validator: (v) => (v == null || v.trim().isEmpty) ? 'Type is required' : null,
                  ),
                  const SizedBox(height: 12),
                  TextFormField(
                    controller: capacityController,
                    keyboardType: const TextInputType.numberWithOptions(decimal: true),
                    decoration: const InputDecoration(labelText: 'Capacity (kg) *'),
                    validator: (v) {
                      final trimmed = v?.trim() ?? '';
                      final parsed = double.tryParse(trimmed);
                      if (parsed == null || parsed <= 0) return 'Capacity must be a positive number';
                      return null;
                    },
                  ),
                  const SizedBox(height: 12),
                  DropdownButtonFormField<VehicleStatus>(
                    value: status,
                    decoration: const InputDecoration(labelText: 'Status'),
                    items: VehicleStatus.values.map((s) => DropdownMenuItem(value: s, child: Text(vehicleStatusLabel(s)))).toList(),
                    onChanged: (v) => setState(() => status = v ?? VehicleStatus.available),
                  ),
                ],
              ),
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.of(dialogContext).pop(), child: const Text('Cancel')),
            ElevatedButton(
              onPressed: () async {
                if (!formKey.currentState!.validate()) return;
                final vehicle = Vehicle(
                  id: existing?.id ?? '',
                  plateNumber: plateController.text.trim(),
                  type: typeController.text.trim(),
                  capacityKg: double.parse(capacityController.text.trim()),
                  status: status,
                );
                final provider = this.context.read<VehicleProvider>();
                final result = existing == null ? await provider.createVehicle(vehicle) : await provider.updateVehicle(existing.id, vehicle);
                if (result != null) {
                  setState(() => error = result);
                } else if (dialogContext.mounted) {
                  Navigator.of(dialogContext).pop();
                }
              },
              child: const Text('Save'),
            ),
          ],
        );
      }),
    );
  }
}
