import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/driver.dart';
import '../state/driver_provider.dart';
import '../state/role_provider.dart';
import '../theme/app_theme.dart';
import '../widgets/app_scaffold.dart';
import '../widgets/status_badge.dart';

class DriversScreen extends StatefulWidget {
  const DriversScreen({super.key});

  @override
  State<DriversScreen> createState() => _DriversScreenState();
}

class _DriversScreenState extends State<DriversScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<DriverProvider>().fetchDrivers();
    });
  }

  @override
  Widget build(BuildContext context) {
    final drivers = context.watch<DriverProvider>();
    final role = context.watch<RoleProvider>();

    return AppScaffold(
      currentRoute: '/drivers',
      title: 'Drivers',
      floatingActionButton: role.isDispatcher
          ? FloatingActionButton.extended(
              onPressed: () => _showDriverDialog(context, null),
              icon: const Icon(Icons.add),
              label: const Text('Add Driver'),
            )
          : null,
      body: drivers.isLoading
          ? const Center(child: CircularProgressIndicator())
          : drivers.error != null
              ? Center(child: Text(drivers.error!, style: const TextStyle(color: AppTheme.danger)))
              : drivers.drivers.isEmpty
                  ? const EmptyState(icon: Icons.badge_outlined, title: 'No drivers yet', message: 'Add your first driver to get started.')
                  : ListView.separated(
                      itemCount: drivers.drivers.length,
                      separatorBuilder: (_, __) => const SizedBox(height: 8),
                      itemBuilder: (context, index) {
                        final driver = drivers.drivers[index];
                        return Card(
                          child: ListTile(
                            leading: const CircleAvatar(backgroundColor: AppTheme.surfaceAlt, child: Icon(Icons.person_outline)),
                            title: Text(driver.name, style: const TextStyle(fontWeight: FontWeight.bold)),
                            subtitle: Text('${driver.phone} • License ${driver.licenseNumber}'),
                            trailing: role.isDispatcher
                                ? Row(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      StatusBadge(label: driverStatusLabel(driver.status), color: _statusColor(driver.status)),
                                      IconButton(icon: const Icon(Icons.edit_outlined, size: 18), onPressed: () => _showDriverDialog(context, driver)),
                                      IconButton(
                                        icon: const Icon(Icons.delete_outline, size: 18, color: AppTheme.danger),
                                        onPressed: () async {
                                          final confirmed = await showConfirmDialog(context,
                                              title: 'Delete Driver', message: 'Delete ${driver.name}? This cannot be undone.');
                                          if (confirmed) {
                                            await context.read<DriverProvider>().deleteDriver(driver.id);
                                          }
                                        },
                                      ),
                                    ],
                                  )
                                : StatusBadge(label: driverStatusLabel(driver.status), color: _statusColor(driver.status)),
                          ),
                        );
                      },
                    ),
    );
  }

  Color _statusColor(DriverStatus status) {
    switch (status) {
      case DriverStatus.available:
        return AppTheme.success;
      case DriverStatus.onDelivery:
        return AppTheme.accent;
      case DriverStatus.offDuty:
        return AppTheme.textSecondary;
    }
  }

  Future<void> _showDriverDialog(BuildContext context, Driver? existing) async {
    final nameController = TextEditingController(text: existing?.name ?? '');
    final phoneController = TextEditingController(text: existing?.phone ?? '');
    final licenseController = TextEditingController(text: existing?.licenseNumber ?? '');
    DriverStatus status = existing?.status ?? DriverStatus.available;
    final formKey = GlobalKey<FormState>();
    String? error;

    await showDialog(
      context: context,
      builder: (dialogContext) => StatefulBuilder(builder: (dialogContext, setState) {
        return AlertDialog(
          title: Text(existing == null ? 'Add Driver' : 'Edit Driver'),
          content: Form(
            key: formKey,
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  if (error != null) Padding(padding: const EdgeInsets.only(bottom: 12), child: Text(error!, style: const TextStyle(color: AppTheme.danger))),
                  TextFormField(
                    controller: nameController,
                    decoration: const InputDecoration(labelText: 'Name *'),
                    validator: (v) => (v == null || v.trim().isEmpty) ? 'Name is required' : null,
                  ),
                  const SizedBox(height: 12),
                  TextFormField(
                    controller: phoneController,
                    decoration: const InputDecoration(labelText: 'Phone *'),
                    validator: (v) {
                      final trimmed = v?.trim() ?? '';
                      if (trimmed.isEmpty) return 'Phone is required';
                      if (!RegExp(r'^\+?[0-9()\-\s]{7,20}$').hasMatch(trimmed)) return 'Enter a valid phone number';
                      return null;
                    },
                  ),
                  const SizedBox(height: 12),
                  TextFormField(
                    controller: licenseController,
                    decoration: const InputDecoration(labelText: 'License Number *'),
                    validator: (v) => (v == null || v.trim().isEmpty) ? 'License number is required' : null,
                  ),
                  const SizedBox(height: 12),
                  DropdownButtonFormField<DriverStatus>(
                    value: status,
                    decoration: const InputDecoration(labelText: 'Status'),
                    items: DriverStatus.values.map((s) => DropdownMenuItem(value: s, child: Text(driverStatusLabel(s)))).toList(),
                    onChanged: (v) => setState(() => status = v ?? DriverStatus.available),
                  ),
                ],
              ),
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.of(dialogContext).pop(), child: const Text('Cancel')),
            ElevatedButton(
              onPressed: () async {
                if (!formKey.currentState!.validate()) return;
                final driver = Driver(
                  id: existing?.id ?? '',
                  name: nameController.text.trim(),
                  phone: phoneController.text.trim(),
                  licenseNumber: licenseController.text.trim(),
                  status: status,
                );
                final provider = this.context.read<DriverProvider>();
                final result = existing == null ? await provider.createDriver(driver) : await provider.updateDriver(existing.id, driver);
                if (result != null) {
                  setState(() => error = result);
                } else if (dialogContext.mounted) {
                  Navigator.of(dialogContext).pop();
                }
              },
              child: const Text('Save'),
            ),
          ],
        );
      }),
    );
  }
}
