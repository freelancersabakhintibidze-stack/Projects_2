import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/order.dart';
import '../state/order_provider.dart';
import '../state/role_provider.dart';
import '../theme/app_theme.dart';
import '../widgets/app_scaffold.dart';
import '../widgets/status_badge.dart';

class OrdersScreen extends StatefulWidget {
  const OrdersScreen({super.key});

  @override
  State<OrdersScreen> createState() => _OrdersScreenState();
}

class _OrdersScreenState extends State<OrdersScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      final provider = context.read<OrderProvider>();
      await provider.restoreFilters();
      await provider.fetchOrders();
    });
  }

  @override
  Widget build(BuildContext context) {
    final orders = context.watch<OrderProvider>();
    final role = context.watch<RoleProvider>();

    return AppScaffold(
      currentRoute: '/orders',
      title: 'Orders',
      floatingActionButton: role.isDispatcher
          ? FloatingActionButton.extended(
              onPressed: () => Navigator.of(context).pushNamed('/orders/new'),
              icon: const Icon(Icons.add),
              label: const Text('New Order'),
            )
          : null,
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildFilterBar(context, orders),
          const SizedBox(height: 16),
          Expanded(
            child: orders.isLoading
                ? const Center(child: CircularProgressIndicator())
                : orders.error != null
                    ? Center(child: Text(orders.error!, style: const TextStyle(color: AppTheme.danger)))
                    : orders.filteredSortedOrders.isEmpty
                        ? const EmptyState(
                            icon: Icons.inbox_outlined,
                            title: 'No orders found',
                            message: 'Try adjusting your filters or search, or create a new order.',
                          )
                        : _buildTable(context, orders),
          ),
          if (!orders.isLoading && orders.filteredSortedOrders.isNotEmpty) _buildPagination(context, orders),
        ],
      ),
    );
  }

  Widget _buildFilterBar(BuildContext context, OrderProvider orders) {
    return Wrap(
      spacing: 12,
      runSpacing: 12,
      children: [
        SizedBox(
          width: 260,
          child: TextField(
            decoration: const InputDecoration(
              prefixIcon: Icon(Icons.search, size: 18),
              hintText: 'Search customer, cargo, ID...',
              isDense: true,
            ),
            onChanged: orders.setSearchQuery,
          ),
        ),
        _buildDropdown(
          hint: 'Status',
          value: orders.statusFilter,
          items: OrderStatus.values.map((s) => statusToApi(s)).toList(),
          onChanged: orders.setStatusFilter,
        ),
        _buildDropdown(
          hint: 'Priority',
          value: orders.priorityFilter,
          items: OrderPriority.values.map((p) => priorityToApi(p)).toList(),
          onChanged: orders.setPriorityFilter,
        ),
        PopupMenuButton<OrderSortField>(
          child: Chip(
            avatar: const Icon(Icons.sort, size: 16),
            label: Text('Sort: ${orders.sortField.name}'),
          ),
          onSelected: orders.setSort,
          itemBuilder: (context) => OrderSortField.values
              .map((f) => PopupMenuItem(value: f, child: Text(f.name)))
              .toList(),
        ),
      ],
    );
  }

  Widget _buildDropdown({
    required String hint,
    required String? value,
    required List<String> items,
    required void Function(String?) onChanged,
  }) {
    return SizedBox(
      width: 160,
      child: DropdownButtonFormField<String>(
        isDense: true,
        value: value,
        hint: Text(hint),
        decoration: const InputDecoration(isDense: true),
        items: [
          const DropdownMenuItem(value: null, child: Text('All')),
          ...items.map((i) => DropdownMenuItem(value: i, child: Text(i))),
        ],
        onChanged: onChanged,
      ),
    );
  }

  Widget _buildTable(BuildContext context, OrderProvider orders) {
    return ListView.separated(
      itemCount: orders.pagedOrders.length,
      separatorBuilder: (_, __) => const SizedBox(height: 8),
      itemBuilder: (context, index) {
        final order = orders.pagedOrders[index];
        return Card(
          child: ListTile(
            onTap: () => Navigator.of(context).pushNamed('/orders/detail', arguments: order.id),
            title: Row(
              children: [
                Text(order.id, style: const TextStyle(fontWeight: FontWeight.bold)),
                const SizedBox(width: 10),
                StatusBadge(label: priorityLabel(order.priority), color: AppTheme.priorityColor(priorityToApi(order.priority))),
              ],
            ),
            subtitle: Padding(
              padding: const EdgeInsets.only(top: 6),
              child: Text('${order.customerName} • ${order.pickupAddress} → ${order.destinationAddress}'),
            ),
            trailing: StatusBadge(label: statusLabel(order.status), color: AppTheme.statusColor(statusToApi(order.status))),
          ),
        );
      },
    );
  }

  Widget _buildPagination(BuildContext context, OrderProvider orders) {
    return Padding(
      padding: const EdgeInsets.only(top: 12),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          IconButton(
            onPressed: orders.page > 0 ? () => orders.setPage(orders.page - 1) : null,
            icon: const Icon(Icons.chevron_left),
          ),
          Text('Page ${orders.page + 1} of ${orders.pageCount}'),
          IconButton(
            onPressed: orders.page < orders.pageCount - 1 ? () => orders.setPage(orders.page + 1) : null,
            icon: const Icon(Icons.chevron_right),
          ),
        ],
      ),
    );
  }
}
