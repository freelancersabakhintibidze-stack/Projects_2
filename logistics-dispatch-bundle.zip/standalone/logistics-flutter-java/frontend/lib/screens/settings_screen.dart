import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../services/api_service.dart';
import '../state/role_provider.dart';
import '../theme/app_theme.dart';
import '../widgets/app_scaffold.dart';
import '../widgets/status_badge.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  String _companyName = 'Apex Logistics';

  @override
  void initState() {
    super.initState();
    _loadCompanyName();
  }

  Future<void> _loadCompanyName() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _companyName = prefs.getString('dispatch_company_name') ?? 'Apex Logistics';
    });
  }

  Future<void> _saveCompanyName(String name) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('dispatch_company_name', name);
  }

  @override
  Widget build(BuildContext context) {
    final role = context.watch<RoleProvider>();

    return AppScaffold(
      currentRoute: '/settings',
      title: 'Settings',
      body: SingleChildScrollView(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 560),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SectionCard(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Company Name', style: TextStyle(fontWeight: FontWeight.bold)),
                    const SizedBox(height: 12),
                    TextFormField(
                      initialValue: _companyName,
                      decoration: const InputDecoration(hintText: 'Company Name'),
                      onFieldSubmitted: (value) {
                        final trimmed = value.trim();
                        if (trimmed.isNotEmpty) {
                          setState(() => _companyName = trimmed);
                          _saveCompanyName(trimmed);
                        }
                      },
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              SectionCard(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Current Role', style: TextStyle(fontWeight: FontWeight.bold)),
                    const SizedBox(height: 4),
                    const Text('Dispatchers can create, edit, delete and complete orders. Viewers can only search and view.',
                        style: TextStyle(color: AppTheme.textSecondary, fontSize: 13)),
                    const SizedBox(height: 12),
                    SegmentedButton<UserRole>(
                      segments: const [
                        ButtonSegment(value: UserRole.dispatcher, label: Text('Dispatcher'), icon: Icon(Icons.build_outlined)),
                        ButtonSegment(value: UserRole.viewer, label: Text('Viewer'), icon: Icon(Icons.visibility_outlined)),
                      ],
                      selected: {role.role},
                      onSelectionChanged: (selection) => context.read<RoleProvider>().setRole(selection.first),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              SectionCard(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Backend Connection', style: TextStyle(fontWeight: FontWeight.bold)),
                    const SizedBox(height: 8),
                    Text('API base URL: ${ApiService.baseUrl}', style: const TextStyle(color: AppTheme.textSecondary, fontSize: 13)),
                    const SizedBox(height: 4),
                    const Text('Data is persisted database-free by the Java backend to local JSON files (orders.json, drivers.json, vehicles.json).',
                        style: TextStyle(color: AppTheme.textSecondary, fontSize: 12)),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              SectionCard(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Danger Zone', style: TextStyle(fontWeight: FontWeight.bold, color: AppTheme.danger)),
                    const SizedBox(height: 8),
                    const Text(
                      'This clears locally cached UI preferences (role, filters, company name) stored on this device. It does not delete orders/drivers/vehicles — those live in the backend JSON files.',
                      style: TextStyle(color: AppTheme.textSecondary, fontSize: 13),
                    ),
                    const SizedBox(height: 12),
                    OutlinedButton(
                      style: OutlinedButton.styleFrom(foregroundColor: AppTheme.danger, side: const BorderSide(color: AppTheme.danger)),
                      onPressed: () async {
                        final confirmed = await showConfirmDialog(
                          context,
                          title: 'Clear Local Cache',
                          message: 'This will reset your role and filter preferences on this device. Continue?',
                          confirmLabel: 'Clear',
                        );
                        if (confirmed) {
                          final prefs = await SharedPreferences.getInstance();
                          await prefs.clear();
                          if (context.mounted) {
                            await context.read<RoleProvider>().load();
                            await _loadCompanyName();
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(content: Text('Local cache cleared.')),
                            );
                          }
                        }
                      },
                      child: const Text('Clear Local Cache'),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
