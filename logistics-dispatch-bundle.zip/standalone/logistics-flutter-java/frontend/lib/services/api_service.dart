import 'package:dio/dio.dart';

/// Thin wrapper around dio configured for the Spring Boot backend.
///
/// Change [baseUrl] if the Java backend is running on a different host/port
/// (e.g. when testing on a physical mobile device use your machine's LAN IP).
class ApiService {
  static const String baseUrl = 'http://localhost:8080/api';

  final Dio dio;

  ApiService()
      : dio = Dio(BaseOptions(
          baseUrl: baseUrl,
          connectTimeout: const Duration(seconds: 8),
          receiveTimeout: const Duration(seconds: 8),
          headers: {'Content-Type': 'application/json'},
        ));

  Future<List<dynamic>> getList(String path) async {
    final response = await dio.get(path);
    return response.data as List<dynamic>;
  }

  Future<Map<String, dynamic>> getOne(String path) async {
    final response = await dio.get(path);
    return response.data as Map<String, dynamic>;
  }

  Future<Map<String, dynamic>> post(String path, Map<String, dynamic> body) async {
    final response = await dio.post(path, data: body);
    return response.data as Map<String, dynamic>;
  }

  Future<Map<String, dynamic>> put(String path, Map<String, dynamic> body) async {
    final response = await dio.put(path, data: body);
    return response.data as Map<String, dynamic>;
  }

  Future<Map<String, dynamic>> patch(String path, Map<String, dynamic> body) async {
    final response = await dio.patch(path, data: body);
    return response.data as Map<String, dynamic>;
  }

  Future<void> delete(String path) async {
    await dio.delete(path);
  }

  /// Extracts a human-readable message from a DioException produced by the
  /// backend's GlobalExceptionHandler (message / fieldErrors / error).
  static String describeError(Object error) {
    if (error is DioException) {
      final data = error.response?.data;
      if (data is Map<String, dynamic>) {
        if (data['fieldErrors'] is Map && (data['fieldErrors'] as Map).isNotEmpty) {
          final fieldErrors = data['fieldErrors'] as Map;
          return fieldErrors.values.first.toString();
        }
        if (data['message'] != null) {
          return data['message'].toString();
        }
      }
      if (error.type == DioExceptionType.connectionError ||
          error.type == DioExceptionType.connectionTimeout) {
        return 'Could not reach the backend. Is the Spring Boot server running on localhost:8080?';
      }
    }
    return error.toString();
  }
}
