import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../state/role_provider.dart';
import '../theme/app_theme.dart';

class NavItem {
  final String label;
  final IconData icon;
  final String route;

  const NavItem({required this.label, required this.icon, required this.route});
}

const List<NavItem> navItems = [
  NavItem(label: 'Dashboard', icon: Icons.dashboard_outlined, route: '/dashboard'),
  NavItem(label: 'Orders', icon: Icons.local_shipping_outlined, route: '/orders'),
  NavItem(label: 'Drivers', icon: Icons.badge_outlined, route: '/drivers'),
  NavItem(label: 'Vehicles', icon: Icons.fire_truck_outlined, route: '/vehicles'),
  NavItem(label: 'Reports', icon: Icons.bar_chart_outlined, route: '/reports'),
];

/// Shared layout: a side navigation rail on wide screens, a drawer on
/// narrow/mobile screens, so the app is usable on Web, tablet and phone.
class AppScaffold extends StatelessWidget {
  final String currentRoute;
  final String title;
  final Widget body;
  final List<Widget>? actions;
  final Widget? floatingActionButton;

  const AppScaffold({
    super.key,
    required this.currentRoute,
    required this.title,
    required this.body,
    this.actions,
    this.floatingActionButton,
  });

  @override
  Widget build(BuildContext context) {
    final isWide = MediaQuery.of(context).size.width >= 900;

    final content = Scaffold(
      appBar: AppBar(
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
        actions: actions,
      ),
      drawer: isWide ? null : Drawer(child: _NavColumn(currentRoute: currentRoute)),
      floatingActionButton: floatingActionButton,
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: body,
      ),
    );

    if (!isWide) return content;

    return Row(
      children: [
        SizedBox(
          width: 220,
          child: _NavColumn(currentRoute: currentRoute),
        ),
        const VerticalDivider(width: 1),
        Expanded(child: content),
      ],
    );
  }
}

class _NavColumn extends StatelessWidget {
  final String currentRoute;
  const _NavColumn({required this.currentRoute});

  @override
  Widget build(BuildContext context) {
    final role = context.watch<RoleProvider>();
    return Container(
      color: AppTheme.surface,
      child: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Padding(
              padding: EdgeInsets.fromLTRB(20, 24, 20, 4),
              child: Text(
                'APEX LOGISTICS',
                style: TextStyle(
                  color: AppTheme.accent,
                  fontWeight: FontWeight.w900,
                  fontSize: 18,
                  letterSpacing: 1.2,
                ),
              ),
            ),
            const Padding(
              padding: EdgeInsets.fromLTRB(20, 0, 20, 20),
              child: Text('DISPATCH CONSOLE', style: TextStyle(color: AppTheme.textSecondary, fontSize: 11, letterSpacing: 1)),
            ),
            for (final item in navItems)
              _NavTile(
                item: item,
                selected: currentRoute == item.route,
              ),
            const Spacer(),
            const Divider(height: 1),
            _NavTile(item: const NavItem(label: 'Settings', icon: Icons.settings_outlined, route: '/settings'), selected: currentRoute == '/settings'),
            _NavTile(item: const NavItem(label: 'About', icon: Icons.info_outline, route: '/about'), selected: currentRoute == '/about'),
            Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  const Icon(Icons.person_outline, size: 16, color: AppTheme.textSecondary),
                  const SizedBox(width: 6),
                  Text(
                    role.isDispatcher ? 'Dispatcher' : 'Viewer',
                    style: const TextStyle(color: AppTheme.textSecondary, fontSize: 12),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _NavTile extends StatelessWidget {
  final NavItem item;
  final bool selected;
  const _NavTile({required this.item, required this.selected});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: selected ? AppTheme.accent.withValues(alpha: 0.12) : Colors.transparent,
      child: InkWell(
        onTap: () {
          if (!selected) {
            Navigator.of(context).pushNamedAndRemoveUntil(item.route, (route) => false);
          } else {
            Navigator.of(context).maybePop();
          }
        },
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
          child: Row(
            children: [
              Icon(item.icon, size: 18, color: selected ? AppTheme.accent : AppTheme.textSecondary),
              const SizedBox(width: 12),
              Text(
                item.label,
                style: TextStyle(
                  color: selected ? AppTheme.accent : AppTheme.textPrimary,
                  fontWeight: selected ? FontWeight.bold : FontWeight.normal,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
