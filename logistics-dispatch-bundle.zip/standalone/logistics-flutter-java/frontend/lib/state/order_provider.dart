import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models/order.dart';
import '../services/api_service.dart';

enum OrderSortField { plannedDate, priority, customerName, status }

class OrderProvider extends ChangeNotifier {
  final ApiService _api;

  OrderProvider(this._api);

  List<DispatchOrder> _orders = [];
  bool _isLoading = false;
  String? _error;

  String searchQuery = '';
  String? statusFilter;
  String? priorityFilter;
  String? cityFilter;
  OrderSortField sortField = OrderSortField.plannedDate;
  bool sortAscending = true;
  int page = 0;
  static const int pageSize = 8;

  List<DispatchOrder> get rawOrders => _orders;
  bool get isLoading => _isLoading;
  String? get error => _error;

  static const _filterPrefsKey = 'dispatch_orders_filters';

  Future<void> restoreFilters() async {
    final prefs = await SharedPreferences.getInstance();
    statusFilter = prefs.getString('$_filterPrefsKey.status');
    priorityFilter = prefs.getString('$_filterPrefsKey.priority');
    cityFilter = prefs.getString('$_filterPrefsKey.city');
    notifyListeners();
  }

  Future<void> _persistFilters() async {
    final prefs = await SharedPreferences.getInstance();
    if (statusFilter != null) {
      await prefs.setString('$_filterPrefsKey.status', statusFilter!);
    } else {
      await prefs.remove('$_filterPrefsKey.status');
    }
    if (priorityFilter != null) {
      await prefs.setString('$_filterPrefsKey.priority', priorityFilter!);
    } else {
      await prefs.remove('$_filterPrefsKey.priority');
    }
    if (cityFilter != null) {
      await prefs.setString('$_filterPrefsKey.city', cityFilter!);
    } else {
      await prefs.remove('$_filterPrefsKey.city');
    }
  }

  Future<void> fetchOrders() async {
    _isLoading = true;
    _error = null;
    notifyListeners();
    try {
      final raw = await _api.getList('/orders');
      _orders = raw.map((e) => DispatchOrder.fromJson(e as Map<String, dynamic>)).toList();
    } catch (e) {
      _error = ApiService.describeError(e);
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  List<DispatchOrder> get filteredSortedOrders {
    var result = _orders.where((order) {
      if (statusFilter != null && statusToApi(order.status) != statusFilter) {
        return false;
      }
      if (priorityFilter != null && priorityToApi(order.priority) != priorityFilter) {
        return false;
      }
      if (cityFilter != null && order.destinationAddress != cityFilter) {
        return false;
      }
      if (searchQuery.trim().isNotEmpty) {
        final q = searchQuery.trim().toLowerCase();
        return order.id.toLowerCase().contains(q) ||
            order.customerName.toLowerCase().contains(q) ||
            order.pickupAddress.toLowerCase().contains(q) ||
            order.destinationAddress.toLowerCase().contains(q) ||
            order.cargoDescription.toLowerCase().contains(q);
      }
      return true;
    }).toList();

    result.sort((a, b) {
      int cmp;
      switch (sortField) {
        case OrderSortField.plannedDate:
          cmp = a.plannedDate.compareTo(b.plannedDate);
          break;
        case OrderSortField.priority:
          cmp = a.priority.index.compareTo(b.priority.index);
          break;
        case OrderSortField.customerName:
          cmp = a.customerName.toLowerCase().compareTo(b.customerName.toLowerCase());
          break;
        case OrderSortField.status:
          cmp = a.status.index.compareTo(b.status.index);
          break;
      }
      return sortAscending ? cmp : -cmp;
    });

    return result;
  }

  List<DispatchOrder> get pagedOrders {
    final all = filteredSortedOrders;
    final start = page * pageSize;
    if (start >= all.length) return [];
    final end = (start + pageSize).clamp(0, all.length);
    return all.sublist(start, end);
  }

  int get pageCount {
    final total = filteredSortedOrders.length;
    return total == 0 ? 1 : (total / pageSize).ceil();
  }

  void setSearchQuery(String value) {
    searchQuery = value;
    page = 0;
    notifyListeners();
  }

  void setStatusFilter(String? value) {
    statusFilter = value;
    page = 0;
    _persistFilters();
    notifyListeners();
  }

  void setPriorityFilter(String? value) {
    priorityFilter = value;
    page = 0;
    _persistFilters();
    notifyListeners();
  }

  void setCityFilter(String? value) {
    cityFilter = value;
    page = 0;
    _persistFilters();
    notifyListeners();
  }

  void setSort(OrderSortField field) {
    if (sortField == field) {
      sortAscending = !sortAscending;
    } else {
      sortField = field;
      sortAscending = true;
    }
    notifyListeners();
  }

  void setPage(int newPage) {
    page = newPage.clamp(0, pageCount - 1);
    notifyListeners();
  }

  DispatchOrder? findById(String id) {
    try {
      return _orders.firstWhere((o) => o.id == id);
    } catch (_) {
      return null;
    }
  }

  bool idExists(String id) => _orders.any((o) => o.id == id);

  Future<String?> createOrder(DispatchOrder order) async {
    try {
      final result = await _api.post('/orders', order.toRequestJson());
      _orders.insert(0, DispatchOrder.fromJson(result));
      notifyListeners();
      return null;
    } catch (e) {
      return ApiService.describeError(e);
    }
  }

  Future<String?> updateOrder(String id, DispatchOrder order) async {
    try {
      final result = await _api.put('/orders/$id', order.toRequestJson());
      final updated = DispatchOrder.fromJson(result);
      final index = _orders.indexWhere((o) => o.id == id);
      if (index >= 0) {
        _orders[index] = updated;
      }
      notifyListeners();
      return null;
    } catch (e) {
      return ApiService.describeError(e);
    }
  }

  Future<String?> updateStatus(String id, OrderStatus status) async {
    try {
      final result = await _api.patch('/orders/$id/status', {'status': statusToApi(status)});
      final updated = DispatchOrder.fromJson(result);
      final index = _orders.indexWhere((o) => o.id == id);
      if (index >= 0) {
        _orders[index] = updated;
      }
      notifyListeners();
      return null;
    } catch (e) {
      return ApiService.describeError(e);
    }
  }

  Future<String?> deleteOrder(String id) async {
    try {
      await _api.delete('/orders/$id');
      _orders.removeWhere((o) => o.id == id);
      notifyListeners();
      return null;
    } catch (e) {
      return ApiService.describeError(e);
    }
  }
}
