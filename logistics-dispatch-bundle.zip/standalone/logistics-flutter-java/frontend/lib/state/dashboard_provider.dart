import 'package:flutter/foundation.dart';

import '../services/api_service.dart';

class DashboardProvider extends ChangeNotifier {
  final ApiService _api;
  DashboardProvider(this._api);

  Map<String, dynamic>? _overview;
  bool _isLoading = false;
  String? _error;

  Map<String, dynamic>? get overview => _overview;
  bool get isLoading => _isLoading;
  String? get error => _error;

  Future<void> fetchOverview() async {
    _isLoading = true;
    _error = null;
    notifyListeners();
    try {
      _overview = await _api.getOne('/dashboard');
    } catch (e) {
      _error = ApiService.describeError(e);
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<Map<String, dynamic>?> fetchDailyReport(DateTime date) async {
    try {
      final dateStr =
          '${date.year.toString().padLeft(4, '0')}-${date.month.toString().padLeft(2, '0')}-${date.day.toString().padLeft(2, '0')}';
      return await _api.getOne('/reports/daily?date=$dateStr');
    } catch (e) {
      return null;
    }
  }
}
