import 'package:flutter/foundation.dart';

import '../models/vehicle.dart';
import '../services/api_service.dart';

class VehicleProvider extends ChangeNotifier {
  final ApiService _api;
  VehicleProvider(this._api);

  List<Vehicle> _vehicles = [];
  bool _isLoading = false;
  String? _error;

  List<Vehicle> get vehicles => _vehicles;
  bool get isLoading => _isLoading;
  String? get error => _error;

  Future<void> fetchVehicles() async {
    _isLoading = true;
    _error = null;
    notifyListeners();
    try {
      final raw = await _api.getList('/vehicles');
      _vehicles = raw.map((e) => Vehicle.fromJson(e as Map<String, dynamic>)).toList();
    } catch (e) {
      _error = ApiService.describeError(e);
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<String?> createVehicle(Vehicle vehicle) async {
    try {
      final result = await _api.post('/vehicles', vehicle.toRequestJson());
      _vehicles.add(Vehicle.fromJson(result));
      notifyListeners();
      return null;
    } catch (e) {
      return ApiService.describeError(e);
    }
  }

  Future<String?> updateVehicle(String id, Vehicle vehicle) async {
    try {
      final result = await _api.put('/vehicles/$id', vehicle.toRequestJson());
      final updated = Vehicle.fromJson(result);
      final index = _vehicles.indexWhere((v) => v.id == id);
      if (index >= 0) _vehicles[index] = updated;
      notifyListeners();
      return null;
    } catch (e) {
      return ApiService.describeError(e);
    }
  }

  Future<String?> deleteVehicle(String id) async {
    try {
      await _api.delete('/vehicles/$id');
      _vehicles.removeWhere((v) => v.id == id);
      notifyListeners();
      return null;
    } catch (e) {
      return ApiService.describeError(e);
    }
  }
}
