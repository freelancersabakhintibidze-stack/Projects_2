import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

enum UserRole { dispatcher, viewer }

/// Holds the currently active role and persists it via shared_preferences so
/// it survives browser reloads / app restarts (per the HydratedBLoC-style
/// caching requirement, implemented here with the simpler shared_preferences
/// + Provider combo).
class RoleProvider extends ChangeNotifier {
  static const _prefsKey = 'dispatch_current_role';

  UserRole _role = UserRole.dispatcher;
  UserRole get role => _role;
  bool get isDispatcher => _role == UserRole.dispatcher;

  Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    final stored = prefs.getString(_prefsKey);
    if (stored == UserRole.viewer.name) {
      _role = UserRole.viewer;
    } else {
      _role = UserRole.dispatcher;
    }
    notifyListeners();
  }

  Future<void> setRole(UserRole role) async {
    _role = role;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_prefsKey, role.name);
    notifyListeners();
  }
}
