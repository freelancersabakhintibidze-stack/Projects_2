import 'package:flutter/foundation.dart';

import '../models/driver.dart';
import '../services/api_service.dart';

class DriverProvider extends ChangeNotifier {
  final ApiService _api;
  DriverProvider(this._api);

  List<Driver> _drivers = [];
  bool _isLoading = false;
  String? _error;

  List<Driver> get drivers => _drivers;
  bool get isLoading => _isLoading;
  String? get error => _error;

  Future<void> fetchDrivers() async {
    _isLoading = true;
    _error = null;
    notifyListeners();
    try {
      final raw = await _api.getList('/drivers');
      _drivers = raw.map((e) => Driver.fromJson(e as Map<String, dynamic>)).toList();
    } catch (e) {
      _error = ApiService.describeError(e);
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<String?> createDriver(Driver driver) async {
    try {
      final result = await _api.post('/drivers', driver.toRequestJson());
      _drivers.add(Driver.fromJson(result));
      notifyListeners();
      return null;
    } catch (e) {
      return ApiService.describeError(e);
    }
  }

  Future<String?> updateDriver(String id, Driver driver) async {
    try {
      final result = await _api.put('/drivers/$id', driver.toRequestJson());
      final updated = Driver.fromJson(result);
      final index = _drivers.indexWhere((d) => d.id == id);
      if (index >= 0) _drivers[index] = updated;
      notifyListeners();
      return null;
    } catch (e) {
      return ApiService.describeError(e);
    }
  }

  Future<String?> deleteDriver(String id) async {
    try {
      await _api.delete('/drivers/$id');
      _drivers.removeWhere((d) => d.id == id);
      notifyListeners();
      return null;
    } catch (e) {
      return ApiService.describeError(e);
    }
  }
}
