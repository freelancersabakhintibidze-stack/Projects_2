import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'screens/about_screen.dart';
import 'screens/dashboard_screen.dart';
import 'screens/drivers_screen.dart';
import 'screens/order_detail_screen.dart';
import 'screens/order_form_screen.dart';
import 'screens/orders_screen.dart';
import 'screens/reports_screen.dart';
import 'screens/settings_screen.dart';
import 'screens/vehicles_screen.dart';
import 'services/api_service.dart';
import 'state/dashboard_provider.dart';
import 'state/driver_provider.dart';
import 'state/order_provider.dart';
import 'state/role_provider.dart';
import 'state/vehicle_provider.dart';
import 'theme/app_theme.dart';

void main() {
  final api = ApiService();

  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => RoleProvider()..load()),
        ChangeNotifierProvider(create: (_) => OrderProvider(api)),
        ChangeNotifierProvider(create: (_) => DriverProvider(api)),
        ChangeNotifierProvider(create: (_) => VehicleProvider(api)),
        ChangeNotifierProvider(create: (_) => DashboardProvider(api)),
      ],
      child: const DispatchApp(),
    ),
  );
}

class DispatchApp extends StatelessWidget {
  const DispatchApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Logistics Dispatch',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.themeData,
      initialRoute: '/dashboard',
      onGenerateRoute: (settings) {
        switch (settings.name) {
          case '/dashboard':
            return MaterialPageRoute(builder: (_) => const DashboardScreen());
          case '/orders':
            return MaterialPageRoute(builder: (_) => const OrdersScreen());
          case '/orders/new':
            return MaterialPageRoute(builder: (_) => const OrderFormScreen());
          case '/orders/detail':
            final id = settings.arguments as String;
            return MaterialPageRoute(builder: (_) => OrderDetailScreen(orderId: id));
          case '/drivers':
            return MaterialPageRoute(builder: (_) => const DriversScreen());
          case '/vehicles':
            return MaterialPageRoute(builder: (_) => const VehiclesScreen());
          case '/reports':
            return MaterialPageRoute(builder: (_) => const ReportsScreen());
          case '/settings':
            return MaterialPageRoute(builder: (_) => const SettingsScreen());
          case '/about':
            return MaterialPageRoute(builder: (_) => const AboutScreen());
          default:
            return MaterialPageRoute(builder: (_) => const DashboardScreen());
        }
      },
    );
  }
}
