enum OrderPriority { low, medium, high, urgent }

enum OrderStatus { pending, assigned, inTransit, completed, cancelled }

OrderPriority priorityFromString(String value) {
  return OrderPriority.values.firstWhere(
    (p) => p.name.toUpperCase() == value.toUpperCase(),
    orElse: () => OrderPriority.medium,
  );
}

String priorityToApi(OrderPriority priority) => priority.name.toUpperCase();

OrderStatus statusFromString(String value) {
  final normalized = value.toUpperCase();
  switch (normalized) {
    case 'IN_TRANSIT':
      return OrderStatus.inTransit;
    default:
      return OrderStatus.values.firstWhere(
        (s) => s.name.toUpperCase() == normalized,
        orElse: () => OrderStatus.pending,
      );
  }
}

String statusToApi(OrderStatus status) {
  switch (status) {
    case OrderStatus.inTransit:
      return 'IN_TRANSIT';
    default:
      return status.name.toUpperCase();
  }
}

String statusLabel(OrderStatus status) {
  switch (status) {
    case OrderStatus.pending:
      return 'Pending';
    case OrderStatus.assigned:
      return 'Assigned';
    case OrderStatus.inTransit:
      return 'In Transit';
    case OrderStatus.completed:
      return 'Completed';
    case OrderStatus.cancelled:
      return 'Cancelled';
  }
}

String priorityLabel(OrderPriority priority) {
  switch (priority) {
    case OrderPriority.low:
      return 'Low';
    case OrderPriority.medium:
      return 'Medium';
    case OrderPriority.high:
      return 'High';
    case OrderPriority.urgent:
      return 'Urgent';
  }
}

class StatusHistoryEntry {
  final OrderStatus status;
  final String timestamp;

  StatusHistoryEntry({required this.status, required this.timestamp});

  factory StatusHistoryEntry.fromJson(Map<String, dynamic> json) {
    return StatusHistoryEntry(
      status: statusFromString(json['status'] as String),
      timestamp: json['timestamp'] as String,
    );
  }
}

class DispatchOrder {
  final String id;
  final String customerName;
  final String phone;
  final String pickupAddress;
  final String destinationAddress;
  final String cargoDescription;
  final double weightKg;
  final String? vehicleId;
  final String? driverId;
  final DateTime plannedDate;
  final String plannedTime; // HH:mm:ss
  final OrderPriority priority;
  final OrderStatus status;
  final String? notes;
  final List<StatusHistoryEntry> statusHistory;
  final String? createdAt;
  final String? updatedAt;

  DispatchOrder({
    required this.id,
    required this.customerName,
    required this.phone,
    required this.pickupAddress,
    required this.destinationAddress,
    required this.cargoDescription,
    required this.weightKg,
    this.vehicleId,
    this.driverId,
    required this.plannedDate,
    required this.plannedTime,
    required this.priority,
    required this.status,
    this.notes,
    this.statusHistory = const [],
    this.createdAt,
    this.updatedAt,
  });

  factory DispatchOrder.fromJson(Map<String, dynamic> json) {
    return DispatchOrder(
      id: json['id'] as String,
      customerName: json['customerName'] as String? ?? '',
      phone: json['phone'] as String? ?? '',
      pickupAddress: json['pickupAddress'] as String? ?? '',
      destinationAddress: json['destinationAddress'] as String? ?? '',
      cargoDescription: json['cargoDescription'] as String? ?? '',
      weightKg: (json['weightKg'] as num?)?.toDouble() ?? 0,
      vehicleId: json['vehicleId'] as String?,
      driverId: json['driverId'] as String?,
      plannedDate: DateTime.parse(json['plannedDate'] as String),
      plannedTime: json['plannedTime'] as String? ?? '00:00:00',
      priority: priorityFromString(json['priority'] as String? ?? 'MEDIUM'),
      status: statusFromString(json['status'] as String? ?? 'PENDING'),
      notes: json['notes'] as String?,
      statusHistory: (json['statusHistory'] as List<dynamic>? ?? [])
          .map((e) => StatusHistoryEntry.fromJson(e as Map<String, dynamic>))
          .toList(),
      createdAt: json['createdAt'] as String?,
      updatedAt: json['updatedAt'] as String?,
    );
  }

  Map<String, dynamic> toRequestJson() {
    return {
      'id': id,
      'customerName': customerName.trim(),
      'phone': phone.trim(),
      'pickupAddress': pickupAddress.trim(),
      'destinationAddress': destinationAddress.trim(),
      'cargoDescription': cargoDescription.trim(),
      'weightKg': weightKg,
      'vehicleId': vehicleId,
      'driverId': driverId,
      'plannedDate':
          '${plannedDate.year.toString().padLeft(4, '0')}-${plannedDate.month.toString().padLeft(2, '0')}-${plannedDate.day.toString().padLeft(2, '0')}',
      'plannedTime': plannedTime,
      'priority': priorityToApi(priority),
      'status': statusToApi(status),
      'notes': notes?.trim(),
    };
  }
}
