enum DriverStatus { available, onDelivery, offDuty }

DriverStatus driverStatusFromString(String value) {
  switch (value.toUpperCase()) {
    case 'ON_DELIVERY':
      return DriverStatus.onDelivery;
    case 'OFF_DUTY':
      return DriverStatus.offDuty;
    default:
      return DriverStatus.available;
  }
}

String driverStatusToApi(DriverStatus status) {
  switch (status) {
    case DriverStatus.onDelivery:
      return 'ON_DELIVERY';
    case DriverStatus.offDuty:
      return 'OFF_DUTY';
    case DriverStatus.available:
      return 'AVAILABLE';
  }
}

String driverStatusLabel(DriverStatus status) {
  switch (status) {
    case DriverStatus.available:
      return 'Available';
    case DriverStatus.onDelivery:
      return 'On Delivery';
    case DriverStatus.offDuty:
      return 'Off Duty';
  }
}

class Driver {
  final String id;
  final String name;
  final String phone;
  final String licenseNumber;
  final DriverStatus status;

  Driver({
    required this.id,
    required this.name,
    required this.phone,
    required this.licenseNumber,
    required this.status,
  });

  factory Driver.fromJson(Map<String, dynamic> json) {
    return Driver(
      id: json['id'] as String,
      name: json['name'] as String? ?? '',
      phone: json['phone'] as String? ?? '',
      licenseNumber: json['licenseNumber'] as String? ?? '',
      status: driverStatusFromString(json['status'] as String? ?? 'AVAILABLE'),
    );
  }

  Map<String, dynamic> toRequestJson() {
    return {
      'name': name.trim(),
      'phone': phone.trim(),
      'licenseNumber': licenseNumber.trim(),
      'status': driverStatusToApi(status),
    };
  }
}
