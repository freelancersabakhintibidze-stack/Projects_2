enum VehicleStatus { available, inUse, maintenance }

VehicleStatus vehicleStatusFromString(String value) {
  switch (value.toUpperCase()) {
    case 'IN_USE':
      return VehicleStatus.inUse;
    case 'MAINTENANCE':
      return VehicleStatus.maintenance;
    default:
      return VehicleStatus.available;
  }
}

String vehicleStatusToApi(VehicleStatus status) {
  switch (status) {
    case VehicleStatus.inUse:
      return 'IN_USE';
    case VehicleStatus.maintenance:
      return 'MAINTENANCE';
    case VehicleStatus.available:
      return 'AVAILABLE';
  }
}

String vehicleStatusLabel(VehicleStatus status) {
  switch (status) {
    case VehicleStatus.available:
      return 'Available';
    case VehicleStatus.inUse:
      return 'In Use';
    case VehicleStatus.maintenance:
      return 'Maintenance';
  }
}

class Vehicle {
  final String id;
  final String plateNumber;
  final String type;
  final double capacityKg;
  final VehicleStatus status;

  Vehicle({
    required this.id,
    required this.plateNumber,
    required this.type,
    required this.capacityKg,
    required this.status,
  });

  factory Vehicle.fromJson(Map<String, dynamic> json) {
    return Vehicle(
      id: json['id'] as String,
      plateNumber: json['plateNumber'] as String? ?? '',
      type: json['type'] as String? ?? '',
      capacityKg: (json['capacityKg'] as num?)?.toDouble() ?? 0,
      status: vehicleStatusFromString(json['status'] as String? ?? 'AVAILABLE'),
    );
  }

  Map<String, dynamic> toRequestJson() {
    return {
      'plateNumber': plateNumber.trim(),
      'type': type.trim(),
      'capacityKg': capacityKg,
      'status': vehicleStatusToApi(status),
    };
  }
}
