package com.dispatch.model;

public enum OrderPriority {
    LOW, MEDIUM, HIGH, URGENT
}
