package com.dispatch.model;

public enum VehicleStatus {
    AVAILABLE, IN_USE, MAINTENANCE
}
