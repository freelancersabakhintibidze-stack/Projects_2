package com.dispatch.model;

public enum DriverStatus {
    AVAILABLE, ON_DELIVERY, OFF_DUTY
}
