package com.dispatch.service;

import com.dispatch.dto.OrderRequest;
import com.dispatch.exception.ApiException;
import com.dispatch.model.Order;
import com.dispatch.model.OrderStatus;
import com.dispatch.storage.JsonFileStore;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

@Service
public class OrderService {

    private final JsonFileStore<Order> orderStore;

    public OrderService(JsonFileStore<Order> orderStore) {
        this.orderStore = orderStore;
    }

    public List<Order> findAll() {
        return orderStore.findAll().stream()
                .sorted(Comparator.comparing(Order::getCreatedAt, Comparator.nullsLast(Comparator.reverseOrder())))
                .toList();
    }

    public Order findById(String id) {
        Order order = orderStore.findById(id);
        if (order == null) {
            throw new ApiException(HttpStatus.NOT_FOUND, "Order '" + id + "' was not found");
        }
        return order;
    }

    public Order create(OrderRequest request) {
        String id = trim(request.getId());

        if (orderStore.existsById(id)) {
            throw new ApiException(HttpStatus.CONFLICT, "Order ID '" + id + "' already exists");
        }
        validatePlannedDateNotInPast(request.getPlannedDate());

        Order order = new Order();
        order.setId(id);
        applyRequestToOrder(order, request);
        order.setStatus(request.getStatus() != null ? request.getStatus() : OrderStatus.PENDING);

        String now = Instant.now().toString();
        order.setCreatedAt(now);
        order.setUpdatedAt(now);
        order.setStatusHistory(new ArrayList<>());
        order.getStatusHistory().add(new Order.StatusHistoryEntry(order.getStatus(), now));

        return orderStore.save(order);
    }

    public Order update(String id, OrderRequest request) {
        Order existing = findById(id);
        validatePlannedDateNotInPast(request.getPlannedDate());

        applyRequestToOrder(existing, request);
        if (request.getStatus() != null && request.getStatus() != existing.getStatus()) {
            transitionStatus(existing, request.getStatus());
        }
        existing.setUpdatedAt(Instant.now().toString());
        return orderStore.save(existing);
    }

    public Order updateStatus(String id, OrderStatus newStatus) {
        Order existing = findById(id);
        transitionStatus(existing, newStatus);
        existing.setUpdatedAt(Instant.now().toString());
        return orderStore.save(existing);
    }

    public void delete(String id) {
        findById(id);
        orderStore.deleteById(id);
    }

    private void transitionStatus(Order order, OrderStatus newStatus) {
        order.setStatus(newStatus);
        order.getStatusHistory().add(new Order.StatusHistoryEntry(newStatus, Instant.now().toString()));
    }

    private void applyRequestToOrder(Order order, OrderRequest request) {
        order.setCustomerName(trim(request.getCustomerName()));
        order.setPhone(trim(request.getPhone()));
        order.setPickupAddress(trim(request.getPickupAddress()));
        order.setDestinationAddress(trim(request.getDestinationAddress()));
        order.setCargoDescription(trim(request.getCargoDescription()));
        order.setWeightKg(request.getWeightKg());
        order.setVehicleId(trim(request.getVehicleId()));
        order.setDriverId(trim(request.getDriverId()));
        order.setPlannedDate(request.getPlannedDate());
        order.setPlannedTime(request.getPlannedTime());
        order.setPriority(request.getPriority());
        order.setNotes(trim(request.getNotes()));
    }

    private void validatePlannedDateNotInPast(LocalDate plannedDate) {
        if (plannedDate != null && plannedDate.isBefore(LocalDate.now())) {
            throw new ApiException(HttpStatus.BAD_REQUEST, "Planned date cannot be in the past");
        }
    }

    private String trim(String value) {
        return value == null ? null : value.trim();
    }
}
