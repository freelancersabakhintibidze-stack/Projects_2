package com.dispatch.model;

public enum OrderStatus {
    PENDING, ASSIGNED, IN_TRANSIT, COMPLETED, CANCELLED
}
