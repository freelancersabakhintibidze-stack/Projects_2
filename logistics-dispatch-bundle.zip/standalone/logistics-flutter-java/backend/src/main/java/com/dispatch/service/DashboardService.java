package com.dispatch.service;

import com.dispatch.model.Order;
import com.dispatch.model.OrderStatus;
import com.dispatch.storage.JsonFileStore;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class DashboardService {

    private final JsonFileStore<Order> orderStore;

    public DashboardService(JsonFileStore<Order> orderStore) {
        this.orderStore = orderStore;
    }

    public Map<String, Object> getOverview() {
        List<Order> orders = orderStore.findAll();

        long total = orders.size();
        long completed = countByStatus(orders, OrderStatus.COMPLETED);
        long pending = countByStatus(orders, OrderStatus.PENDING);
        long cancelled = countByStatus(orders, OrderStatus.CANCELLED);
        double totalWeight = orders.stream().mapToDouble(Order::getWeightKg).sum();

        Map<String, Long> byCity = orders.stream()
                .filter(o -> o.getDestinationAddress() != null && !o.getDestinationAddress().isBlank())
                .collect(Collectors.groupingBy(Order::getDestinationAddress, LinkedHashMap::new, Collectors.counting()));

        Map<String, Long> byPriority = orders.stream()
                .filter(o -> o.getPriority() != null)
                .collect(Collectors.groupingBy(o -> o.getPriority().name(), LinkedHashMap::new, Collectors.counting()));

        List<Order> recentActivity = orders.stream()
                .sorted((a, b) -> {
                    String ta = a.getUpdatedAt() != null ? a.getUpdatedAt() : "";
                    String tb = b.getUpdatedAt() != null ? b.getUpdatedAt() : "";
                    return tb.compareTo(ta);
                })
                .limit(10)
                .toList();

        Map<String, Object> result = new LinkedHashMap<>();
        result.put("totalOrders", total);
        result.put("completed", completed);
        result.put("pending", pending);
        result.put("cancelled", cancelled);
        result.put("totalCargoWeightKg", totalWeight);
        result.put("deliveriesByCity", byCity);
        result.put("deliveriesByPriority", byPriority);
        result.put("recentActivity", recentActivity);
        return result;
    }

    public Map<String, Object> getDailyReport(LocalDate date) {
        LocalDate target = date != null ? date : LocalDate.now();
        List<Order> ordersForDay = orderStore.findAll().stream()
                .filter(o -> target.equals(o.getPlannedDate()))
                .toList();

        long completed = countByStatus(ordersForDay, OrderStatus.COMPLETED);
        long pending = countByStatus(ordersForDay, OrderStatus.PENDING) + countByStatus(ordersForDay, OrderStatus.ASSIGNED)
                + countByStatus(ordersForDay, OrderStatus.IN_TRANSIT);
        long cancelled = countByStatus(ordersForDay, OrderStatus.CANCELLED);
        double totalWeight = ordersForDay.stream().mapToDouble(Order::getWeightKg).sum();

        Map<String, Object> result = new LinkedHashMap<>();
        result.put("date", target.toString());
        result.put("totalOrders", ordersForDay.size());
        result.put("completed", completed);
        result.put("pending", pending);
        result.put("cancelled", cancelled);
        result.put("totalCargoWeightKg", totalWeight);
        result.put("orders", ordersForDay);
        return result;
    }

    private long countByStatus(List<Order> orders, OrderStatus status) {
        return orders.stream().filter(o -> o.getStatus() == status).count();
    }
}
