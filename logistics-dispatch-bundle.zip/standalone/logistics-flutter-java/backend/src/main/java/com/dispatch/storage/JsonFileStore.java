package com.dispatch.storage;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import java.util.function.Function;

/**
 * Generic, thread-safe, database-less persistence helper.
 *
 * Keeps an in-memory ConcurrentHashMap as the source of truth for fast reads,
 * and mirrors every mutation to a JSON file on disk guarded by a
 * ReentrantReadWriteLock so concurrent requests never corrupt the file.
 */
public class JsonFileStore<T> {

    private static final Logger log = LoggerFactory.getLogger(JsonFileStore.class);

    private final ObjectMapper objectMapper;
    private final File file;
    private final Class<T> type;
    private final Function<T, String> idExtractor;
    private final ReadWriteLock lock = new ReentrantReadWriteLock();
    private final Map<String, T> cache = new ConcurrentHashMap<>();

    public JsonFileStore(ObjectMapper objectMapper, File file, Class<T> type, Function<T, String> idExtractor) {
        this.objectMapper = objectMapper;
        this.file = file;
        this.type = type;
        this.idExtractor = idExtractor;
        load();
    }

    private void load() {
        lock.readLock().lock();
        try {
            if (!file.exists()) {
                log.info("No existing data file at {}, starting with empty collection", file.getPath());
                return;
            }
            List<T> items = objectMapper.readValue(file,
                    objectMapper.getTypeFactory().constructCollectionType(List.class, type));
            for (T item : items) {
                cache.put(idExtractor.apply(item), item);
            }
            log.info("Loaded {} records from {}", cache.size(), file.getPath());
        } catch (IOException e) {
            log.error("Failed to load data file {}: {}", file.getPath(), e.getMessage());
        } finally {
            lock.readLock().unlock();
        }
    }

    private void persist() {
        lock.writeLock().lock();
        try {
            File parent = file.getParentFile();
            if (parent != null && !parent.exists()) {
                parent.mkdirs();
            }
            objectMapper.writerWithDefaultPrettyPrinter().writeValue(file, cache.values());
        } catch (IOException e) {
            log.error("Failed to persist data file {}: {}", file.getPath(), e.getMessage());
        } finally {
            lock.writeLock().unlock();
        }
    }

    public List<T> findAll() {
        return List.copyOf(cache.values());
    }

    public T findById(String id) {
        return cache.get(id);
    }

    public boolean existsById(String id) {
        return cache.containsKey(id);
    }

    public T save(T item) {
        cache.put(idExtractor.apply(item), item);
        persist();
        return item;
    }

    public void deleteById(String id) {
        cache.remove(id);
        persist();
    }

    public long count() {
        return cache.size();
    }
}
