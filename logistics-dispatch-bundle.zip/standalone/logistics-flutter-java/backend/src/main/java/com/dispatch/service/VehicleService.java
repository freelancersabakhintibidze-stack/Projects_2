package com.dispatch.service;

import com.dispatch.dto.VehicleRequest;
import com.dispatch.exception.ApiException;
import com.dispatch.model.Vehicle;
import com.dispatch.storage.JsonFileStore;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

@Service
public class VehicleService {

    private final JsonFileStore<Vehicle> vehicleStore;

    public VehicleService(JsonFileStore<Vehicle> vehicleStore) {
        this.vehicleStore = vehicleStore;
    }

    public List<Vehicle> findAll() {
        return vehicleStore.findAll();
    }

    public Vehicle findById(String id) {
        Vehicle vehicle = vehicleStore.findById(id);
        if (vehicle == null) {
            throw new ApiException(HttpStatus.NOT_FOUND, "Vehicle '" + id + "' was not found");
        }
        return vehicle;
    }

    public Vehicle create(VehicleRequest request) {
        Vehicle vehicle = new Vehicle();
        vehicle.setId(UUID.randomUUID().toString());
        applyRequest(vehicle, request);
        return vehicleStore.save(vehicle);
    }

    public Vehicle update(String id, VehicleRequest request) {
        Vehicle existing = findById(id);
        applyRequest(existing, request);
        return vehicleStore.save(existing);
    }

    public void delete(String id) {
        findById(id);
        vehicleStore.deleteById(id);
    }

    private void applyRequest(Vehicle vehicle, VehicleRequest request) {
        vehicle.setPlateNumber(request.getPlateNumber().trim());
        vehicle.setType(request.getType().trim());
        vehicle.setCapacityKg(request.getCapacityKg());
        vehicle.setStatus(request.getStatus());
    }
}
