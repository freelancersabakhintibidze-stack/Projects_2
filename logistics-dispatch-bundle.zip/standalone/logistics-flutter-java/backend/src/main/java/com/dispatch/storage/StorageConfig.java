package com.dispatch.storage;

import com.dispatch.model.Driver;
import com.dispatch.model.Order;
import com.dispatch.model.Vehicle;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

import java.io.File;

@Configuration
public class StorageConfig {

    @Value("${dispatch.storage.directory}")
    private String storageDirectory;

    @Bean
    @Primary
    public ObjectMapper objectMapper() {
        ObjectMapper mapper = new ObjectMapper();
        mapper.registerModule(new JavaTimeModule());
        return mapper;
    }

    @Bean
    public JsonFileStore<Order> orderStore(ObjectMapper objectMapper) {
        return new JsonFileStore<>(objectMapper, new File(storageDirectory, "orders.json"), Order.class, Order::getId);
    }

    @Bean
    public JsonFileStore<Driver> driverStore(ObjectMapper objectMapper) {
        return new JsonFileStore<>(objectMapper, new File(storageDirectory, "drivers.json"), Driver.class, Driver::getId);
    }

    @Bean
    public JsonFileStore<Vehicle> vehicleStore(ObjectMapper objectMapper) {
        return new JsonFileStore<>(objectMapper, new File(storageDirectory, "vehicles.json"), Vehicle.class, Vehicle::getId);
    }
}
