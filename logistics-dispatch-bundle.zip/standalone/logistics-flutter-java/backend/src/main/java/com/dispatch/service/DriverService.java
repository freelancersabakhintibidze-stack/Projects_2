package com.dispatch.service;

import com.dispatch.dto.DriverRequest;
import com.dispatch.exception.ApiException;
import com.dispatch.model.Driver;
import com.dispatch.storage.JsonFileStore;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

@Service
public class DriverService {

    private final JsonFileStore<Driver> driverStore;

    public DriverService(JsonFileStore<Driver> driverStore) {
        this.driverStore = driverStore;
    }

    public List<Driver> findAll() {
        return driverStore.findAll();
    }

    public Driver findById(String id) {
        Driver driver = driverStore.findById(id);
        if (driver == null) {
            throw new ApiException(HttpStatus.NOT_FOUND, "Driver '" + id + "' was not found");
        }
        return driver;
    }

    public Driver create(DriverRequest request) {
        Driver driver = new Driver();
        driver.setId(UUID.randomUUID().toString());
        applyRequest(driver, request);
        return driverStore.save(driver);
    }

    public Driver update(String id, DriverRequest request) {
        Driver existing = findById(id);
        applyRequest(existing, request);
        return driverStore.save(existing);
    }

    public void delete(String id) {
        findById(id);
        driverStore.deleteById(id);
    }

    private void applyRequest(Driver driver, DriverRequest request) {
        driver.setName(request.getName().trim());
        driver.setPhone(request.getPhone().trim());
        driver.setLicenseNumber(request.getLicenseNumber().trim());
        driver.setStatus(request.getStatus());
    }
}
