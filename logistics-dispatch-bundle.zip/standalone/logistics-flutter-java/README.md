# Logistics Dispatch System — Flutter + Java Spring Boot

A database-less logistics dispatch application: a Flutter client (Web/Mobile/Desktop) talking to a Java Spring Boot REST API that persists data to local JSON files instead of a database.

> **Note:** This project is provided as standalone source code for you to build and run **on your own machine**. It is not wired into any Replit workflow/proxy — you'll need Flutter and a JDK installed locally.

## Architecture

```
frontend/   Flutter app (Material 3, Provider state management, dio HTTP client, shared_preferences for local UI caching)
backend/    Spring Boot REST API (Java 17, Maven) — file-based persistence, no database
backend/data/   orders.json, drivers.json, vehicles.json — created/updated automatically by the backend
```

Data flow: Flutter UI → Provider state → dio HTTP client → Spring REST controllers → Service layer (validation) → `JsonFileStore` (ConcurrentHashMap + ReentrantReadWriteLock) → JSON files on disk.

## Prerequisites

- JDK 17+ and Maven (or use the included `mvnw` if you generate one via `mvn -N io.takari:maven:wrapper`)
- Flutter SDK 3.19+ (`flutter --version` to check)
- A running Chrome (for `flutter run -d chrome`) or Android/iOS toolchain if targeting mobile

## 1. Run the backend

```bash
cd backend
mvn spring-boot:run
```

The API starts on `http://localhost:8080`. On first run it seeds `data/orders.json`, `data/drivers.json`, and `data/vehicles.json` with example records. Every create/update/delete operation immediately rewrites the corresponding JSON file, so data survives restarts without any database.

Key endpoints:

- `GET/POST /api/orders`, `GET/PUT/DELETE /api/orders/{id}`, `PATCH /api/orders/{id}/status`
- `GET/POST /api/drivers`, `GET/PUT/DELETE /api/drivers/{id}`
- `GET/POST /api/vehicles`, `GET/PUT/DELETE /api/vehicles/{id}`
- `GET /api/dashboard` — aggregated overview stats
- `GET /api/reports/daily?date=YYYY-MM-DD` — daily report

## 2. Run the Flutter frontend

```bash
cd frontend
flutter pub get
flutter run -d chrome     # for web
# or: flutter run           # to pick a connected device/emulator
```

The app expects the backend at `http://localhost:8080/api` (see `lib/services/api_service.dart`). If you run the Flutter app on a physical mobile device, change `baseUrl` to your computer's LAN IP (e.g. `http://192.168.1.50:8080/api`) since `localhost` on a phone refers to the phone itself.

## Features implemented

- **Roles:** Dispatcher (full CRUD) vs Viewer (read-only), switchable in Settings, persisted locally via `shared_preferences`.
- **Screens:** Dashboard, Orders (filter/sort/search/paginate), Order Detail (status timeline + transitions), Create/Edit Order, Drivers, Vehicles, Daily Reports, Settings, About.
- **Validation:** required fields, unique Order ID, positive cargo weight, valid phone format, planned date not in the past, delete confirmation dialogs, automatic trimming of text fields — enforced on both the Flutter form layer and the Spring Boot DTO layer (defense in depth).
- **Persistence:** Java backend reads/writes local JSON files under `backend/data/`; Flutter caches lightweight UI state (role, filters) locally via `shared_preferences` so it survives reloads.
- **Concurrency:** `ConcurrentHashMap` + `ReentrantReadWriteLock` in `JsonFileStore` so simultaneous API requests can't corrupt the JSON files.

## Notes

- This backend/frontend pair is intentionally decoupled from Replit's artifact/proxy system — you own the ports, hosts, and process lifecycle when you run it locally.
- To reset all business data (orders/drivers/vehicles), stop the backend and delete the three JSON files in `backend/data/` — they will be recreated empty on next boot (or restore the originals from `data/orders.json` etc. included in this bundle).
